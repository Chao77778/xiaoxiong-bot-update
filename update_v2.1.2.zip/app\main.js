﻿// ============== Electron 主进程（OneBot v11 + 网站对接 + 群粒度开关）==============
const { app, BrowserWindow, ipcMain, dialog, shell } = require("electron");
const path = require("path");
const fs = require("fs");
const https = require("https");
const http = require("http");
const { exec } = require("child_process");
const WebSocket = require("ws");
const superlotusImage = require("./text-to-image.js");
const superlotusWF = require("./superlotus-wf.js");
const xiuxian = require("./xiuxian.js");
const { DEFAULT_CONFIG } = require("./defaultConfig");
const officialBot = require("./qqOfficialBot");

const CONFIG_PATH = path.join(app.getPath("userData"), "config.json");
const APP_VERSION = require("./package.json").version;
const UPDATE_URL = "https://raw.githubusercontent.com/Chao77778/xiaoxiong-bot-update/main/";

// ==================== 工具函数 ====================
// 定期清理过期缓存（防止内存泄漏）
let cacheCleanupTimer = null;
function startCacheCleanup() {
  if (cacheCleanupTimer) return;
  cacheCleanupTimer = setInterval(() => {
    const now = Date.now();
    // 清理过期的频率限制
    for (const [userId, lastTime] of userRateLimit) {
      if (now - lastTime > 60000) userRateLimit.delete(userId);
    }
    // 清理过期的缓存
    for (const [key, item] of cacheStore) {
      if (now > item.expire) cacheStore.delete(key);
    }
    // 清理入群欢迎缓存（保留最近1000条）
    if (welcomeCache.size > 1000) {
      const arr = Array.from(welcomeCache);
      welcomeCache.clear();
      arr.slice(-500).forEach(id => welcomeCache.add(id));
    }
  }, 300000); // 每5分钟清理一次
}
// 带超时的HTTP GET
function httpGet(url, timeout = null, customHeaders = null) {
  // 从配置读取超时时间，默认8秒
  if (!timeout && currentConfig && currentConfig.system) {
    timeout = (currentConfig.system.msgTimeout || 8) * 1000;
  } else if (!timeout) {
    timeout = 8000;
  }
  return new Promise((resolve, reject) => {
    const client = url.startsWith("https://") ? https : http;
    const headers = customHeaders || { "User-Agent": "XiaoXiongBot/1.0", "Accept": "application/json" };
    const req = client.get(url, { headers }, (res) => {
      let data = "";
      res.on("data", (c) => data += c);
      res.on("end", () => {
        if (res.statusCode < 200 || res.statusCode >= 300) { reject(new Error("HTTP " + res.statusCode)); return; }
        try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
      });
    });
    req.setTimeout(timeout, () => { req.destroy(); reject(new Error("请求超时")); });
    req.on("error", reject);
  });
}

// 简单缓存（带过期时间）
const cacheStore = new Map();
function cacheGet(key) {
  const item = cacheStore.get(key);
  if (!item) return null;
  if (Date.now() > item.expire) { cacheStore.delete(key); return null; }
  return item.data;
}
function cacheSet(key, data, ttl = 30000) {
  cacheStore.set(key, { data, expire: Date.now() + ttl });
}

// 消息频率限制（每个用户每3秒最多1次指令响应）
const userRateLimit = new Map();
function checkRateLimit(userId, interval = 3000) {
  const now = Date.now();
  const last = userRateLimit.get(userId) || 0;
  if (now - last < interval) return false;
  userRateLimit.set(userId, now);
  return true;
}

let mainWindow = null;
let xiuxianAdminWindow = null; // 修仙管理独立窗口
let ws = null;
let currentConfig = null;
let botStatus = "disconnected";
let logBuffer = [];
let reconnectTimer = null;
let heartbeatTimer = null;
let websiteMonitorTimer = null;
let websiteInitialCheckTimer = null;
let botQQ = null;
let reconnectAttempts = 0;
let connectTimeoutTimer = null;
let manualDisconnect = false; // 主动断开标志，避免主动断开后自动重连
const welcomeCache = new Set();
const MAX_LOGS = 500;
let actionEchoCounter = 0;
const actionCallbacks = new Map();

// 官方机器人模式状态
let officialMode = false; // false=OneBot模式, true=官方模式
let officialStatus = "disconnected";
let officialLastMsgId = null; // 官方模式当前处理的消息ID，用于被动回复

// ==================== 配置文件读写 ====================
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const data = fs.readFileSync(CONFIG_PATH, "utf-8");
      currentConfig = JSON.parse(data);
      currentConfig = deepMerge(DEFAULT_CONFIG, currentConfig);
    } else {
      currentConfig = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
      saveConfig();
    }
  } catch (e) {
    console.error("加载配置失败:", e);
    currentConfig = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  }
  // 同步运行模式
  officialMode = currentConfig.officialMode === true;
  return currentConfig;
}

function saveConfig(config) {
  if (config) currentConfig = config;
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(currentConfig, null, 2), "utf-8");
    return true;
  } catch (e) {
    console.error("保存配置失败:", e);
    return false;
  }
}

function deepMerge(target, source) {
  const result = { ...target };
  for (const key in source) {
    if (source[key] && typeof source[key] === "object" && !Array.isArray(source[key])) {
      result[key] = deepMerge(target[key] || {}, source[key]);
    } else {
      result[key] = source[key];
    }
  }
  return result;
}

// ==================== 群功能开关辅助 ====================
function isFeatureEnabled(groupId, feature) {
  const gid = String(groupId);
  // 先直接用groupId查找
  let groupCfg = currentConfig.groupSettings[gid];
  if (groupCfg && typeof groupCfg[feature] === "boolean") {
    return groupCfg[feature];
  }
  // 如果是openid格式，尝试通过映射找到QQ群号
  if (gid.length === 32 && /^[0-9A-F]+$/.test(gid)) {
    const groupIdMap = currentConfig.groupOpenIdMap || {};
    const qqGroupId = groupIdMap[gid];
    if (qqGroupId) {
      groupCfg = currentConfig.groupSettings[String(qqGroupId)];
      if (groupCfg && typeof groupCfg[feature] === "boolean") {
        return groupCfg[feature];
      }
    }
  }
  return currentConfig.defaults[feature] !== false;
}

// ==================== 日志 & 状态 ====================
function addLog(type, message) {
  // 日志级别过滤
  const sysCfg = currentConfig.system || {};
  const logLevel = sysCfg.logLevel || "all";
  const levelOrder = { debug: 0, info: 1, warn: 2, error: 3 };
  const minLevel = levelOrder[logLevel] !== undefined ? levelOrder[logLevel] : 0;
  const currentLevel = levelOrder[type] !== undefined ? levelOrder[type] : 1;
  if (currentLevel < minLevel) return;
  
  // 调试模式
  if (sysCfg.debugMode) {
    console.log("[DEBUG][" + type + "] " + message);
  }
  

  const now = new Date();
  const time = now.toLocaleString("zh-CN", { hour12: false, month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const entry = {
    time,
    type,
    message,
    timestamp: now.getTime()
  };
  logBuffer.push(entry);
  if (logBuffer.length > MAX_LOGS) logBuffer.shift();
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send("bot:log", entry);
  }
}

function updateStatus(status) {
  botStatus = status;
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send("bot:status", { status, botQQ });
  }
}

// ==================== 官方机器人模式 ====================
async function connectOfficialBotMode() {
  // 设置官方机器人日志回调，输出到UI日志
  officialBot.setLogCallback((type, msg) => {
    addLog(type, "[官方] " + msg);
  });
  
  const appId = currentConfig.official && currentConfig.official.appId;
  const appSecret = currentConfig.official && currentConfig.official.appSecret;
  
  if (!appId || !appSecret) {
    addLog("error", "请先配置官方机器人 AppID 和 AppSecret");
    updateOfficialStatus("error");
    return;
  }
  
  try {
    updateOfficialStatus("connecting");
    // 对AppID进行部分隐藏，避免日志泄露
    const maskedAppId = appId.length > 8 ? appId.slice(0, 4) + "****" + appId.slice(-4) : appId;
    addLog("info", `正在连接官方机器人: AppID=${maskedAppId}`);
    
    await officialBot.connectOfficialBot(
      appId,
      appSecret,
      (msg) => handleOfficialMessage(msg),
      (status) => updateOfficialStatus(status)
    );
    
    addLog("success", "官方机器人连接成功");
  } catch (e) {
    addLog("error", `官方机器人连接失败: ${e.message}`);
    updateOfficialStatus("error");
  }
}

function disconnectOfficialBotMode() {
  officialBot.disconnectOfficialBot();
  updateOfficialStatus("disconnected");
  addLog("info", "官方机器人已断开");
}

function handleOfficialMessage(msg) {
  // 记录最近活跃的群（用于管理后台一键添加）
  if (msg.group_id || msg.group_openid) {
    const gid = msg.group_id || msg.group_openid;
    if (!currentConfig.recentActiveGroups) currentConfig.recentActiveGroups = [];
    currentConfig.recentActiveGroups = currentConfig.recentActiveGroups.filter(g => g.id !== gid);
    currentConfig.recentActiveGroups.unshift({ id: gid, lastActive: Date.now(), type: msg.type });
    if (currentConfig.recentActiveGroups.length > 20) currentConfig.recentActiveGroups = currentConfig.recentActiveGroups.slice(0, 20);
    saveConfig();
  }

  if (msg.type === "group_at") {
    // 群@消息 - 去掉@机器人部分，调用现有指令处理
    let content = msg.message || "";
    content = content.replace(/^@\S+\s*/, "").trim();
    addLog("info", `[官方-群@] 群openid=${msg.group_id} 用户=${msg.user_id}: ${content}`);
    
    // 设置当前消息ID，用于被动回复
    officialLastMsgId = msg.message_id;
    
    // 构造OneBot格式的消息对象，复用现有处理逻辑
    const fakeData = {
      raw_message: content,
      group_id: msg.group_id,
      user_id: msg.user_id,
      sender: { role: "member", nickname: "用户" },
      message: [{ type: "text", data: { text: content } }],
      post_type: "message",
      message_type: "group"
    };
    
    // 调用现有群消息处理逻辑
    handleGroupMessage(fakeData, currentConfig);
    
  } else if (msg.type === "group_add") {
    // 机器人被添加到群 - 记录group_openid，方便配置双模式映射
    addLog("success", `[官方] 机器人被添加到群！group_openid = ${msg.group_openid}`);
    addLog("info", `[官方] 完整msg: ${JSON.stringify(msg)}`);
    addLog("info", `[官方] msg.group_id: ${msg.group_id}, msg.group_openid: ${msg.group_openid}`);
    addLog("info", `[官方] 请在双模式配置中添加群ID映射：QQ群号 -> ${msg.group_openid}`);
    // 发送到渲染进程
    if (mainWindow) mainWindow.webContents.send("official:group_added", { group_openid: msg.group_openid, time: new Date().toLocaleString("zh-CN") });
    
  } else if (msg.type === "c2c") {
    // 单聊消息
    addLog("info", `[官方-单聊] 用户${msg.user_id}: ${msg.message}`);
  } else if (msg.type === "group_member_add") {
    // 群成员加入 - 官方机器人模式（Markdown消息+图片+按钮）
    addLog("info", `[官方-入群] 群${msg.group_id} 用户${msg.user_id} 加入群聊`);
    if (isFeatureEnabled(msg.group_id, "welcome")) {
      try {
      const cfg = currentConfig;
      // 构建Markdown内容
      let markdownContent = cfg.welcome.message
        .replace(/{at}/g, `<qqbot-at-user id="${msg.user_id}" />`)
        .replace(/{nick}/g, "新成员")
        .replace(/{qq}/g, String(msg.user_id))
        .replace(/{group}/g, "本群");
      // 欢迎图片使用Markdown图片语法（QQ官方必须带#宽度px参数，否则会显示成文字）
      const welcomeImage = (cfg.welcome && cfg.welcome.image) ? cfg.welcome.image.trim() : "";
      if (welcomeImage && (welcomeImage.startsWith("http://") || welcomeImage.startsWith("https://"))) {
        const encodedImage = encodeURI(welcomeImage);
        markdownContent += `\n\n![欢迎图 #600px](${encodedImage})`;
      }
      // 构建底部按钮（每行最多3个）
      let keyboard = null;
      const welcomeButtons = (cfg.welcome && cfg.welcome.buttons) ? cfg.welcome.buttons : [];
      if (welcomeButtons.length > 0) {
        const buttonRows = [];
        let currentRow = [];
        welcomeButtons.forEach((btn, idx) => {
          let buttonObj = null;
          const btnId = "welcome_btn_" + idx;
          if (btn.type === "link") {
            // 跳转按钮：点击后直接打开链接
            const btnStyle = btn.style !== undefined ? parseInt(btn.style) : 4;
            buttonObj = officialBot.buildLinkButton(btn.label || "按钮", btn.data || "", btnId, btnStyle);
          } else if (btn.type === "command") {
            // 指令按钮：点击后自动在输入框插入 @bot + 指令
            const btnStyle = btn.style !== undefined ? parseInt(btn.style) : 4;
            buttonObj = officialBot.buildCommandButton(btn.label || "指令", btn.data || "", btnId, btnStyle);
          } else if (btn.type === "copy") {
            // 复制按钮（兼容旧配置）
            const btnStyle = btn.style !== undefined ? parseInt(btn.style) : 4;
            buttonObj = officialBot.buildCopyButton(btn.label || "复制", btn.data || "", btnId);
            buttonObj.render_data.style = btnStyle;
          }
          if (buttonObj) {
            addLog("debug", `[欢迎按钮] ${btn.label} type=${btn.type} style=${buttonObj.render_data.style}`);
            currentRow.push(buttonObj);
            if (currentRow.length >= 3) {
              buttonRows.push(currentRow);
              currentRow = [];
            }
          }
        });
        if (currentRow.length > 0) buttonRows.push(currentRow);
        if (buttonRows.length > 0) {
          keyboard = officialBot.buildKeyboard(buttonRows);
        }
      }
      addLog("debug", `[欢迎调试] 按钮构建完成，keyboard=${keyboard ? "有" : "无"}，行数=${keyboard && keyboard.content ? keyboard.content.rows.length : 0}`);
      // 调试：打印按钮详情
      try {
        if (keyboard && keyboard.content && keyboard.content.rows) {
          keyboard.content.rows.forEach((row, ri) => {
            row.buttons.forEach((btn, bi) => {
              addLog("debug", `[欢迎按钮详情] 行${ri}按钮${bi}: id=${btn.id} label=${btn.render_data.label} style=${btn.render_data.style} actionType=${btn.action.type} data=${btn.action.data} permType=${btn.action.permission ? btn.action.permission.type : "无"}`);
            });
          });
        }
      } catch(e) { addLog("debug", "打印按钮详情失败: " + e.message); }
      addLog("debug", "[欢迎调试] 准备发送消息...");

      // 发送Markdown消息（支持@用户、图片、按钮）
      sendOfficialMarkdownMessage(msg.group_id, markdownContent, keyboard, null, msg.event_id || null).then(() => {
        addLog("success", `[官方-入群欢迎] 已发送Markdown欢迎消息 群${msg.group_id}`);
      }).catch(e => {
        addLog("error", `[官方-入群欢迎] Markdown发送失败 群${msg.group_id}: ${e.message}`);
        // 降级为纯文本
        let fallbackMsg = cfg.welcome.message
          .replace(/{at}/g, "新成员")
          .replace(/{nick}/g, "新成员")
          .replace(/{qq}/g, String(msg.user_id))
          .replace(/{group}/g, "本群");
        sendOfficialGroupMessage(msg.group_id, fallbackMsg, null, msg.event_id || null).catch(e2 => {
          addLog("error", `[官方-入群欢迎] 纯文本也发送失败: ${e2.message}`);
        });
      });
      } catch (welcomeErr) { addLog("error", `[入群欢迎异常] ${welcomeErr.message}\n${welcomeErr.stack}`); }
    }
  } else if (msg.type === "group_member_remove") {
    // 群成员退出 - 官方机器人模式
    addLog("info", `[官方-退群] 群${msg.group_id} 用户${msg.user_id} 退出群聊`);
    if (isFeatureEnabled(msg.group_id, "leaveNotice")) {
      const cfg = currentConfig;
      const leaveMsg = cfg.leaveNotice.message
        .replace(/{nick}/g, String(msg.user_id))
        .replace(/{qq}/g, String(msg.user_id));
      sendOfficialGroupMessage(msg.group_id, leaveMsg).catch(e => {
        addLog("error", `[官方-退群提醒] 发送失败: ${e.message}`);
      });
    }
  }
}

async function sendOfficialGroupMessage(groupId, content, msgId = null) {
  try {
    const result = await officialBot.sendOfficialGroupMessage(groupId, content, msgId);
    addLog("success", `[官方] 发送群消息成功: ${groupId}`);
    return result;
  } catch (e) {
    addLog("error", `[官方] 发送群消息失败: ${e.message}`);
    throw e;
  }
}


async function sendOfficialMarkdownMessage(groupId, markdownContent, keyboard = null, msgId = null, eventId = null) {
  try {
    const result = await officialBot.sendOfficialMarkdownMessage(groupId, markdownContent, keyboard, msgId, eventId);
    addLog("success", `[官方] Markdown消息发送成功: ${groupId}`);
    return result;
  } catch (e) {
    addLog("error", `[官方] Markdown消息发送失败: ${e.message}`);
    throw e;
  }
}

function updateOfficialStatus(status) {
  officialStatus = status;
  botStatus = status; // 同步到全局状态，让运行控制台能显示
  if (mainWindow) {
    mainWindow.webContents.send("official:status", { status: status });
    mainWindow.webContents.send("bot:status", { status: status, botQQ: null });
  }
}

// ==================== OneBot WebSocket 连接 ====================
function connectBot() {
  manualDisconnect = false; // 重置主动断开标志
  reconnectAttempts = 0;
  if (ws) { try { ws.close(); } catch (e) {} ws = null; }
  clearTimeout(reconnectTimer);
  clearInterval(heartbeatTimer);

  const url = currentConfig.connection.wsUrl;
  if (!url) {
    addLog("error", "请先配置 OneBot WebSocket 地址");
    updateStatus("error");
    return;
  }

  updateStatus("connecting");
  addLog("info", `正在连接 OneBot: ${url}`);

  try {
    const wsOptions = currentConfig.connection.accessToken
      ? { headers: { Authorization: `Bearer ${currentConfig.connection.accessToken}` } }
      : undefined;
    ws = new WebSocket(url, wsOptions);
    // 10秒连接超时
    connectTimeoutTimer = setTimeout(() => {
      if (ws && ws.readyState !== WebSocket.OPEN) {
        addLog("error", "连接超时，10秒内未建立连接");
        try { ws.close(); } catch (e) {}
      }
    }, 10000);
  } catch (e) {
    addLog("error", `连接失败: ${e.message}`);
    updateStatus("error");
    scheduleReconnect();
    return;
  }

  ws.onopen = () => {
    clearTimeout(connectTimeoutTimer);
    reconnectAttempts = 0;
    addLog("success", "已连接到 OneBot 服务");
    updateStatus("connected");
    heartbeatTimer = setInterval(() => {
      sendAction("get_status", {});
    }, 30000);
    startWebsiteMonitor();
  };

  ws.onmessage = (event) => {
    try { handleOneBotEvent(JSON.parse(event.data)); } catch (e) { addLog("warn", `消息解析失败: ${e.message}`); }
  };

  ws.onerror = () => {
    addLog("error", "连接错误，请确认 OneBot 服务已启动且 WebSocket 已开启");
  };

  ws.onclose = () => {
    addLog("warn", "与 OneBot 的连接已断开");
    clearInterval(heartbeatTimer);
    stopWebsiteMonitor();
    ws = null; botQQ = null;
    updateStatus("disconnected");
    // 主动断开时不自动重连
    if (!manualDisconnect && !officialMode && currentConfig.connection.autoReconnect) {
      scheduleReconnect();
    } else if (manualDisconnect) {
      addLog("info", "主动断开，不自动重连");
    } else if (officialMode) {
      addLog("info", "当前为官方机器人模式，不自动重连OneBot");
    }
  };
}

function disconnectBot() {
  manualDisconnect = true; // 标记为主动断开，避免自动重连
  clearTimeout(reconnectTimer);
  clearInterval(heartbeatTimer);
  stopWebsiteMonitor();
  if (ws) { try { ws.close(); } catch (e) {} ws = null; }
  botQQ = null;
  updateStatus("disconnected");
  addLog("info", "已断开连接");
}

function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  reconnectAttempts++
  // 检查是否超过最大重连次数
  const _maxReconnect = (currentConfig && currentConfig.system && currentConfig.system.reconnectLimit) || 10;
  if (reconnectAttempts > _maxReconnect) {
    addLog("warn", "已超过最大重连次数(" + _maxReconnect + ")，停止自动重连，请手动连接");
    botStatus = "disconnected";
    return;
  }
  addLog("info", "自动重连第" + reconnectAttempts + "/" + _maxReconnect + "次");;
  const delay = Math.min(5000 * Math.pow(2, reconnectAttempts - 1), 60000);
  const seconds = Math.round(delay / 1000);
  addLog("info", `${seconds}秒后自动重连（第${reconnectAttempts}次尝试）...`);
  reconnectTimer = setTimeout(() => {
    if (currentConfig.connection.autoReconnect && !officialMode) connectBot();
  }, delay);
}

// ==================== OneBot 动作发送 ====================
function sendAction(action, params, callback) {
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    if (callback) callback({ error: "未连接" });
    return null;
  }
  const echo = `action_${++actionEchoCounter}`;
  const payload = { action, params, echo };
  if (callback) {
    actionCallbacks.set(echo, callback);
    // 15秒超时自动清理，防止内存泄漏
    setTimeout(() => {
      if (actionCallbacks.has(echo)) {
        actionCallbacks.delete(echo);
        callback({ error: "请求超时" });
      }
    }, 15000);
  }
  try { ws.send(JSON.stringify(payload)); } catch (e) {
    actionCallbacks.delete(echo);
    if (callback) callback({ error: e.message });
  }
  return echo;
}


function sendGroupMessage(groupId, message) {
  // 官方单模式
  if (officialMode) {
    let text = "";
    let imagePath = "";
    if (typeof message === "string") {
      text = message;
    } else if (Array.isArray(message)) {
      message.forEach((seg) => {
        if (seg.type === "text" && seg.data && seg.data.text) {
          text += seg.data.text;
        } else if (seg.type === "image" && seg.data && seg.data.file) {
          imagePath = seg.data.file;
        }
      });
    }
    if (text.length > 4500) {
      text = text.slice(0, 4500) + "\n\n...（内容过长已截断）";
    }
    const msgId = officialLastMsgId || null;
    
    // 如果有图片，使用图片发送接口
    if (imagePath) {
      officialBot.sendOfficialGroupMessageWithImage(groupId, text, imagePath, msgId).then(() => {
        addLog("success", `[官方] 图片发送成功 群${groupId}`);
      }).catch((e) => {
        addLog("warn", `[官方] 图片发送失败 群${groupId}: ${e.message}`);
        // 图片发送失败时，如果有文本则只发文本
        if (text) {
          officialBot.sendOfficialGroupMessage(groupId, text, msgId).catch((e2) => {
            addLog("warn", `[官方] 文本发送也失败 群${groupId}: ${e2.message}`);
          });
        }
      });
    } else if (text) {
      // 只有文本
      officialBot.sendOfficialGroupMessage(groupId, text, msgId).catch((e) => {
        addLog("warn", `[官方] 发消息失败 群${groupId}: ${e.message}`);
      });
    }
    return;
  }
  
  // OneBot单模式
  let msg = message;
  if (typeof msg === "string") {
    if (msg.length > 4500) {
      msg = msg.slice(0, 4500) + "\n\n...（内容过长已截断）";
    }
  }
  sendAction("send_group_msg", { group_id: groupId, message: msg }, (resp) => {
    if (resp && resp.error) addLog("warn", `发消息失败 群${groupId}: ${resp.error}`);
  });
}

// ==================== 网站对接模块 ====================
function fetchLatestPosts(count = 5) {
  const baseUrl = currentConfig.website.url.replace(/\/$/, "");
  const apiUrl = `${baseUrl}/wp-json/wp/v2/posts?per_page=${count}&_embed&_fields=id,title,link,date,excerpt,content,featured_media`;
  return httpGet(apiUrl, 10000);
}

// 从HTML内容中提取第一张图片URL
function extractFirstImage(html) {
  if (!html) return "";
  const match = html.match(/<img[^>]+src=["']([^"']+)["']/i);
  return match ? match[1] : "";
}

// CQ码特殊字符转义
function escapeCqCode(str) {
  if (!str) return "";
  return str.replace(/&/g, "&amp;").replace(/\[/g, "&#91;").replace(/\]/g, "&#93;").replace(/,/g, "&#44;");
}

async function checkWebsiteAndPush() {
  if (!currentConfig.website.enabled) return;
  if (!currentConfig.website.pushGroups || currentConfig.website.pushGroups.length === 0) return;
  try {
    const posts = await fetchLatestPosts(20);
    if (!Array.isArray(posts) || posts.length === 0) return;
    const latest = posts[0];
    const lastId = currentConfig.website.lastPostId || 0;
    // 获取已推送的文章ID列表（用于双重去重）
    let pushedIds = currentConfig.website.pushedPostIds || [];
    if (!Array.isArray(pushedIds)) pushedIds = [];
    if (lastId === 0) {
      currentConfig.website.lastPostId = latest.id;
      // 记录已推送的文章ID
      pushedIds = posts.map(p => p.id);
      currentConfig.website.pushedPostIds = pushedIds.slice(-50);
      saveConfig();
      addLog("info", `[网站推送] 首次记录最新文章ID: ${latest.id}`);
      return;
    }
    // 找出所有比上次记录新的文章，并且不在已推送列表中
    const newPosts = posts.filter(p => 
      p.id > lastId && !pushedIds.includes(p.id)
    ).reverse();
    for (let i = 0; i < newPosts.length; i++) {
      const post = newPosts[i];
      setTimeout(() => { pushPostToGroups(post); }, i * 3000);
      currentConfig.website.lastPostId = post.id;
      pushedIds.push(post.id);
    }
    if (newPosts.length > 0) {
      // 只保留最近50个已推送ID，避免列表过长
      currentConfig.website.pushedPostIds = pushedIds.slice(-50);
      saveConfig();
      addLog("success", `[网站推送] 推送了 ${newPosts.length} 篇新文章`);
    }
  } catch (e) {
    addLog("warn", `[网站推送] 检查失败: ${e.message}`);
  }
}

async function pushPostToGroups(post) {
  const title = (post.title && post.title.rendered) ? post.title.rendered.replace(/<[^>]+>/g, "") : "新文章";
  const link = post.link || "";
  // 提取文章摘要作为描述
  let description = "";
  if (post.excerpt && post.excerpt.rendered) {
    description = post.excerpt.rendered.replace(/<[^>]+>/g, "").trim();
    if (description.length > 100) description = description.slice(0, 100) + "...";
  }
  // 提取特色图片URL
  let imageUrl = "";
  if (post._embedded && post._embedded["wp:featuredmedia"] && post._embedded["wp:featuredmedia"][0]) {
    imageUrl = post._embedded["wp:featuredmedia"][0].source_url || "";
  }
  // 如果没有特色图片，从文章内容中提取第一张图片
  if (!imageUrl && post.content && post.content.rendered) {
    imageUrl = extractFirstImage(post.content.rendered);
  }
  const template = currentConfig.website.pushTemplate || "{title}\n{link}";
  let textMsg = template.replace(/{title}/g, title).replace(/{link}/g, link);
  
  const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
  const groupIdMap = (currentConfig.dualMode && currentConfig.dualMode.groupIdMap) || {};

  for (const gid of currentConfig.website.pushGroups) {
    if (isFeatureEnabled(gid, "websitePush")) {
      // 双模式：使用 Embed 卡片发送
      if (dualEnabled) {
        const groupOpenId = groupIdMap[String(gid)];
        if (groupOpenId) {
          try {
            await officialBot.sendOfficialArticleCard(groupOpenId, title, description, imageUrl, link);
            addLog("success", `[网站推送] 官方卡片发送成功 群${gid}: ${title}`);
          } catch (e) {
            addLog("warn", `[网站推送] 官方卡片发送失败 群${gid}: ${e.message}`);
            addLog("info", `[网站推送] 自动切换到OneBot发送 群${gid}`);
            // fallback 到 OneBot 发送
            if (imageUrl) {
              const messageSegments = [
                { type: "text", data: { text: textMsg + "\n\n" } },
                { type: "image", data: { file: imageUrl } }
              ];
              sendGroupMessage(gid, messageSegments);
            } else {
              sendGroupMessage(gid, textMsg);
            }
          }
        } else {
          addLog("warn", `[网站推送] 群${gid}未配置group_openid映射，改用OneBot发送`);
          if (imageUrl) {
            const messageSegments = [
              { type: "text", data: { text: textMsg + "\n\n" } },
              { type: "image", data: { file: imageUrl } }
            ];
            sendGroupMessage(gid, messageSegments);
          } else {
            sendGroupMessage(gid, textMsg);
          }
        }
      } else {
        // 非双模式：保持原来的逻辑
        if (imageUrl) {
          const messageSegments = [
            { type: "text", data: { text: textMsg + "\n\n" } },
            { type: "image", data: { file: imageUrl } }
          ];
          sendGroupMessage(gid, messageSegments);
        } else {
          sendGroupMessage(gid, textMsg);
        }
      }
    }
  }
}

function startWebsiteMonitor() {
  stopWebsiteMonitor();
  if (!currentConfig.website.enabled) return;
  const interval = Math.max(1, currentConfig.website.checkInterval || 5) * 60 * 1000;
  websiteMonitorTimer = setInterval(checkWebsiteAndPush, interval);
  addLog("info", `[网站推送] 监控已启动，每 ${currentConfig.website.checkInterval} 分钟检查一次`);
  // 启动后延迟10秒先检查一次
  websiteInitialCheckTimer = setTimeout(checkWebsiteAndPush, 10000);
}

function stopWebsiteMonitor() {
  if (websiteMonitorTimer) {
    clearInterval(websiteMonitorTimer);
    websiteMonitorTimer = null;
  }
  if (websiteInitialCheckTimer) {
    clearTimeout(websiteInitialCheckTimer);
    websiteInitialCheckTimer = null;
  }
}

// ==================== 网站查询功能（搜索/随机/分类/详情）====================
function wpApiRequest(path) {
  const baseUrl = currentConfig.website.url.replace(/\/$/, "");
  const url = `${baseUrl}/wp-json/wp/v2/${path}`;
  return httpGet(url, 10000);
}

async function searchPosts(keyword, count = 5) {
  const posts = await wpApiRequest(`posts?search=${encodeURIComponent(keyword)}&per_page=${count}&_fields=id,title,link,excerpt,date`);
  return Array.isArray(posts) ? posts : [];
}

async function getRandomPost() {
  // 获取最近20篇然后随机选一篇（WordPress原生不支持随机排序）
  const posts = await wpApiRequest("posts?per_page=20&_fields=id,title,link,excerpt,date");
  if (!Array.isArray(posts) || posts.length === 0) return null;
  return posts[Math.floor(Math.random() * posts.length)];
}

async function getCategories() {
  const cats = await wpApiRequest("categories?per_page=100&_fields=id,name,count");
  return Array.isArray(cats) ? cats : [];
}

async function getPostsByCategory(catName, count = 8) {
  const cats = await getCategories();
  const matched = cats.find((c) => c.name.includes(catName) || catName.includes(c.name));
  if (!matched) return { category: null, posts: [] };
  const posts = await wpApiRequest(`posts?categories=${matched.id}&per_page=${count}&_fields=id,title,link,date`);
  return { category: matched, posts: Array.isArray(posts) ? posts : [] };
}

async function getPostDetail(postId) {
  const post = await wpApiRequest(`posts/${postId}?_embed`);
  return post;
}

async function getTags() {
  const tags = await wpApiRequest("tags?per_page=100&_fields=id,name,count");
  return Array.isArray(tags) ? tags : [];
}

async function getPostsByTag(tagName, count = 8) {
  const tags = await getTags();
  const matched = tags.find((t) => t.name.includes(tagName) || tagName.includes(t.name));
  if (!matched) return { tag: null, posts: [] };
  const posts = await wpApiRequest(`posts?tags=${matched.id}&per_page=${count}&_fields=id,title,link,date`);
  return { tag: matched, posts: Array.isArray(posts) ? posts : [] };
}

function stripHtml(html) {
  return (html || "").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
}

function formatPostBrief(post) {
  const title = stripHtml(post.title?.rendered || "无标题");
  const link = post.link || "";
  const excerpt = stripHtml(post.excerpt?.rendered || "").slice(0, 80);
  let msg = `🎮 ${title}\n`;
  if (excerpt) msg += `${excerpt}...\n`;
  msg += `👉 ${link}`;
  return msg;
}


// ==================== 超级小莲风格图片发送 ====================
async function sendSuperlotusImage(groupId, text, title = "") {
  try {
    const buffer = superlotusImage.convertSimple(text, title, null, true);
    const tmpPath = require("path").join(__dirname, "data", "wf_tmp_" + Date.now() + ".png");
    fs.writeFileSync(tmpPath, buffer);
    
    if (onebotWs && onebotWs.readyState === 1) {
      const imgMsg = JSON.stringify({
        action: "send_group_msg",
        params: { group_id: groupId, message: [{ type: "image", data: { file: "file:///" + tmpPath.replace(/\\/g, "/") } }] },
        echo: "wf_image_" + Date.now()
      });
      onebotWs.send(imgMsg);
      console.log("[超级小莲图片] 发送成功 群" + groupId + " 标题:" + title);
      setTimeout(() => { try { fs.unlinkSync(tmpPath); } catch(e) {} }, 3000);
      return true;
    }
    return false;
  } catch (e) {
    console.warn("[超级小莲图片] 发送失败:", e.message);
    return false;
  }
}

// 通用群图片发送函数
async function sendGroupImage(groupId, buffer) {
  try {
    const tmpPath = require("path").join(__dirname, "data", "tmp_" + Date.now() + ".png");
    fs.writeFileSync(tmpPath, buffer);
    
    // 官方机器人模式
    if (officialMode) {
      const msgId = officialLastMsgId || null;
      officialBot.sendOfficialGroupMessageWithImage(groupId, "", tmpPath, msgId).then(() => {
        addLog("success", `[官方] 图片发送成功 群${groupId}`);
      }).catch((e) => {
        addLog("warn", `[官方] 图片发送失败 群${groupId}: ${e.message}`);
      });
      setTimeout(() => { try { fs.unlinkSync(tmpPath); } catch(e) {} }, 5000);
      return true;
    }
    
    // OneBot模式
    if (onebotWs && onebotWs.readyState === 1) {
      const imgMsg = JSON.stringify({
        action: "send_group_msg",
        params: { group_id: groupId, message: [{ type: "image", data: { file: "file:///" + tmpPath.replace(/\\/g, "/") } }] },
        echo: "image_" + Date.now()
      });
      onebotWs.send(imgMsg);
      setTimeout(() => { try { fs.unlinkSync(tmpPath); } catch(e) {} }, 3000);
      return true;
    }
    return false;
  } catch (e) {
    console.warn("[图片发送] 失败:", e.message);
    return false;
  }
}

// ==================== Warframe 国际服模块 ====================

// ==================== WF功能图片生成 ====================
let wfImageWindow = null;

// 文本转图片（wfhub.top精确排版 - 修复版）
async function textToImage(title, content, footer) {
  return new Promise((resolve, reject) => {
    try {
      const { BrowserWindow } = require("electron");
      const escapeHtml = (str) => String(str).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;");
      
      const lines = content.split("\n");
      let cardsHtml = "";
      let inSection = false;
      let cardCount = 0;
      let sectionCount = 0;
      let textLineCount = 0;
      
      const eraColors = {
        "Lith": "#58a6ff", "古纪": "#58a6ff",
        "Meso": "#3fb950", "中纪": "#3fb950", "前纪": "#3fb950",
        "Neo": "#d2a8ff", "后纪": "#d2a8ff",
        "Axi": "#f0883e",
        "Requiem": "#f85149", "安魂": "#f85149",
        "Omnia": "#ffc800", "洪流": "#ffc800"
      };
      
      const isTimeFormat = (s) => {
        return /\d+分/.test(s) || /\d+小时/.test(s) || /\d+h\s*\d*m/.test(s) || /\d+m$/.test(s) || s.includes("已结束") || /\d+秒/.test(s);
      };
      
      lines.forEach(line => {
        const t = line.trim();
        if (t === "") return;
        
        // 跳过emoji标题行（header已经显示了title）
        if (t.match(/^[🌌⚔️🛒🚨🗺️🏆🛡️💰🔬⏳📡🎯📊]/) && t.includes("共")) return;
        
        // 分类标题【】
        if (t.startsWith("【") && t.endsWith("】")) {
          if (inSection) cardsHtml += "</div>";
          inSection = true; sectionCount++;
          cardsHtml += "<div class='section'><div class='section-header'>" + escapeHtml(t) + "</div>";
          return;
        }
        
        // wfhub.top风格任务行：[纪元] [标签] 节点｜任务类型 · 阵营｜剩余时间
        if (t.match(/^\[/) && t.includes("｜")) {
          cardCount++;
          let remain = "", mainPart = t;
          const lastPipe = t.lastIndexOf("｜");
          if (lastPipe > 0) {
            const lastPart = t.substring(lastPipe + 1).trim();
            if (isTimeFormat(lastPart)) { remain = lastPart; mainPart = t.substring(0, lastPipe).trim(); }
          }
          let era = "", tags = [];
          const tagMatches = mainPart.match(/\[([^\]]+)\]/g);
          if (tagMatches) {
            tagMatches.forEach((m, idx) => {
              const val = m.replace(/[\[\]]/g, "");
              if (idx === 0 && (eraColors[val] || val.match(/纪|Lith|Meso|Neo|Axi|Requiem|Omnia|洪流/))) era = val;
              else tags.push(val);
            });
            mainPart = mainPart.replace(/\[[^\]]+\]/g, "").trim();
          }
          let nodeName = mainPart, missionType = "", faction = "";
          const parts = mainPart.split("｜").map(p => p.trim());
          if (parts.length >= 2) {
            nodeName = parts[0];
            const typeParts = parts[1].split("·").map(p => p.trim());
            missionType = typeParts[0] || "";
            faction = typeParts[1] || "";
          }
          const eraColor = eraColors[era] || "#8b949e";
          const tagHtml = tags.map(tg => {
            const isSteel = tg.includes("钢铁") || tg === "SP" || tg === "Steel";
            const isRailjack = tg.includes("Railjack") || tg.includes("航道");
            return "<span class='mission-tag " + (isSteel ? "tag-steel" : isRailjack ? "tag-railjack" : "tag-normal") + "'>" + escapeHtml(tg) + "</span>";
          }).join("");
          cardsHtml += "<div class='wf-card'><div class='wf-card-left'>";
          if (era) cardsHtml += "<div class='wf-era' style='color:" + eraColor + "'>" + escapeHtml(era) + "</div>";
          if (tagHtml) cardsHtml += "<div class='wf-tags'>" + tagHtml + "</div>";
          cardsHtml += "</div><div class='wf-card-middle'><div class='wf-node'>" + escapeHtml(nodeName) + "</div>";
          if (missionType) {
            cardsHtml += "<div class='wf-mission'>" + escapeHtml(missionType);
            if (faction) cardsHtml += " <span class='wf-faction'>· " + escapeHtml(faction) + "</span>";
            cardsHtml += "</div>";
          }
          cardsHtml += "</div><div class='wf-card-right'>";
          if (remain) cardsHtml += "<div class='wf-time" + (remain.includes("已结束") ? " wf-time-ended" : "") + "'>" + escapeHtml(remain) + "</div>";
          cardsHtml += "</div></div>";
          return;
        }
        
        // 普通任务行
        if (t.includes("｜") || isTimeFormat(t)) {
          cardCount++;
          let name = t, type = "", remain = "";
          const lastPipe = t.lastIndexOf("｜");
          if (lastPipe > 0) {
            const lastPart = t.substring(lastPipe + 1).trim();
            if (isTimeFormat(lastPart)) { remain = lastPart; t = t.substring(0, lastPipe).trim(); }
          }
          const parts = t.split("｜").map(p => p.trim());
          if (parts.length >= 2) { name = parts[0]; type = parts[1]; }
          cardsHtml += "<div class='wf-card'><div class='wf-card-left'></div><div class='wf-card-middle'><div class='wf-node'>" + escapeHtml(name) + "</div>" + (type ? "<div class='wf-mission'>" + escapeHtml(type) + "</div>" : "") + "</div><div class='wf-card-right'>" + (remain ? "<div class='wf-time'>" + escapeHtml(remain) + "</div>" : "") + "</div></div>";
          return;
        }
        
        textLineCount++;
        cardsHtml += "<div class='text-line'>" + escapeHtml(t) + "</div>";
      });
      if (inSection) cardsHtml += "</div>";
      if (cardCount === 0 && textLineCount === 0) cardsHtml = "<div class='plain-text'>" + escapeHtml(content).replace(/\n/g, "<br>") + "</div>";
      
      const winWidth = 850;
      let winHeight = 180 + (cardCount * 80) + (sectionCount * 60) + (textLineCount * 40);
      winHeight = Math.max(450, Math.min(winHeight, 4500));
      
      console.log("[图片生成] 卡片数:", cardCount, "分类数:", sectionCount, "文本行:", textLineCount, "窗口尺寸:", winWidth + "x" + winHeight);
      
      const html = "<!DOCTYPE html><html><head><meta charset='UTF-8'><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Segoe UI','Microsoft YaHei',sans-serif;background:#0d1117;color:#c9d1d9;padding:25px;min-height:100vh}.container{max-width:800px;margin:0 auto}.header{background:linear-gradient(135deg,#161b22,#21262d);border-radius:14px;padding:22px 28px;margin-bottom:18px;border:1px solid #30363d;display:flex;align-items:center;justify-content:space-between}.header h1{font-size:28px;color:#58a6ff;font-weight:700}.header .badge{background:rgba(88,166,255,.15);color:#58a6ff;padding:8px 18px;border-radius:22px;font-size:15px;font-weight:600}.section{margin-bottom:18px}.section-header{font-size:20px;font-weight:700;color:#f0f6fc;padding:14px 18px;background:#161b22;border-radius:10px 10px 0 0;border:1px solid #30363d;border-bottom:none}.wf-card{display:flex;align-items:center;padding:14px 18px;background:#161b22;border:1px solid #30363d;border-top:none;gap:14px}.wf-card:last-child{border-radius:0 0 10px 10px}.wf-card-left{min-width:65px;display:flex;flex-direction:column;gap:5px}.wf-era{font-size:19px;font-weight:800;letter-spacing:1px}.wf-tags{display:flex;gap:5px;flex-wrap:wrap}.mission-tag{font-size:11px;padding:3px 9px;border-radius:10px;font-weight:600}.tag-steel{background:rgba(248,81,73,.18);color:#f85149;border:1px solid rgba(248,81,73,.3)}.tag-railjack{background:rgba(210,168,255,.18);color:#d2a8ff;border:1px solid rgba(210,168,255,.3)}.tag-normal{background:rgba(56,139,253,.18);color:#388bfd;border:1px solid rgba(56,139,253,.3)}.wf-card-middle{flex:1;min-width:0}.wf-node{font-size:18px;font-weight:600;color:#f0f6fc;margin-bottom:3px}.wf-mission{font-size:14px;color:#8b949e}.wf-faction{color:#6e7681}.wf-card-right{text-align:right;flex-shrink:0;min-width:85px}.wf-time{font-size:17px;font-weight:700;color:#3fb950}.wf-time-ended{color:#6e7681}.text-line{padding:10px 18px;font-size:16px;color:#c9d1d9;background:#161b22;border:1px solid #30363d;border-top:none;line-height:1.6}.plain-text{background:#161b22;border:1px solid #30363d;border-radius:10px;padding:22px;font-size:17px;line-height:1.8;color:#c9d1d9;white-space:pre-wrap}.footer{text-align:center;margin-top:18px;padding-top:12px;border-top:1px solid #21262d;font-size:14px;color:#484f58}</style></head><body><div class='container'><div class='header'><h1>" + escapeHtml(title) + "</h1><span class='badge'>Tenno Hub</span></div>" + cardsHtml + "<div class='footer'>" + escapeHtml(footer) + "</div></div></body></html>";
      
      const win = new BrowserWindow({ width: winWidth, height: winHeight, show: false, webPreferences: { contextIsolation: true, nodeIntegration: false } });
      win.loadURL("data:text/html;charset=utf-8," + encodeURIComponent(html));
      win.webContents.on("did-finish-load", () => {
        setTimeout(() => {
          win.webContents.capturePage().then(img => {
            const p = require("path").join(require("os").tmpdir(), "wf_" + Date.now() + ".png");
            require("fs").writeFileSync(p, img.toPNG());
            win.close(); resolve(p);
          }).catch(reject);
        }, 600);
      });
      setTimeout(() => { try { win.close(); } catch(e) {} reject(new Error("渲染超时")); }, 20000);
    } catch (e) { reject(e); }
  });
}

// 加载节点和任务类型对照表（英文+中文）
let WF_SOL_NODES = {};
let WF_MISSION_TYPES = {};
let WF_SOL_NODES_ZH = {};
let WF_MISSION_TYPES_ZH = {};
let WF_WM_ALIASES = {};
try {
  WF_SOL_NODES = JSON.parse(fs.readFileSync(path.join(__dirname, "wfdata", "solNodes.json"), "utf-8"));
  WF_MISSION_TYPES = JSON.parse(fs.readFileSync(path.join(__dirname, "wfdata", "missionTypes.json"), "utf-8"));
  WF_SOL_NODES_ZH = JSON.parse(fs.readFileSync(path.join(__dirname, "wfdata", "solNodes.zh.json"), "utf-8"));
  WF_MISSION_TYPES_ZH = JSON.parse(fs.readFileSync(path.join(__dirname, "wfdata", "missionTypes.zh.json"), "utf-8"));
  try {
    WF_WM_ALIASES = JSON.parse(fs.readFileSync(path.join(__dirname, "wfdata", "wm_aliases.json"), "utf-8"));
    console.log("[WF] 加载WM别名数据库:", Object.keys(WF_WM_ALIASES).length, "个别名");
  } catch(e) {
    WF_WM_ALIASES = {};
    console.warn("[WF] 加载WM别名数据库失败:", e.message);
  }
  console.log("[WF] 加载节点对照表:", Object.keys(WF_SOL_NODES).length, "个节点（中文:", Object.keys(WF_SOL_NODES_ZH).length, "）");
  console.log("[WF] 加载任务类型对照表:", Object.keys(WF_MISSION_TYPES).length, "种类型（中文:", Object.keys(WF_MISSION_TYPES_ZH).length, "）");
} catch (e) {
  console.warn("[WF] 加载对照表失败，使用内置映射:", e.message);
}
const WF_API = "https://api.warframestat.us/";

// ==================== 挑战翻译器（移植自超级小莲）====================
let challengeTranslations = null;
let challengeData = null;

function loadChallengeData() {
  if (challengeTranslations && challengeData) return;
  try {
    const zhPath = require("path").join(__dirname, "data", "zh.json");
    const expPath = require("path").join(__dirname, "data", "ExportChallenges.json");
    if (fs.existsSync(zhPath)) {
      challengeTranslations = JSON.parse(fs.readFileSync(zhPath, "utf-8"));
    }
    if (fs.existsSync(expPath)) {
      challengeData = JSON.parse(fs.readFileSync(expPath, "utf-8"));
    }
    console.log("[挑战翻译器] 数据加载成功:", Object.keys(challengeTranslations || {}).length, "条翻译,", Object.keys(challengeData || {}).length, "条挑战");
  } catch (e) {
    console.warn("[挑战翻译器] 加载失败:", e.message);
    challengeTranslations = {};
    challengeData = {};
  }
}

// 将worldState挑战ID映射到ExportChallenges.json的键
function mapToExportKey(challengeId) {
  if (!challengeId) return null;
  // 如果已经是Seasons/Calendar1999/Zariman/Hex格式，直接返回
  if (challengeId.includes("/Seasons/") || challengeId.includes("/Calendar1999/") || 
      challengeId.includes("/Zariman/") || challengeId.includes("/Hex/")) {
    return challengeId;
  }
  // 预定义映射
  const MAP = {
    "/Lotus/Types/Challenges/DailyChallenge_CompleteAnyMission": "/Lotus/Types/Challenges/Seasons/Daily/SeasonDailyCompleteMission",
    "/Lotus/Types/Challenges/WeeklyChallenge_KillEnemies": "/Lotus/Types/Challenges/Seasons/Weekly/SeasonWeeklyKillEnemies",
    "/Lotus/Types/Challenges/WeeklyChallenge_CompleteSpyMissions": "/Lotus/Types/Challenges/Seasons/Weekly/SeasonWeeklyCompleteSpy",
    "/Lotus/Types/Challenges/WeeklyEliteChallenge_CompleteSorties": "/Lotus/Types/Challenges/Seasons/Weekly/SeasonWeeklyCompleteSortie"
  };
  if (MAP[challengeId]) return MAP[challengeId];
  // 通用映射
  if (challengeId.startsWith("/Lotus/Types/Challenges/")) {
    const name = challengeId.replace("/Lotus/Types/Challenges/", "");
    if (name.startsWith("DailyChallenge_")) {
      return "/Lotus/Types/Challenges/Seasons/Daily/SeasonDaily" + name.replace("DailyChallenge_", "");
    } else if (name.startsWith("WeeklyChallenge_")) {
      return "/Lotus/Types/Challenges/Seasons/Weekly/SeasonWeekly" + name.replace("WeeklyChallenge_", "");
    } else if (name.startsWith("WeeklyEliteChallenge_")) {
      return "/Lotus/Types/Challenges/Seasons/Weekly/SeasonElite" + name.replace("WeeklyEliteChallenge_", "");
    }
  }
  return null;
}

// 翻译挑战并获取声望值
function translateChallengeWithStanding(challengeId) {
  loadChallengeData();
  if (!challengeData || !challengeTranslations) return { title: null, standing: 0 };
  try {
    const exportKey = mapToExportKey(challengeId);
    if (!exportKey || !challengeData[exportKey]) {
      // 回退：从ID提取名称
      const parts = challengeId.split("/");
      let simpleName = parts[parts.length - 1] || challengeId;
      const prefixes = ["DailyChallenge_", "WeeklyChallenge_", "WeeklyEliteChallenge_"];
      for (const p of prefixes) {
        if (simpleName.startsWith(p)) { simpleName = simpleName.substring(p.length); break; }
      }
      const suffixes = ["Challenge", "Easy", "Medium", "Hard", "VeryHard", "Normal"];
      for (const s of suffixes) {
        if (simpleName.endsWith(s)) { simpleName = simpleName.substring(0, simpleName.length - s.length); break; }
      }
      simpleName = simpleName.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/([A-Z])([A-Z][a-z])/g, "$1 $2");
      return { title: simpleName, standing: 1000 };
    }
    const cd = challengeData[exportKey];
    const standing = cd.standing || 0;
    const nameKey = cd.name || "";
    if (!nameKey || !nameKey.endsWith("_Name")) {
      return { title: nameKey || exportKey.split("/").pop(), standing };
    }
    const descKey = nameKey.replace("_Name", "_Description");
    let translation = challengeTranslations[descKey];
    if (!translation) {
      return { title: descKey.split("/").pop(), standing };
    }
    // 替换|COUNT|占位符（用split/join避免正则表达式问题）
    const requiredCount = cd.requiredCount || 0;
    if (requiredCount > 0 && translation.includes("|COUNT|")) {
      translation = translation.split("|COUNT|").join(String(requiredCount));
    }
    // 清理伤害类型标记和其他XML标记
    translation = translation.replace(/<[^>]+>/g, "");
    // 清理其他未替换的占位符（|val|、|NUM|等）
    translation = translation.replace(/\|[a-zA-Z0-9_]+\|/g, "");
    return { title: translation, standing };
  } catch (e) {
    console.warn("[挑战翻译器] 翻译失败:", challengeId, e.message);
    return { title: challengeId.split("/").pop(), standing: 0 };
  }
}

let WF_PLATFORM = "pc";

// 官方 API（替代已403的 warframestat.us）
const WF_OFFICIAL_API = "https://api.wfhub.top/int/worldState.json";
const WF_HUB_REFERER = "https://wfhub.top/";
let wfOfficialCache = null;
let wfOfficialCacheTime = 0;
const WF_OFFICIAL_CACHE_TTL = 20000;

async function wfOfficialGet() {
  const now = Date.now();
  if (wfOfficialCache && (now - wfOfficialCacheTime) < WF_OFFICIAL_CACHE_TTL) {
    return wfOfficialCache;
  }
  const headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Referer": WF_HUB_REFERER,
    "Origin": "https://wfhub.top"
  };
  const data = await httpGet(WF_OFFICIAL_API, 15000, headers);
  wfOfficialCache = data;
  wfOfficialCacheTime = now;
  return data;
}

// 从官方API提取时间（毫秒时间戳字符串）
function wfOfficialTime(field) {
  if (!field) return null;
  if (field.$date && field.$date.$numberLong) {
    return parseInt(field.$date.$numberLong, 10);
  }
  return null;
}

// 官方API中英文映射表
const WF_BOSS_MAP = {
  "SORTIE_BOSS_RUK": "莱希·克里尔中尉",
  "SORTIE_BOSS_VAYHEK": "瓦黑克议员",
  "SORTIE_BOSS_SARGAS_RUK": "萨尔加斯·鲁克将军",
  "SORTIE_BOSS_TYL_REGOR": "泰尔·雷戈尔",
  "SORTIE_BOSS_NEF_ANYO": "内夫·安尤",
  "SORTIE_BOSS_AMULS": "阿姆鲁斯",
  "SORTIE_BOSS_KELA_DE_THAYM": "凯拉·德·塞姆",
  "SORTIE_BOSS_HYENA": "鬣狗群",
  "SORTIE_BOSS_LECH_KRIL": "莱希·克里尔中尉",
  "SORTIE_BOSS_VOR": "沃尔上尉",
  "SORTIE_BOSS_PHORID": "恐惧",
  "SORTIE_BOSS_MUTALIST_ALAD_V": "变异化阿拉德五世",
  "SORTIE_BOSS_ALAD_V": "阿拉德五世",
  "SORTIE_BOSS_NATAH": "纳塔",
  "SORTIE_BOSS_TESHIN": "泰辛",
  "SORTIE_BOSS_ERRA": "埃拉",
  "SORTIE_BOSS_BALLAS": "巴拉斯",
  "SORTIE_BOSS_HUNHOW": "浑豪"
};

const WF_MISSION_TYPE_MAP = {
  "MT_ASSASSINATION": "刺杀",
  "MT_EXTERMINATION": "歼灭",
  "MT_SURVIVAL": "生存",
  "MT_DEFENSE": "防御",
  "MT_MOBILE_DEFENSE": "移动防御",
  "MT_CAPTURE": "捕获",
  "MT_INTEL": "间谍",
  "MT_RESCUE": "救援",
  "MT_SABOTAGE": "破坏",
  "MT_EXCAVATION": "挖掘",
  "MT_INTERCEPTION": "拦截",
  "MT_DEFECTION": "叛逃",
  "MT_DISRUPTION": "中断",
  "MT_LANDSCAPE": "开放世界",
  "MT_HIVE": "母巢",
  "MT_ARENA": "竞技场",
  "MT_RUSH": "冲刺",
  "MT_ASSAULT": "突击",
  "MT_SKIRMISH": "前哨战",
  "MT_VOLATILE": " volatile",
  "MT_ORPHIX": "奥菲克斯",
  "MT_CROSSFIRE": "交火",
  "MT_ARTIFACT": "挖掘",
  "MT_TERRITORY": "占领",
  "MT_CORRUPTION": "破坏",
  "MT_ALCHEMY": "炼金",
  "MT_VOID_CASCADE": "虚空洪流",
  "MT_EXCAVATE": "挖掘"
};

const WF_SORTIE_MODIFIER_MAP = {
  "SORTIE_MODIFIER_LOW_ENERGY": "能量降低",
  "SORTIE_MODIFIER_EXIMUS": "卓越者敌人",
  "SORTIE_MODIFIER_HAZARD_MAGNETIC": "磁力危害",
  "SORTIE_MODIFIER_HAZARD_FIRE": "火焰危害",
  "SORTIE_MODIFIER_HAZARD_COLD": "冰冻危害",
  "SORTIE_MODIFIER_HAZARD_TOXIN": "毒素危害",
  "SORTIE_MODIFIER_HAZARD_RADIATION": "辐射危害",
  "SORTIE_MODIFIER_HAZARD_CORROSIVE": "腐蚀危害",
  "SORTIE_MODIFIER_HAZARD_VIRAL": "病毒危害",
  "SORTIE_MODIFIER_HAZARD_BLAST": "爆炸危害",
  "SORTIE_MODIFIER_HAZARD_GAS": "毒气危害",
  "SORTIE_MODIFIER_HAZARD_ELECTRICITY": "电击危害",
  "SORTIE_MODIFIER_NO_SHIELD": "护盾恢复降低",
  "SORTIE_MODIFIER_NO_DAMAGE": "伤害降低",
  "SORTIE_MODIFIER_ARMOR": "敌人护甲增强",
  "SORTIE_MODIFIER_DAMAGE": "敌人伤害增强",
  "SORTIE_MODIFIER_SHIELD": "敌人护盾增强",
  "SORTIE_MODIFIER_HEALTH": "敌人生命增强",
  "SORTIE_MODIFIER_SNIPER_ONLY": "仅狙击枪",
  "SORTIE_MODIFIER_SHOTGUN_ONLY": "仅霰弹枪",
  "SORTIE_MODIFIER_BOW_ONLY": "仅弓",
  "SORTIE_MODIFIER_MELEE_ONLY": "仅近战",
  "SORTIE_MODIFIER_PISTOL_ONLY": "仅副武器",
  "SORTIE_MODIFIER_RIFLE_ONLY": "仅主武器",
  "SORTIE_MODIFIER_AUGMENTED_ENEMIES": "强化敌人",
  "SORTIE_MODIFIER_REDUCED_ACCURACY": "精准度降低"
};

const WF_FACTION_MAP = {
  "FC_GRINEER": "Grineer",
  "FC_CORPUS": "Corpus",
  "FC_INFESTATION": "Infested",
  "FC_SENTIENT": "Sentient",
  "FC_TENNO": "Tenno",
  "FC_STALKER": "Stalker",
  "FC_NARMER": "Narmer"
};

const WF_VOID_TIER_MAP = {
  "VoidT1": "古纪",
  "VoidT2": "前纪",
  "VoidT3": "中纪",
  "VoidT4": "后纪",
  "VoidT5": "安魂"
};

// 节点中文映射（常用节点+HUB）
const WF_NODE_MAP = {
  // 中继站/HUB
  "EarthHUB": "地球·希图斯",
  "VenusHUB": "金星·福尔图娜",
  "DeimosHUB": "火卫二·殁世幽都",
  "MercuryHUB": "水星中继站",
  "MarsHUB": "火星中继站",
  "JupiterHUB": "木星中继站",
  "SaturnHUB": "土星中继站",
  "UranusHUB": "天王星中继站",
  "NeptuneHUB": "海王星中继站",
  "PlutoHUB": "冥王星中继站",
  "ErisHUB": "阋神星中继站",
  "SednaHUB": "赛德娜中继站",
  "CeresHUB": "谷神星中继站",
  "EuropaHUB": "欧罗巴中继站",
  "PhobosHUB": "火卫一中继站",
  // 地球
  "SolNode228": "地球·夜灵平野",
  "SolNode187": "地球·生存",
  "SolNode195": "地球·入侵节点",
  "SolNode226": "地球·间谍",
  "SolNode32": "地球·刺杀",
  // 水星
  "SolNode100": "水星·Tolstoj",
  "SolNode101": "水星·Elion",
  "SolNode102": "水星·Apollodorus",
  // 金星
  "SolNode200": "金星·V Prime",
  "SolNode201": "金星·Cytherean",
  "SolNode202": "金星·Ishtar",
  // 火星
  "SolNode300": "火星·Ara",
  "SolNode301": "火星·Spear",
  "SolNode302": "火星·Hellas",
  "SolNode303": "火星·Augustus",
  // 谷神星
  "SolNode400": "谷神星·Gabii",
  "SolNode401": "谷神星·Draco",
  "SolNode402": "谷神星·Nuovo",
  // 木星
  "SolNode500": "木星·Cameria",
  "SolNode501": "木星·Sinai",
  "SolNode502": "木星·Themisto",
  "SolNode503": "木星·Elara",
  "SolNode504": "木星·Io",
  // 欧罗巴
  "SolNode600": "欧罗巴·Cholistan",
  "SolNode601": "欧罗巴·Nanus",
  "SolNode602": "欧罗巴·Yursa",
  // 土星
  "SolNode700": "土星·Helene",
  "SolNode701": "土星·Mimas",
  "SolNode702": "土星·Tethys",
  "SolNode703": "土星·Enceladus",
  // 天王星
  "SolNode800": "天王星·Piscinas",
  "SolNode801": "天王星·Despina",
  "SolNode802": "天王星·Thalassa",
  // 海王星
  "SolNode900": "海王星·Salacia",
  "SolNode901": "海王星·Hades",
  "SolNode902": "海王星·Proteus",
  // 冥王星
  "SolNode1000": "冥王星·Hydra",
  "SolNode1001": "冥王星·Nix",
  "SolNode1002": "冥王星·Charon",
  // 阋神星
  "SolNode1100": "阋神星·Zabiela",
  "SolNode1101": "阋神星·Berehynia",
  "SolNode1102": "阋神星·Xini",
  // 赛德娜
  "SolNode1200": "赛德娜·Adaro",
  "SolNode1201": "赛德娜·Kappa",
  "SolNode1202": "赛德娜·Hydron",
  "SolNode1203": "赛德娜·Vodyanoi",
  "SolNode1204": "赛德娜·Merrow",
  // 火卫一
  "SolNode1300": "火卫一·Roche",
  "SolNode1301": "火卫一·Trinculo",
  "SolNode1302": "火卫一·Oberon",
  // 航道星舰节点
  "CrewBattleNode518": "航道星舰·虚空风暴T1",
  "CrewBattleNode515": "航道星舰·虚空风暴T1",
  "CrewBattleNode524": "航道星舰·虚空风暴T3",
  "CrewBattleNode534": "航道星舰·虚空风暴T2",
  "CrewBattleNode531": "航道星舰·虚空风暴T4",
  "CrewBattleNode555": "航道星舰·虚空风暴T4"
};

// 常见物品中文映射
const WF_ITEM_MAP = {
  // 武器部件
  "SnipetronVandalStock": "狙击特昂破坏者枪托",
  "SnipetronVandalBarrel": "狙击特昂破坏者枪管",
  "SnipetronVandalReceiver": "狙击特昂破坏者枪机",
  "LatronWraithBarrel": "拉特昂亡魂枪管",
  "LatronWraithStock": "拉特昂亡魂枪托",
  "LatronWraithReceiver": "拉特昂亡魂枪机",
  "BratonVandalStock": "布拉玛破坏者枪托",
  "BratonVandalBarrel": "布拉玛破坏者枪管",
  "BratonVandalReceiver": "布拉玛破坏者枪机",
  // MOD
  "WaterFightBucks": "夏日活动币",
  // 常见资源
  "Neurodes": "神经传感器",
  "NeuralSensors": "神经传感器",
  "AlloyPlate": "合金板",
  "Circuits": "电路",
  "ControlModule": "控制模块",
  "Ferrite": "铁氧体",
  "FerritePlate": "铁氧体",
  "Gallium": "镓",
  "Morphics": "生物质",
  "NanoSpores": "纳米孢子",
  "OrokinCell": "奥罗金电池",
  "Oxium": "氧金属",
  "Plastids": "非晶态合金",
  "PolymerBundle": "聚合杆",
  "Rubedo": "红化结晶",
  "Salvage": "废旧金属",
  "Tellurium": "碲",
  "ArgonCrystal": "氩结晶",
  "Cryotic": "冰晶石",
  "MutalistMass": "异变感染体",
  "NavCoordinate": "导航坐标",
  "Fieldron": "场力石",
  "DetoniteInjector": "爆燃安瓿",
  "MutagenMass": "诱变剂",
  // 杜卡德币相关
  "Ducats": "杜卡德金币"
};

// 节点名转显示名（优先中文，其次英文，最后内置映射）
function wfNodeName(nodeId) {
  if (!nodeId) return "未知";
  // 优先使用中文映射表
  if (WF_SOL_NODES_ZH[nodeId]) {
    return WF_SOL_NODES_ZH[nodeId];
  }
  // 其次使用英文对照表
  if (WF_SOL_NODES[nodeId] && WF_SOL_NODES[nodeId].value) {
    return WF_SOL_NODES[nodeId].value;
  }
  // 最后使用内置中文映射
  if (WF_NODE_MAP[nodeId]) {
    return WF_NODE_MAP[nodeId];
  }
  return nodeId;
}

// 物品名转中文（从路径提取最后一段后映射）

// 任务类型转显示名（优先中文，其次英文，最后内置映射）
function wfMissionType(typeId) {
  if (!typeId) return "未知";
  // 优先使用中文映射表
  if (WF_MISSION_TYPES_ZH[typeId]) {
    return WF_MISSION_TYPES_ZH[typeId];
  }
  // 其次使用英文对照表
  if (WF_MISSION_TYPES[typeId] && WF_MISSION_TYPES[typeId].value) {
    return WF_MISSION_TYPES[typeId].value;
  }
  // 最后使用内置中文映射
  if (WF_MISSION_TYPE_MAP[typeId]) {
    return WF_MISSION_TYPE_MAP[typeId];
  }
  return typeId;
}
function wfItemName(itemType) {
  if (!itemType) return "未知";
  const shortName = itemType.split("/").pop();
  return WF_ITEM_MAP[shortName] || shortName;
}

function wfGet(endpoint) {
  const cacheKey = `wf:${WF_PLATFORM}:${endpoint}`;
  const cached = cacheGet(cacheKey);
  if (cached) return Promise.resolve(cached);
  const url = `${WF_API}${WF_PLATFORM}/${endpoint}`;
  const wfHeaders = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Language": "zh"
  };
  return httpGet(url, 10000, wfHeaders).then((data) => {
    cacheSet(cacheKey, data, 20000);
    return data;
  });
}

function wfTime(iso) {
  if (!iso) return "未知";
  const diff = new Date(iso).getTime() - Date.now();
  if (diff <= 0) return "已结束";
  const h = Math.floor(diff / 3600000), m = Math.floor((diff % 3600000) / 60000), s = Math.floor((diff % 60000) / 1000);
  if (h > 0) return h + "小时" + m + "分";
  if (m > 0) return m + "分" + s + "秒";
  return s + "秒";
}

// 突击
// 从毫秒时间戳计算剩余时间
function wfTimeMs(ts) {
  if (!ts) return "未知";
  const diff = ts - Date.now();
  if (diff <= 0) return "已结束";
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  if (h > 0) return `${h}小时${m}分`;
  if (m > 0) return `${m}分${s}秒`;
  return `${s}秒`;
}

async function wfSortie() {
  try {
    const ws = await wfOfficialGet();
    const sortie = Array.isArray(ws.Sorties) ? ws.Sorties[0] : ws.Sorties;
    if (!sortie) return "暂无突击数据";
    const expiry = wfOfficialTime(sortie.Expiry);
    const boss = WF_BOSS_MAP[sortie.Boss] || sortie.Boss || "未知";
    let msg = `⚔️ 今日突击（剩余${wfTimeMs(expiry)}）\n`;
    msg += `BOSS：${boss}\n\n`;
    if (sortie.Variants && sortie.Variants.length > 0) {
      sortie.Variants.forEach((v, i) => {
        const missionType = wfMissionType(v.missionType) || "未知";
        const modifier = WF_SORTIE_MODIFIER_MAP[v.modifierType] || v.modifierType || "未知";
        msg += `${i + 1}. ${missionType}｜${modifier}\n   节点：${wfNodeName(v.node)}\n\n`;
      });
    }
    return msg.trim();
  } catch (e) {
    return "突击数据获取失败：" + e.message;
  }
}

// 虚空商人
async function wfVoidTrader() {
  try {
    const ws = await wfOfficialGet();
    const traders = ws.VoidTraders;
    if (!traders || traders.length === 0) return "暂无虚空商人数据";
    const trader = traders[0];
    const activation = wfOfficialTime(trader.Activation);
    const expiry = wfOfficialTime(trader.Expiry);
    const now = Date.now();
    const node = trader.Node || "未知";
    const character = trader.Character || "Baro'Ki Teel";
    if (now >= activation && now <= expiry) {
      let msg = `🛒 ${character}已到来（剩余${wfTimeMs(expiry)}）\n`;
      msg += `地点：${node}\n\n`;
      msg += "（官方API不提供售卖物品列表，请游戏内查看）";
      return msg;
    } else {
      return `🛒 ${character}未到来\n下次到达：${new Date(activation).toLocaleString("zh-CN")}\n地点：${node}\n距离到来：${wfTimeMs(activation)}`;
    }
  } catch (e) {
    return "虚空商人数据获取失败：" + e.message;
  }
}


// Darvo每日特惠
async function wfDarvoDeals() {
  try {
    const ws = await wfOfficialGet();
    const deals = ws.DailyDeals;
    if (!Array.isArray(deals) || deals.length === 0) return "暂无Darvo每日特惠";
    let msg = "🏷️ Darvo每日特惠\n\n";
    deals.forEach((d, i) => {
      const itemPath = d.StoreItem || "";
      const itemName = itemPath.split("/").pop().replace(/([A-Z])/g, " $1").trim();
      const discount = d.Discount || 0;
      const originalPrice = d.OriginalPrice || 0;
      const salePrice = d.SalePrice || 0;
      const amountTotal = d.AmountTotal || 0;
      const amountSold = d.AmountSold || 0;
      const remaining = amountTotal - amountSold;
      const expiry = wfOfficialTime(d.Expiry);
      msg += (i+1) + ". " + itemName + "\n";
      msg += "   原价：" + originalPrice + "白金 → 现价：" + salePrice + "白金（-" + discount + "%）\n";
      msg += "   库存：" + remaining + "/" + amountTotal + "（已售" + amountSold + "）\n";
      msg += "   剩余：" + wfTimeMs(expiry) + "\n\n";
    });
    return msg.trim();
  } catch (e) {
    return "Darvo特惠获取失败：" + e.message;
  }
}

// 仲裁
async function wfArbitration() {
  try {
    const ws = await wfOfficialGet();
    // 仲裁数据在SyndicateMissions的ArbitersSyndicate里
    const arb = (ws.SyndicateMissions || []).find(m => m.Tag === "ArbitersSyndicate");
    if (!arb || !arb.Nodes || arb.Nodes.length === 0) return "🏆 暂无仲裁数据";
    const node = arb.Nodes[0];
    let msg = "🏆 当前仲裁\n";
    msg += "节点：" + wfNodeName(node.Node || "未知") + "\n";
    if (node.Type) msg += "类型：" + (WF_MISSION_TYPE_MAP[node.Type] || node.Type) + "\n";
    msg += "剩余：" + wfTimeMs(wfOfficialTime(arb.Expiry));
    return msg;
  } catch (e) {
    return "仲裁获取失败：" + e.message;
  }
}

// 虚空裂缝（支持4种类型：普通/钢铁/虚空风暴普通/虚空风暴钢铁）
async function wfFissures(type) {
  try {
    const ws = await wfOfficialGet();
    const missions = ws.ActiveMissions || [];
    const storms = ws.VoidStorms || [];
    
    // 纪元映射
    const tierMap = { "VoidT1": "古纪", "VoidT2": "前纪", "VoidT3": "中纪", "VoidT4": "后纪", "VoidT5": "安魂", "VoidT6": "洪流" };
    
    // 按类型筛选
    let normalFissures = missions.filter(m => m.Modifier && m.Modifier.startsWith("Void") && !m.Hard);
    let steelFissures = missions.filter(m => m.Modifier && m.Modifier.startsWith("Void") && m.Hard);
    let normalStorms = storms.filter(s => !s.Hard);
    let steelStorms = storms.filter(s => s.Hard);
    
    let title = "";
    let showList = [];
    let maxShow = 20;
    
    switch(type) {
      case "steel":
        title = "⚔️ 钢铁裂缝（共" + steelFissures.length + "个）";
        showList = steelFissures;
        break;
      case "storm":
        title = "🚀 虚空风暴（共" + normalStorms.length + "个）";
        showList = normalStorms;
        maxShow = 15;
        break;
      case "steelstorm":
        title = "⚔️🚀 钢铁虚空风暴（共" + steelStorms.length + "个）";
        showList = steelStorms;
        maxShow = 15;
        break;
      case "normal":
      default:
        title = "🌌 普通裂缝（共" + normalFissures.length + "个）";
        showList = normalFissures;
        break;
    }
    
    if (showList.length === 0) return title + "\n（当前暂无此类裂缝）";
    
    let msg = title + "\n\n";
    
    // 英文任务类型映射
    const missionTypeEn = {
      "MT_MOBILE_DEFENSE": "MOBILE DEFENSE", "MT_EXTERMINATION": "EXTERMINATION",
      "MT_SURVIVAL": "SURVIVAL", "MT_DEFENSE": "DEFENSE", "MT_INTERCEPTION": "INTERCEPTION",
      "MT_RESCUE": "RESCUE", "MT_SPY": "SPY", "MT_CAPTURE": "CAPTURE",
      "MT_SABOTAGE": "SABOTAGE", "MT_HIJACK": "HIJACK", "MT_ASSAULT": "ASSAULT",
      "MT_PURSUIT": "PURSUIT", "MT_RUSH": "RUSH", "MT_VOID_FISSURE": "VOID FISSURE",
      "MT_VOID_CASCADE": "VOID CASCADE", "MT_VOID_FLOOD": "VOID FLOOD",
      "MT_ALCHEMY": "ALCHEMY", "MT_CONJUNCTION_SURVIVAL": "CONJUNCTION SURVIVAL",
      "MT_SKIRMISH": "SKIRMISH", "MT_VOLATILE": "VOLATILE", "MT_DISRUPTION": "DISRUPTION",
      "MT_FREE_ROAM": "FREE ROAM", "MT_EXCAVATION": "EXCAVATION",
      "MT_DEFECTION": "DEFECTION", "MT_INFESTED_SALVAGE": "INFESTED SALVAGE",
      "MT_ARENA": "ARENA", "MT_RACE": "RACE", "MT_PARKOUR": "PARKOUR",
      "MT_MULTIPLAYER": "MULTIPLAYER", "MT_TUTORIAL": "TUTORIAL",
      "MT_UNDEFINED": "UNDEFINED", "MT_RAILJACK": "RAILJACK",
      "MT_VOID_ARMAGEDDON": "VOID ARMAGEDDON", "MT_VOID_CULLING": "VOID CULLING",
      "MT_VOID_DESTRUCTION": "VOID DESTRUCTION", "MT_VOID_TIDE": "VOID TIDE",
      "MT_VOID_RAIL": "VOID RAIL", "MT_VOID_STORM": "VOID STORM",
      "MT_VOID_TEAR": "VOID TEAR", "MT_VOID_WEAPON": "VOID WEAPON",
      "MT_VOID_WING": "VOID WING", "MT_VOID_ZONE": "VOID ZONE",
      "MT_ARCHWING": "ARCHWING", "MT_ARCHWING_EXTERMINATION": "ARCHWING EXTERMINATION",
      "MT_ARCHWING_SABOTAGE": "ARCHWING SABOTAGE", "MT_ARCHWING_SURVIVAL": "ARCHWING SURVIVAL",
      "MT_ARCHWING_DEFENSE": "ARCHWING DEFENSE", "MT_ARCHWING_MOBILE_DEFENSE": "ARCHWING MOBILE DEFENSE",
      "MT_ARCHWING_INTERCEPTION": "ARCHWING INTERCEPTION", "MT_ARCHWING_RESCUE": "ARCHWING RESCUE",
      "MT_ARCHWING_SPY": "ARCHWING SPY", "MT_ARCHWING_CAPTURE": "ARCHWING CAPTURE",
      "MT_ARCHWING_ASSAULT": "ARCHWING ASSAULT", "MT_ARCHWING_PURSUIT": "ARCHWING PURSUIT",
      "MT_ARCHWING_RUSH": "ARCHWING RUSH", "MT_ARCHWING_DISRUPTION": "ARCHWING DISRUPTION",
      "MT_ARCHWING_EXCAVATION": "ARCHWING EXCAVATION", "MT_ARCHWING_DEFECTION": "ARCHWING DEFECTION",
      "MT_ARCHWING_INFESTED_SALVAGE": "ARCHWING INFESTED SALVAGE", "MT_ARCHWING_ARENA": "ARCHWING ARENA",
      "MT_ARCHWING_RACE": "ARCHWING RACE", "MT_ARCHWING_PARKOUR": "ARCHWING PARKOUR",
      "MT_ARCHWING_MULTIPLAYER": "ARCHWING MULTIPLAYER", "MT_ARCHWING_TUTORIAL": "ARCHWING TUTORIAL",
      "MT_ARCHWING_UNDEFINED": "ARCHWING UNDEFINED", "MT_ARCHWING_RAILJACK": "ARCHWING RAILJACK",
      "MT_LANDSCAPE": "LANDSCAPE", "MT_LANDSCAPE_EXTERMINATION": "LANDSCAPE EXTERMINATION",
      "MT_LANDSCAPE_SABOTAGE": "LANDSCAPE SABOTAGE", "MT_LANDSCAPE_SURVIVAL": "LANDSCAPE SURVIVAL",
      "MT_LANDSCAPE_DEFENSE": "LANDSCAPE DEFENSE", "MT_LANDSCAPE_MOBILE_DEFENSE": "LANDSCAPE MOBILE DEFENSE",
      "MT_LANDSCAPE_INTERCEPTION": "LANDSCAPE INTERCEPTION", "MT_LANDSCAPE_RESCUE": "LANDSCAPE RESCUE",
      "MT_LANDSCAPE_SPY": "LANDSCAPE SPY", "MT_LANDSCAPE_CAPTURE": "LANDSCAPE CAPTURE",
      "MT_LANDSCAPE_ASSAULT": "LANDSCAPE ASSAULT", "MT_LANDSCAPE_PURSUIT": "LANDSCAPE PURSUIT",
      "MT_LANDSCAPE_RUSH": "LANDSCAPE RUSH", "MT_LANDSCAPE_DISRUPTION": "LANDSCAPE DISRUPTION",
      "MT_LANDSCAPE_EXCAVATION": "LANDSCAPE EXCAVATION", "MT_LANDSCAPE_DEFECTION": "LANDSCAPE DEFECTION",
      "MT_LANDSCAPE_INFESTED_SALVAGE": "LANDSCAPE INFESTED SALVAGE", "MT_LANDSCAPE_ARENA": "LANDSCAPE ARENA",
      "MT_LANDSCAPE_RACE": "LANDSCAPE RACE", "MT_LANDSCAPE_PARKOUR": "LANDSCAPE PARKOUR",
      "MT_LANDSCAPE_MULTIPLAYER": "LANDSCAPE MULTIPLAYER", "MT_LANDSCAPE_TUTORIAL": "LANDSCAPE TUTORIAL",
      "MT_LANDSCAPE_UNDEFINED": "LANDSCAPE UNDEFINED", "MT_LANDSCAPE_RAILJACK": "LANDSCAPE RAILJACK",
      "MT_CAPTURE_TARGET": "CAPTURE TARGET", "MT_EXTERMINATE": "EXTERMINATE",
      "MT_MONSTER": "MONSTER", "MT_BOSS": "BOSS", "MT_MINIBOSS": "MINIBOSS",
      "MT_STALKER": "STALKER", "MT_GRINEER": "GRINEER", "MT_CORPUS": "CORPUS",
      "MT_INFESTED": "INFESTED", "MT_CORRUPTED": "CORRUPTED", "MT_MURMUR": "MURMUR",
      "MT_NARAMON": "NARAMON", "MT_MADURAI": "MADURAI", "MT_UNAIRU": "UNAIRU",
      "MT_ZENURIK": "ZENURIK", "MT_VAZARIN": "VAZARIN", "MT_PENJAGA": "PENJAGA",
      "MT_AMALGAM": "AMALGAM", "MT_SENTIENT": "SENTIENT", "MT_NIGHTWAVE": "NIGHTWAVE",
      "MT_NIGHTWAVE_EXTERMINATION": "NIGHTWAVE EXTERMINATION", "MT_NIGHTWAVE_SURVIVAL": "NIGHTWAVE SURVIVAL",
      "MT_NIGHTWAVE_DEFENSE": "NIGHTWAVE DEFENSE", "MT_NIGHTWAVE_MOBILE_DEFENSE": "NIGHTWAVE MOBILE DEFENSE",
      "MT_NIGHTWAVE_INTERCEPTION": "NIGHTWAVE INTERCEPTION", "MT_NIGHTWAVE_RESCUE": "NIGHTWAVE RESCUE",
      "MT_NIGHTWAVE_SPY": "NIGHTWAVE SPY", "MT_NIGHTWAVE_CAPTURE": "NIGHTWAVE CAPTURE",
      "MT_NIGHTWAVE_ASSAULT": "NIGHTWAVE ASSAULT", "MT_NIGHTWAVE_PURSUIT": "NIGHTWAVE PURSUIT",
      "MT_NIGHTWAVE_RUSH": "NIGHTWAVE RUSH", "MT_NIGHTWAVE_DISRUPTION": "NIGHTWAVE DISRUPTION",
      "MT_NIGHTWAVE_EXCAVATION": "NIGHTWAVE EXCAVATION", "MT_NIGHTWAVE_DEFECTION": "NIGHTWAVE DEFECTION",
      "MT_NIGHTWAVE_INFESTED_SALVAGE": "NIGHTWAVE INFESTED SALVAGE", "MT_NIGHTWAVE_ARENA": "NIGHTWAVE ARENA",
      "MT_NIGHTWAVE_RACE": "NIGHTWAVE RACE", "MT_NIGHTWAVE_PARKOUR": "NIGHTWAVE PARKOUR",
      "MT_NIGHTWAVE_MULTIPLAYER": "NIGHTWAVE MULTIPLAYER", "MT_NIGHTWAVE_TUTORIAL": "NIGHTWAVE TUTORIAL",
      "MT_NIGHTWAVE_UNDEFINED": "NIGHTWAVE UNDEFINED", "MT_NIGHTWAVE_RAILJACK": "NIGHTWAVE RAILJACK"
    };
    // 英文纪元映射
    const tierEn = { "VoidT1": "Lith", "VoidT2": "Meso", "VoidT3": "Neo", "VoidT4": "Axi", "VoidT5": "Requiem", "VoidT6": "Omnia" };
    
    showList.slice(0, maxShow).forEach(m => {
      const tier = tierEn[m.Modifier || m.ActiveMissionTier] || tierMap[m.Modifier] || "未知";
      const missionType = missionTypeEn[m.MissionType] || wfMissionType(m.MissionType);
      const nodeName = wfNodeName(m.Node);
      const isStorm = type === "storm" || type === "steelstorm";
      const isSteel = m.Hard;
      const expiry = wfOfficialTime(m.Expiry);
      const remaining = wfTimeMs(expiry);
      
      // 从节点名推断阵营
      let faction = "";
      const nodeLower = (m.Node || "").toLowerCase();
      if (nodeLower.includes("grineer") || nodeLower.includes("kuva") || nodeLower.includes("fortress")) faction = "Grineer";
      else if (nodeLower.includes("corpus") || nodeLower.includes("proxima")) faction = "Corpus";
      else if (nodeLower.includes("infested") || nodeLower.includes("deimos") || nodeLower.includes("eris")) faction = "Infested";
      else if (nodeLower.includes("void") || nodeLower.includes("lua")) faction = "Corrupted";
      
      // wfhub.top风格格式：[纪元] [标签] 节点｜任务类型 · 阵营｜剩余时间
      let line = "[" + tier + "] ";
      if (isSteel) line += "[SP] ";
      if (isStorm) line += "[Railjack] ";
      line += nodeName + "｜" + missionType;
      if (faction) line += " · " + faction;
      line += "｜" + remaining;
      msg += line + "\n";
    });
    
    if (showList.length > maxShow) msg += "...等共" + showList.length + "个";
    
    return msg.trim();
  } catch (e) {
    return "虚空裂缝获取失败：" + e.message;
  }
}

// 开放世界赏金任务解析
function parseBounties(ws, syndicateTag) {
  const missions = ws.SyndicateMissions || [];
  const target = missions.find(m => m.Tag === syndicateTag);
  if (!target || !target.Nodes || target.Nodes.length === 0) return [];
  const bounties = [];
  target.Nodes.forEach(node => {
    if (node.Jobs && node.Jobs.length > 0) {
      node.Jobs.forEach(job => {
        bounties.push({
          node: node.Node || "未知",
          levels: job.enemyLevels || [0, 0],
          type: job.type ? job.type.split("/").pop() : "赏金",
          expiry: wfOfficialTime(target.Expiry)
        });
      });
    }
  });
  return bounties;
}

// 开放世界通用格式化
function wfOpenWorld(name, data, bountyKey) {
  if (!data) return `暂无${name}数据`;
  const isDay = data.isDay !== undefined ? data.isDay : data.state === "day";
  const timeState = data.isDay !== undefined ? (isDay ? "白天" : "夜晚") : (data.state || "未知");
  let msg = `🗺️ ${name}\n当前：${timeState}｜剩余${wfTime(data.expiry)}\n\n`;
  const bounties = data[bountyKey] || data.bounties;
  if (Array.isArray(bounties) && bounties.length > 0) {
    msg += "当前赏金：\n";
    bounties.forEach((b, i) => {
      const levels = b.enemyLevels ? `${b.enemyLevels[0]}-${b.enemyLevels[1]}` : "未知";
      const type = b.type ? b.type.replace(/^.*\//, "") : "赏金";
      msg += `${i + 1}. [${levels}级] ${type}\n`;
      if (b.rewardPool && Array.isArray(b.rewardPool)) {
        msg += `   奖励：${b.rewardPool.slice(0, 3).join("、")}${b.rewardPool.length > 3 ? "..." : ""}\n`;
      }
    });
  } else {
    msg += "（当前无赏金任务数据）";
  }
  return msg.trim();
}

// 入侵
async function wfInvasions() {
  try {
    const ws = await wfOfficialGet();
    const invasions = ws.Invasions;
    if (!Array.isArray(invasions) || invasions.length === 0) return "暂无入侵数据";
    const active = invasions.filter((i) => !i.Completed);
    if (active.length === 0) return "暂无进行中的入侵";
    let msg = `⚔️ 进行中的入侵（共${active.length}个）\n\n`;
    active.slice(0, 8).forEach((inv) => {
      const att = WF_FACTION_MAP[inv.Faction] || inv.Faction || "未知";
      const def = WF_FACTION_MAP[inv.DefenderFaction] || inv.DefenderFaction || "未知";
      const count = inv.Count || 0;
      const goal = inv.Goal || 40000;
      const pct = Math.round(Math.abs(count) / goal * 100);
      const leading = count < 0 ? att : def;
      // 简化奖励显示
      const attReward = inv.AttackerReward && inv.AttackerReward.countedItems && inv.AttackerReward.countedItems.length > 0
        ? inv.AttackerReward.countedItems.map((r) => (r.ItemType || "").split("/").pop().replace(/([A-Z])/g, " $1").trim()).join("、")
        : "无";
      const defReward = inv.DefenderReward && inv.DefenderReward.countedItems && inv.DefenderReward.countedItems.length > 0
        ? inv.DefenderReward.countedItems.map((r) => (r.ItemType || "").split("/").pop().replace(/([A-Z])/g, " $1").trim()).join("、")
        : "无";
      // wfhub.top风格卡片格式
      msg += "[入侵] " + wfNodeName(inv.Node) + "｜" + att + "(" + attReward + ") vs " + def + "(" + defReward + ") · 进度" + pct + "%｜" + leading + "领先\n";
    });
    if (active.length > 8) msg += `...等共${active.length}个`;
    return msg.trim();
  } catch (e) {
    return "入侵数据获取失败：" + e.message;
  }
}

// 钢铁之路侵袭
async function wfSteelPath() {
  try {
    const ws = await wfOfficialGet();
    const upgrades = ws.GlobalUpgrades || [];
    const steelUpgrades = upgrades.filter(u => u.Upgrade && u.Upgrade.OperationType === "SteelPath");
    if (steelUpgrades.length === 0) {
      // 尝试从ProjectPct获取钢铁侵袭数据
      const projects = ws.ProjectPct || [];
      const steelProject = projects.find(p => p.Tag && p.Tag.includes("SteelPath"));
      if (steelProject) {
        let msg = "🛡️ 钢铁之路侵袭\n\n";
        msg += "当前目标：" + (steelProject.Faction || "未知") + "\n";
        msg += "进度：" + Math.round((steelProject.Progress || 0) * 100) + "%\n";
        return msg;
      }
      return "🛡️ 暂无钢铁侵袭数据";
    }
    const steel = steelUpgrades[0];
    let msg = "🛡️ 钢铁之路侵袭\n\n";
    msg += "当前：" + (steel.Upgrade.Tag || steel.Tag || "进行中") + "\n";
    if (steel.Expiry) {
      msg += "剩余：" + wfTimeMs(wfOfficialTime(steel.Expiry)) + "\n";
    }
    if (steel.Upgrade && steel.Upgrade.Boost) {
      msg += "加成：" + (steel.Upgrade.Boost * 100) + "%\n";
    }
    return msg;
  } catch (e) {
    return "钢铁侵袭获取失败：" + e.message;
  }
}

// 警报
async function wfAlerts() {
  try {
    const ws = await wfOfficialGet();
    const alerts = ws.Alerts;
    if (!Array.isArray(alerts) || alerts.length === 0) return "暂无警报数据";
    const now = Date.now();
    const active = alerts.filter((a) => {
      const expiry = wfOfficialTime(a.Expiry);
      return expiry && expiry > now;
    });
    if (active.length === 0) return "暂无进行中的警报";
    let msg = `🚨 当前警报（共${active.length}个）\n\n`;
    active.slice(0, 6).forEach((a) => {
      const mi = a.MissionInfo || {};
      const missionType = WF_MISSION_TYPE_MAP[mi.missionType] || mi.missionType || "未知";
      const faction = WF_FACTION_MAP[mi.faction] || mi.faction || "未知";
      const expiry = wfOfficialTime(a.Expiry);
      const rewards = [];
      if (mi.missionReward && mi.missionReward.credits) rewards.push(`${mi.missionReward.credits}现金`);
      if (mi.missionReward && mi.missionReward.countedItems && mi.missionReward.countedItems.length > 0) {
        mi.missionReward.countedItems.forEach((r) => {
          const itemName = wfItemName(r.ItemType);
          if (itemName) rewards.push(`${r.ItemCount || 1}×${itemName}`);
        });
      }
      msg += `📍 ${wfNodeName(mi.location)}\n  ${missionType}｜${faction}\n  等级：${mi.minEnemyLevel || "?"}-${mi.maxEnemyLevel || "?"}\n`;
      if (rewards.length > 0) msg += `  奖励：${rewards.join("、")}\n`;
      msg += `  剩余：${wfTimeMs(expiry)}\n\n`;
    });
    if (active.length > 6) msg += `...等共${active.length}个`;
    return msg.trim();
  } catch (e) {
    return "警报数据获取失败：" + e.message;
  }
}


// 午夜电波/1999日历（使用挑战翻译器，含声望值）
async function wfNightwave() {
  try {
    const ws = await wfOfficialGet();
    const season = ws.SeasonInfo;
    if (!season) return "暂无午夜电波数据";
    const seasonNum = season.Season || "?";
    const phase = season.Phase || 0;
    const expiry = wfOfficialTime(season.Expiry);
    const challenges = season.ActiveChallenges || [];
    
    // 翻译所有挑战并获取声望值
    const parsedChallenges = challenges.map(c => {
      const { title, standing } = translateChallengeWithStanding(c.Challenge || "");
      const cExpiry = wfOfficialTime(c.Expiry);
      return {
        title: title || "未知挑战",
        standing: standing || 0,
        remaining: wfTimeMs(cExpiry),
        isDaily: c.Daily || false
      };
    });
    
    // 按声望值排序（从低到高）
    parsedChallenges.sort((a, b) => a.standing - b.standing);
    
    const dailyChallenges = parsedChallenges.filter(c => c.isDaily);
    const weeklyChallenges = parsedChallenges.filter(c => !c.isDaily);
    
    let msg = "📻 午夜电波（第" + seasonNum + "季 第" + (phase+1) + "阶段）\n";
    msg += "赛季结束：" + wfTimeMs(expiry) + "\n\n";
    
    if (dailyChallenges.length > 0) {
      msg += "【每日挑战】（" + dailyChallenges.length + "个）\n";
      dailyChallenges.forEach((c, i) => {
        msg += (i+1) + ".[声望+" + c.standing + "] " + c.title + "（" + c.remaining + "）\n";
      });
      msg += "\n";
    }
    
    if (weeklyChallenges.length > 0) {
      msg += "【每周挑战】（" + weeklyChallenges.length + "个）\n";
      weeklyChallenges.forEach((c, i) => {
        msg += (i+1) + ".[声望+" + c.standing + "] " + c.title + "（" + c.remaining + "）\n";
      });
    }
    
    if (parsedChallenges.length === 0) {
      msg += "（当前无活跃挑战）";
    }
    
    return msg.trim();
  } catch (e) {
    return "午夜电波获取失败：" + e.message;
  }
}

// 深层科研（从Conquests获取）
async function wfDeepArchimedea() {
  try {
    const ws = await wfOfficialGet();
    const conquests = ws.Conquests || [];
    if (conquests.length === 0) return "暂无深层科研数据";
    // 第一个Conquest是深层科研，第二个是时光科研
    const deep = conquests[0];
    if (!deep) return "暂无深层科研数据";
    const expiry = wfOfficialTime(deep.Expiry);
    const missions = deep.Missions || [];
    const variables = deep.Variables || [];
    
    let msg = "🔬 深层科研（Archimedea）\n";
    msg += "剩余：" + wfTimeMs(expiry) + "\n\n";
    
    if (missions.length > 0) {
      msg += "【任务列表】\n";
      missions.forEach((m, i) => {
        const missionType = WF_MISSION_TYPE_MAP[m] || m || "未知";
        msg += (i+1) + ". " + missionType + "\n";
      });
      msg += "\n";
    }
    
    if (variables.length > 0) {
      msg += "【风险变量】\n";
      variables.forEach((v, i) => {
        const varName = v.split("/").pop().replace(/([A-Z])/g, " $1").trim();
        msg += (i+1) + ". " + varName + "\n";
      });
    }
    
    return msg.trim();
  } catch (e) {
    return "深层科研获取失败：" + e.message;
  }
}

// 时光科研（从Conquests获取）
async function wfNetracells() {
  try {
    const ws = await wfOfficialGet();
    const conquests = ws.Conquests || [];
    if (conquests.length < 2) return "暂无时光科研数据";
    // 第二个Conquest是时光科研
    const temporal = conquests[1];
    if (!temporal) return "暂无时光科研数据";
    const expiry = wfOfficialTime(temporal.Expiry);
    const missions = temporal.Missions || [];
    const variables = temporal.Variables || [];
    
    let msg = "⏳ 时光科研（Temporal Archimedea）\n";
    msg += "剩余：" + wfTimeMs(expiry) + "\n\n";
    
    if (missions.length > 0) {
      msg += "【任务列表】\n";
      missions.forEach((m, i) => {
        const missionType = WF_MISSION_TYPE_MAP[m] || m || "未知";
        msg += (i+1) + ". " + missionType + "\n";
      });
      msg += "\n";
    }
    
    if (variables.length > 0) {
      msg += "【风险变量】\n";
      variables.forEach((v, i) => {
        const varName = v.split("/").pop().replace(/([A-Z])/g, " $1").trim();
        msg += (i+1) + ". " + varName + "\n";
      });
    }
    
    return msg.trim();
  } catch (e) {
    return "时光科研获取失败：" + e.message;
  }
}


// 无尽回廊
async function wfDescents() {
  try {
    const ws = await wfOfficialGet();
    const descents = ws.Descents || [];
    if (descents.length === 0) return "暂无无尽回廊数据";
    
    let msg = "🏰 无尽回廊（The Duviri Paradox）\n\n";
    
    descents.forEach((d, i) => {
      const expiry = wfOfficialTime(d.Expiry);
      const challenges = d.Challenges || [];
      msg += "【第" + (i+1) + "层】剩余：" + wfTimeMs(expiry) + "\n";
      if (challenges.length > 0) {
        challenges.forEach((c, j) => {
          const challengeName = (c || "").split("/").pop().replace(/([A-Z])/g, " $1").trim();
          msg += "  " + (j+1) + ". " + challengeName + "\n";
        });
      }
      msg += "\n";
    });
    
    return msg.trim();
  } catch (e) {
    return "无尽回廊获取失败：" + e.message;
  }
}

// 平原时间计算（根据游戏时间规则）
// 地球/夜灵平野：150分钟白天 + 100分钟夜晚 = 250分钟周期
function calcCetusCycle() {
  const now = Date.now();
  const cycleLength = 250 * 60 * 1000;
  const dayLength = 150 * 60 * 1000;
  const baseTime = Date.UTC(2022, 0, 1, 0, 0, 0);
  const elapsed = (now - baseTime) % cycleLength;
  const isDay = elapsed < dayLength;
  const remaining = isDay ? (dayLength - elapsed) : (cycleLength - elapsed);
  return { isDay, state: isDay ? "白天" : "夜晚", remaining, nextState: isDay ? "夜晚" : "白天" };
}

// 奥布山谷：6.5分钟温暖 + 16.5分钟寒冷 = 23分钟周期
function calcOrbVallisCycle() {
  const now = Date.now();
  const cycleLength = 23 * 60 * 1000;
  const warmLength = 6.5 * 60 * 1000;
  const baseTime = Date.UTC(2022, 0, 1, 0, 0, 0);
  const elapsed = (now - baseTime) % cycleLength;
  const isWarm = elapsed < warmLength;
  const remaining = isWarm ? (warmLength - elapsed) : (cycleLength - elapsed);
  return { isWarm, state: isWarm ? "温暖" : "寒冷", remaining, nextState: isWarm ? "寒冷" : "温暖" };
}

// 魔胎之境：100分钟Fass + 100分钟Vome = 200分钟周期
function calcCambionDriftCycle() {
  const now = Date.now();
  const cycleLength = 200 * 60 * 1000;
  const fassLength = 100 * 60 * 1000;
  const baseTime = Date.UTC(2022, 0, 1, 0, 0, 0);
  const elapsed = (now - baseTime) % cycleLength;
  const isFass = elapsed < fassLength;
  const remaining = isFass ? (fassLength - elapsed) : (cycleLength - elapsed);
  return { isFass, state: isFass ? "Fass（混乱）" : "Vome（秩序）", remaining, nextState: isFass ? "Vome" : "Fass" };
}

function formatRemaining(ms) {
  if (ms <= 0) return "即将切换";
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  if (h > 0) return h + "小时" + m + "分";
  if (m > 0) return m + "分" + s + "秒";
  return s + "秒";
}

// 平原时间
async function wfPlainsTime() {
  try {
    const cetus = calcCetusCycle();
    const orb = calcOrbVallisCycle();
    const cambion = calcCambionDriftCycle();
    let msg = "🌍 开放世界时间\n\n";
    msg += "【地球·夜灵平野】\n当前：" + cetus.state + "\n距离" + cetus.nextState + "：" + formatRemaining(cetus.remaining) + "\n\n";
    msg += "【金星·奥布山谷】\n当前：" + orb.state + "\n距离" + orb.nextState + "：" + formatRemaining(orb.remaining) + "\n\n";
    msg += "【火卫二·魔胎之境】\n当前：" + cambion.state + "\n距离" + cambion.nextState + "：" + formatRemaining(cambion.remaining);
    return msg;
  } catch (e) {
    return "平原时间获取失败：" + e.message;
  }
}

// Warframe Market v2 API - 物品列表缓存（24小时）
let marketItemsCache = null;
let marketItemsCacheTime = 0;
const MARKET_ITEMS_CACHE_TTL = 24 * 60 * 60 * 1000;

async function getMarketItems() {
  const now = Date.now();
  if (marketItemsCache && (now - marketItemsCacheTime) < MARKET_ITEMS_CACHE_TTL) {
    return marketItemsCache;
  }
  const marketHeaders = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Language": "zh-hans",
    "Platform": "pc"
  };
  const data = await httpGet("https://api.warframe.market/v2/items", 15000, marketHeaders);
  marketItemsCache = data && data.data ? data.data : [];
  marketItemsCacheTime = now;
  return marketItemsCache;
}

// Warframe Market 查询（v2 API）
async function wfMarket(keyword) {
  const cacheKey = `wfmarket:${keyword.toLowerCase()}`;
  const cached = cacheGet(cacheKey);
  if (cached) return cached;
  
  // 别名转换：把玩家俗称/中文名转换成url_name
  const originalName = keyword;
  if (WF_WM_ALIASES[keyword]) {
    keyword = WF_WM_ALIASES[keyword];
    addLog("info", `[WM别名] ${originalName} -> ${keyword}`);
  } else {
    // 尝试模糊匹配（不区分大小写）
    const lowerName = keyword.toLowerCase();
    for (const [alias, urlName] of Object.entries(WF_WM_ALIASES)) {
      if (alias.toLowerCase() === lowerName) {
        keyword = urlName;
        addLog("info", `[WM别名] ${originalName} -> ${keyword}`);
        break;
      }
    }
  }
  
  const marketHeaders = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Language": "zh-hans",
    "Platform": "pc"
  };
  try {
    // 1. 获取物品列表并本地搜索
    const items = await getMarketItems();
    const kw = keyword.toLowerCase();
    
    // v2 API的物品名在 i18n["zh-hans"].name 里
    const matches = items.filter((item) => {
      const zhName = item.i18n && item.i18n["zh-hans"] ? item.i18n["zh-hans"].name : "";
      const enName = item.i18n && item.i18n.en ? item.i18n.en.name : "";
      const slug = item.slug || "";
      return zhName.toLowerCase().includes(kw) || 
             enName.toLowerCase().includes(kw) || 
             slug.toLowerCase().includes(kw);
    });
    
    if (matches.length === 0) return `未找到"${originalName}"相关物品`;
    
    // 取最匹配的（优先完全匹配slug，其次名称最短的）
    matches.sort((a, b) => {
      const aExact = (a.slug === keyword) ? 0 : 1;
      const bExact = (b.slug === keyword) ? 0 : 1;
      if (aExact !== bExact) return aExact - bExact;
      const na = (a.i18n?.["zh-hans"]?.name || a.i18n?.en?.name || a.slug || "").length;
      const nb = (b.i18n?.["zh-hans"]?.name || b.i18n?.en?.name || b.slug || "").length;
      return na - nb;
    });
    
    const item = matches[0];
    const itemName = item.i18n?.["zh-hans"]?.name || item.i18n?.en?.name || item.slug;
    const itemSlug = item.slug;
    
    // 2. 查询最优订单
    const ordersUrl = `https://api.warframe.market/v2/orders/item/${itemSlug}/top`;
    const ordersData = await httpGet(ordersUrl, 10000, marketHeaders);
    const orderData = ordersData && ordersData.data ? ordersData.data : {};
    const sellOrders = orderData.sell || [];
    const buyOrders = orderData.buy || [];
    
    // 详细表格格式显示
    let msg = `💰 Warframe Market\n物品：${itemName}\n`;
    msg += `英文：${itemSlug}\n\n`;
    
    // 卖家列表
    if (sellOrders.length > 0) {
      msg += `【卖家】（共${sellOrders.length}条）\n`;
      msg += `卖家名            信誉  数量  价格\n`;
      msg += `────────────────────────────\n`;
      sellOrders.slice(0, 8).forEach(o => {
        const name = o.user ? (o.user.ingameName || "未知") : "未知";
        const rep = o.user ? (o.user.reputation || 0) : 0;
        const qty = o.quantity || 1;
        const price = o.platinum || 0;
        const status = o.user?.status === "ingame" ? "🎮" : o.user?.status === "online" ? "💚" : "⚪";
        // 格式化对齐
        const namePad = name.padEnd(16, " ");
        const repPad = String(rep).padStart(4, " ");
        const qtyPad = String(qty).padStart(4, " ");
        const pricePad = String(price).padStart(4, " ");
        msg += `${status}${namePad}${repPad}${qtyPad}${pricePad}白金\n`;
      });
      if (sellOrders.length > 8) msg += `...还有${sellOrders.length - 8}条\n`;
      msg += "\n";
    }
    
    // 买家列表
    if (buyOrders.length > 0) {
      msg += `【买家】（共${buyOrders.length}条）\n`;
      msg += `买家名            信誉  数量  价格\n`;
      msg += `────────────────────────────\n`;
      buyOrders.slice(0, 6).forEach(o => {
        const name = o.user ? (o.user.ingameName || "未知") : "未知";
        const rep = o.user ? (o.user.reputation || 0) : 0;
        const qty = o.quantity || 1;
        const price = o.platinum || 0;
        const status = o.user?.status === "ingame" ? "🎮" : o.user?.status === "online" ? "💚" : "⚪";
        const namePad = name.padEnd(16, " ");
        const repPad = String(rep).padStart(4, " ");
        const qtyPad = String(qty).padStart(4, " ");
        const pricePad = String(price).padStart(4, " ");
        msg += `${status}${namePad}${repPad}${qtyPad}${pricePad}白金\n`;
      });
      if (buyOrders.length > 6) msg += `...还有${buyOrders.length - 6}条\n`;
    }
    
    msg += `\n共${sellOrders.length + buyOrders.length}条在线订单（卖家${sellOrders.length}，买家${buyOrders.length}）`;
    
    cacheSet(cacheKey, msg, 30000);
    return msg;
  } catch (e) {
    return "Market 查询失败：" + e.message;
  }
}

// Warframe 指令分发
async function handleWarframeCommand(rawMsg, groupId) {
  let msg = rawMsg.trim();
  // 超级小莲风格 WF 功能
  try {
    // WF别名处理
    try {
      const wfAliases = (currentConfig && currentConfig.wfAliases) || {};
      const aliasKeys = Object.keys(wfAliases);
      for (const alias of aliasKeys) {
        const standardCmd = wfAliases[alias];
        if (msg === alias || msg.startsWith(alias + " ")) {
          const params = msg.substring(alias.length).trim();
          msg = standardCmd + (params ? " " + params : "");
          addLog("info", `[WF别名] ${alias} -> ${standardCmd}`);
          break;
        }
      }
    } catch (e) {}
    
    // 超级小莲风格指令
    if (msg === "#全部" || msg === "#all" || msg === "全部" || msg === "all") return await superlotusWF.getAllStatus();
    if (msg === "#平原" || msg === "#平原时间" || msg === "#时间" || msg === "平原" || msg === "平原时间" || msg === "时间") return superlotusWF.getPlainsTime();
    if (msg === "#裂缝" || msg === "#普通裂缝" || msg === "#虚空裂缝" || msg === "#fissure" || msg === "裂缝" || msg === "普通裂缝" || msg === "虚空裂缝" || msg === "fissure") return await superlotusWF.getFissures("normal");
    if (msg === "#钢铁裂缝" || msg === "#钢裂" || msg === "#steel fissure" || msg === "钢铁裂缝" || msg === "钢裂" || msg === "steel fissure") return await superlotusWF.getFissures("steel");
    if (msg === "#虚空风暴" || msg === "#风暴" || msg === "#storm" || msg === "虚空风暴" || msg === "风暴" || msg === "storm") return await superlotusWF.getFissures("storm");
    if (msg === "#钢铁风暴" || msg === "#钢风暴" || msg === "钢铁风暴" || msg === "钢风暴") return await superlotusWF.getFissures("steelstorm");
    if (msg === "#突击" || msg === "#sortie" || msg === "突击" || msg === "sortie") return await superlotusWF.getSorties();
    if (msg === "#警报" || msg === "#alert" || msg === "警报" || msg === "alert") return await superlotusWF.getAlerts();
    if (msg === "#入侵" || msg === "#invasion" || msg === "入侵" || msg === "invasion") return await superlotusWF.getInvasions();
    if (msg === "#钢铁侵袭" || msg === "#钢铁之路" || msg === "#steelpath" || msg === "钢铁侵袭" || msg === "钢铁之路" || msg === "steelpath") return await superlotusWF.getSteelPath();
    if (msg === "#电波" || msg === "#午夜电波" || msg === "#nightwave" || msg === "#nw" || msg === "电波" || msg === "午夜电波" || msg === "nightwave" || msg === "nw") return await superlotusWF.getNightwave();
    if (msg === "#商人" || msg === "#虚空商人" || msg === "#baro" || msg === "#voidtrader" || msg === "商人" || msg === "虚空商人" || msg === "baro" || msg === "voidtrader") return await superlotusWF.getVoidTrader();
    if (msg === "#Darvo" || msg === "#darvo" || msg === "#每日特惠" || msg === "#特惠" || msg === "Darvo" || msg === "darvo" || msg === "每日特惠" || msg === "特惠") return await superlotusWF.getDarvoDeals();
    if (msg === "#回廊" || msg === "#无尽回廊" || msg === "#duviri" || msg === "#descents" || msg === "回廊" || msg === "无尽回廊" || msg === "duviri" || msg === "descents") return await superlotusWF.getDescents();
    if (msg === "#深层科研" || msg === "#深岩" || msg === "#archimedea" || msg === "深层科研" || msg === "深岩" || msg === "archimedea") return await superlotusWF.getDeepArchimedea();
    if (msg === "#时光科研" || msg === "#网件" || msg === "#temporal" || msg === "时光科研" || msg === "网件" || msg === "temporal") return await superlotusWF.getTemporalArchimedea();
    // 精英科研（支持#前缀和无前缀）
    if (msg === "#精英科研" || msg === "#精英" || msg === "#elite" || msg === "#elitearchimedea" ||
        msg === "精英科研" || msg === "精英" || msg === "elite" || msg === "elitearchimedea") return await superlotusWF.getEliteArchimedea();
    // Kahl任务（支持#前缀和无前缀）
    if (msg === "#kahl" || msg === "#Kahl" || msg === "#卡尔" || msg === "#kahl任务" ||
        msg === "kahl" || msg === "Kahl" || msg === "卡尔" || msg === "kahl任务") return await superlotusWF.getKahlMissions();
    // 赏金任务（支持#前缀和无前缀）
    if (msg === "#赏金" || msg === "#bounty" || msg === "#赏金任务" ||
        msg === "赏金" || msg === "bounty" || msg === "赏金任务") return await superlotusWF.getBounties();
    // 1999日历（支持#前缀和无前缀）
    if (msg === "#日历" || msg === "#1999" || msg === "#calendar" || msg === "#1999日历" ||
        msg === "日历" || msg === "1999" || msg === "calendar" || msg === "1999日历") return await superlotusWF.getCalendar1999();
    // 仲裁任务（支持#前缀和无前缀）
    if (msg === "#仲裁" || msg === "#arbitration" || msg === "#仲裁任务" ||
        msg === "仲裁" || msg === "arbitration" || msg === "仲裁任务") return await superlotusWF.getArbitration();
    // 紫卡查询（支持#前缀和无前缀）
    if (msg.startsWith("#紫卡") || msg.startsWith("#riven") || msg.startsWith("#紫卡查询") ||
        msg.startsWith("紫卡") || msg.startsWith("riven") || msg.startsWith("紫卡查询")) {
      const kw = msg.replace(/^#?(紫卡|riven|紫卡查询)\s*/, "").trim();
      if (!kw) return "用法：紫卡 武器名（如 紫卡 绝路）";
      const isZeroRoll = kw.includes("0洗") || kw.includes("零洗");
      const weapon = kw.replace(/0洗|零洗/g, "").trim();
      return await superlotusWF.queryRiven(weapon, isZeroRoll);
    }

    if (msg === "#wf帮助" || msg === "#warframe" || msg === "#wfhelp" || msg === "wf帮助" || msg === "warframe" || msg === "wfhelp") return superlotusWF.getHelp();
    
    // 裂缝订阅功能（支持#前缀和无前缀）
    if (msg.startsWith("#订阅裂缝") || msg.startsWith("#订阅") || 
        msg.startsWith("订阅裂缝 ") || msg.startsWith("订阅 ")) {
      const era = msg.replace(/^#?(订阅裂缝|订阅)\s*/, "").trim();
      return superlotusWF.subscribeFissure(String(data.group_id), String(data.user_id), era);
    }
    if (msg.startsWith("#取消订阅") || msg.startsWith("#取消") ||
        msg.startsWith("取消订阅 ") || msg.startsWith("取消 ")) {
      const era = msg.replace(/^#?(取消订阅|取消)\s*/, "").trim();
      return superlotusWF.unsubscribeFissure(String(data.group_id), String(data.user_id), era);
    }
    if (msg === "#我的订阅" || msg === "#订阅列表" || msg === "我的订阅" || msg === "订阅列表") {
      return superlotusWF.getMySubscriptions(String(data.group_id), String(data.user_id));
    }
    
    // WM市场查询（支持#前缀和无前缀）
    if (msg.startsWith("#wm") || msg.startsWith("#market") || msg.startsWith("#市场") ||
        msg.startsWith("wm ") || msg.startsWith("market ") || msg.startsWith("市场 ")) {
      const kw = msg.replace(/^#?(wm|market|市场)\s*/, "").trim();
      if (!kw) return "用法：wm 物品名（如 wm 狂战士）";
      return await superlotusWF.queryMarket(kw);
    }
    
    // 市场分析（支持#前缀和无前缀）
    if (msg.startsWith("#市场分析") || msg.startsWith("#分析") || msg.startsWith("#marketanaly") ||
        msg.startsWith("市场分析 ") || msg.startsWith("分析 ") || msg.startsWith("marketanaly ")) {
      const kw = msg.replace(/^#?(市场分析|分析|marketanaly)\s*/, "").trim();
      if (!kw) return "用法：市场分析 物品名（如 市场分析 狂战士）";
      return await superlotusWF.analyzeMarket(kw);
    }
    
    return null;
  } catch (e) {
    return "Warframe 查询失败: " + e.message;
  }
}

// ==================== OneBot 事件处理 ====================
function handleOneBotEvent(data) {
  if (data.echo && actionCallbacks.has(data.echo)) {
    const cb = actionCallbacks.get(data.echo);
    actionCallbacks.delete(data.echo);
    cb(data);
    return;
  }

  if (data.post_type === "meta_event") {
    if (data.meta_event_type === "lifecycle" && data.sub_type === "connect") {
      sendAction("get_login_info", {}, (resp) => {
        if (resp && resp.data) {
          botQQ = resp.data.user_id;
          addLog("success", `机器人登录: ${resp.data.nickname} (${botQQ})`);
          updateStatus("connected");
        }
      });
    }
    return;
  }

  const cfg = currentConfig;

  if (data.post_type === "notice" && data.notice_type === "group_increase") {
    if (isFeatureEnabled(data.group_id, "welcome")) handleGroupIncrease(data, cfg);
    return;
  }

  if (data.post_type === "notice" && data.notice_type === "group_decrease") {
    if (isFeatureEnabled(data.group_id, "leaveNotice")) handleGroupDecrease(data, cfg);
    return;
  }

  if (data.post_type === "message" && data.message_type === "group") {
    handleGroupMessage(data, cfg);
    return;
  }
}

// ==================== 入群欢迎 ====================
function handleGroupIncrease(data, cfg) {
  if (botQQ && data.user_id === botQQ) return;
  const groupId = data.group_id;
  const userId = data.user_id;
  // 防重复：10秒内同一用户入群只欢迎一次
  const cacheKey = `${groupId}_${userId}`;
  if (welcomeCache.has(cacheKey)) return;
  welcomeCache.add(cacheKey);
  setTimeout(() => welcomeCache.delete(cacheKey), 10000);
  
  // 先从事件数据里尝试获取昵称
  let eventNick = "";
  if (data.sender && data.sender.nickname) eventNick = data.sender.nickname;
  else if (data.sender && data.sender.card) eventNick = data.sender.card;
  else if (data.nickname) eventNick = data.nickname;
  else if (data.card) eventNick = data.card;
  
  let welcomeSent = false;
  const sendWelcome = (nick, groupName) => {
    if (welcomeSent) return;
    welcomeSent = true;
    // 只显示昵称，不显示QQ号；如果获取不到昵称，显示"新成员"
    const displayName = nick && nick !== String(userId) && nick.trim() !== "" ? nick : "新成员";
    sendWelcomeMessage(groupId, userId, displayName, groupName || "本群", cfg.welcome.message);
    addLog("info", `[入群欢迎] 群${groupId} 欢迎 ${displayName}(${userId})`);
  };
  
  // 8秒超时保护
  const timeout = setTimeout(() => {
    if (eventNick) sendWelcome(eventNick, "本群");
    else sendWelcome("新成员", "本群");
  }, 8000);
  
  // 第一步：获取群信息
  sendAction("get_group_info", { group_id: groupId }, (groupResp) => {
    const groupName = (groupResp && groupResp.data && groupResp.data.group_name) || "本群";
    addLog("info", `[入群欢迎] 群信息: ${JSON.stringify(groupResp?.data || {})}`);
    
    // 第二步：获取群成员信息
    sendAction("get_group_member_info", { group_id: groupId, user_id: userId }, (memberResp) => {
      addLog("info", `[入群欢迎] 群成员信息返回: retcode=${memberResp?.retcode} status=${memberResp?.status} data=${JSON.stringify(memberResp?.data || {})}`);
      
      if (memberResp && memberResp.data && (memberResp.data.card || memberResp.data.nickname || memberResp.data.name)) {
        clearTimeout(timeout);
        const nick = memberResp.data.card || memberResp.data.nickname || memberResp.data.name;
        sendWelcome(nick, groupName);
      } else {
        // 群成员信息获取失败，尝试获取陌生人信息
        addLog("info", "[入群欢迎] 群成员信息无昵称，尝试get_stranger_info");
        sendAction("get_stranger_info", { user_id: userId, no_cache: true }, (strangerResp) => {
          clearTimeout(timeout);
          addLog("info", `[入群欢迎] 陌生人信息返回: ${JSON.stringify(strangerResp?.data || {})}`);
          if (strangerResp && strangerResp.data && strangerResp.data.nickname) {
            sendWelcome(strangerResp.data.nickname, groupName);
          } else if (eventNick) {
            sendWelcome(eventNick, groupName);
          } else {
            sendWelcome("新成员", groupName);
          }
        });
      }
    });
  });
}

// 处理base64图片，转换为OneBot可用的格式
function processWelcomeImage(imageData) {
  if (!imageData) return null;
  // 如果是base64 data URL格式（data:image/png;base64,xxx）
  if (imageData.startsWith("data:image")) {
    const base64Data = imageData.split(",")[1];
    return "base64://" + base64Data;
  }
  // 如果已经是base64://格式
  if (imageData.startsWith("base64://")) {
    return imageData;
  }
  // 如果是URL或本地路径，直接返回
  return imageData;
}

// 提取纯base64数据（去掉前缀），用于官方API上传
function extractPureBase64(imageData) {
  if (!imageData) return null;
  if (imageData.startsWith("data:image")) {
    return imageData.split(",")[1];
  }
  if (imageData.startsWith("base64://")) {
    return imageData.substring(9);
  }
  return imageData;
}

function sendWelcomeMessage(groupId, userId, nick, groupName, template) {
  let msg = template.replace(/{nick}/g, String(nick)).replace(/{qq}/g, String(nick)).replace(/{group}/g, String(groupName));
  const welcomeCfg = currentConfig.welcome || {};
  const welcomeImage = welcomeCfg.image || "";
  const welcomeButtons = welcomeCfg.buttons || [];
  const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
  const groupIdMap = (currentConfig.dualMode && currentConfig.dualMode.groupIdMap) || {};
  const groupOpenId = dualEnabled ? groupIdMap[String(groupId)] : null;
  
  // 双模式 + 有groupOpenId：用官方Markdown（文本+URL图片+底部按钮，全部同气泡）
  if (dualEnabled && groupOpenId) {
    (async () => {
      try {
        let md = msg;
        // URL图片直接嵌入Markdown
        if (welcomeImage && (welcomeImage.startsWith("http://") || welcomeImage.startsWith("https://"))) {
          md += "\n\n![欢迎图 #600px #400px](" + welcomeImage + ")";
        }
        
        // 构造底部按钮
        let keyboard = null;
        if (welcomeButtons && welcomeButtons.length > 0) {
          const rows = [];
          for (let i = 0; i < welcomeButtons.length; i += 3) {
            const rowButtons = [];
            for (let j = i; j < Math.min(i + 3, welcomeButtons.length); j++) {
              const btn = welcomeButtons[j];
              const btnData = (btn.data || "").replace(/{nick}/g, String(nick)).replace(/{qq}/g, String(nick)).replace(/{group}/g, String(groupName));
              const btnLabel = (btn.label || "按钮").replace(/{nick}/g, String(nick)).replace(/{qq}/g, String(nick)).replace(/{group}/g, String(groupName));
              let actionType = 2;
              if (btn.type === "link") actionType = 0;
              rowButtons.push({
                id: "welcome_btn_" + j,
                render_data: { label: btnLabel, visited_label: "已点击", style: btn.style || 1 },
                action: { type: actionType, data: btnData, permission: { type: 2 }, unsupport_tips: "客户端不支持" }
              });
            }
            rows.push({ buttons: rowButtons });
          }
          keyboard = { content: { rows: rows } };
        }
        
        // 官方发送（内部已有3次重试 + token自动刷新）
        await officialBot.sendOfficialMarkdownMessage(groupOpenId, md, keyboard);
        addLog("success", "[入群欢迎] 官方发送成功（文本+图片+按钮同气泡） 群" + groupId + " 用户" + nick);
      } catch (e) {
        addLog("error", "[入群欢迎] 官方发送失败（已重试3次） 群" + groupId + ": " + e.message);
        addLog("info", "[入群欢迎] 请检查：1.群openid映射是否正确 2.官方机器人是否在群内 3.网络是否正常");
      }
    })();
  } else {
    // 非双模式或无groupOpenId：用OneBot发送
    const messageSegments = [{ type: "text", data: { text: msg + (welcomeImage ? "\n\n" : "") } }];
    if (welcomeImage) messageSegments.push({ type: "image", data: { file: welcomeImage } });
    // 按钮转文本
    if (welcomeButtons && welcomeButtons.length > 0) {
      let btnText = "\n\n";
      welcomeButtons.forEach((btn) => {
        const btnLabel = (btn.label || "按钮").replace(/{nick}/g, String(nick)).replace(/{qq}/g, String(nick)).replace(/{group}/g, String(groupName));
        const btnData = (btn.data || "").replace(/{nick}/g, String(nick)).replace(/{qq}/g, String(nick)).replace(/{group}/g, String(groupName));
        if (btn.type === "link") btnText += `🔗 ${btnLabel}: ${btnData}\n`;
        else if (btn.type === "copy") btnText += `📋 ${btnLabel}: ${btnData}\n`;
        else btnText += `⚡ ${btnLabel}: 发送 ${btnData}\n`;
      });
      messageSegments.push({ type: "text", data: { text: btnText } });
    }
    sendAction("send_group_msg", { group_id: groupId, message: messageSegments }, (resp) => {
      if (resp && resp.error) addLog("warn", `[入群欢迎] 发送失败 群${groupId}: ${resp.error}`);
      else addLog("success", `[入群欢迎] OneBot发送成功 群${groupId}`);
    });
  }
}

// ==================== 退群提醒 ====================
function handleGroupDecrease(data, cfg) {
  if (botQQ && data.user_id === botQQ) return;
  const msg = cfg.leaveNotice.message
    .replace(/{nick}/g, String(data.user_id))
    .replace(/{qq}/g, String(data.user_id));
  sendGroupMessage(data.group_id, msg);
  addLog("info", `[退群提醒] 群${data.group_id} ${data.user_id} 退群`);
}

// ==================== 群消息处理 ====================
// 消息去重缓存，防止双模式下同一条消息被重复处理
const _messageDedupCache = new Map();
const DEDUP_CACHE_SIZE = 200;
const DEDUP_EXPIRE_TIME = 60000; // 60秒

function isDuplicateMessage(userId, groupId, messageText) {
  const key = userId + "_" + groupId + "_" + messageText.substring(0, 100);
  const now = Date.now();
  
  // 清理过期缓存
  for (const [k, v] of _messageDedupCache) {
    if (now - v > DEDUP_EXPIRE_TIME) {
      _messageDedupCache.delete(k);
    }
  }
  
  if (_messageDedupCache.has(key)) {
    return true;
  }
  
  _messageDedupCache.set(key, now);
  
  // 限制缓存大小
  if (_messageDedupCache.size > DEDUP_CACHE_SIZE) {
    const firstKey = _messageDedupCache.keys().next().value;
    _messageDedupCache.delete(firstKey);
  }
  
  return false;
}

async function handleGroupMessage(data, cfg) {
  // 消息去重检查（防止双模式下同一条消息被重复处理）
  try {
    const userId = data.user_id || (data.sender && data.sender.user_id) || "";
    const groupId = data.group_id || "";
    let messageText = "";
    if (typeof data.message === "string") {
      messageText = data.message;
    } else if (Array.isArray(data.message)) {
      messageText = data.message.map(m => m.type === "text" ? (m.data && m.data.text || "") : "").join("");
    } else if (data.raw_message) {
      messageText = data.raw_message;
    }
    if (userId && groupId && messageText && isDuplicateMessage(userId, groupId, messageText)) {
      addLog("info", "[去重] 忽略重复消息 群" + groupId + " 用户" + userId);
      return;
    }
  } catch (e) {
    // 去重检查失败不影响正常处理
  }

  // ========== 系统设置检查 ==========
  const sys = currentConfig.system || {};
  
  // 全局开关检查
  if (sys.globalEnabled === false) {
    return;
  }
  
  // 群黑名单检查
  const _sysGroupId = String(data.group_id || "");
  if (sys.groupBlacklist && sys.groupBlacklist.includes(_sysGroupId)) {
    return;
  }
  
  // 用户黑名单检查
  const _sysUserId = String(data.user_id || "");
  if (sys.userBlacklist && sys.userBlacklist.includes(_sysUserId)) {
    return;
  }
  
  // 防刷屏检查（管理员豁免）
  const _isAdmin = sys.adminList && sys.adminList.includes(_sysUserId);
  if (!_isAdmin && sys.antiSpam && sys.antiSpam > 0) {
    const now = Date.now();
    if (!global.lastReplyTime) global.lastReplyTime = {};
    const lastTime = global.lastReplyTime[_sysUserId] || 0;
    if (now - lastTime < sys.antiSpam * 1000) {
      return;
    }
    global.lastReplyTime[_sysUserId] = now;
  }
  
  // 管理员标记
  data.isAdmin = _isAdmin;
  

  const rawMsg = (data.raw_message || "").trim();
  const groupId = data.group_id;
  const userId = data.user_id;
  const sender = data.sender || {};
  const isAdmin = sender.role === "owner" || sender.role === "admin";
  const messageArray = data.message || [];
  const atUsers = messageArray.filter((m) => m.type === "at").map((m) => m.data.qq);


  
  // ========== 修仙功能 ==========
  const isXiuxianCommand = (() => {
    const checkMsg = rawMsg.startsWith("#") ? rawMsg.substring(1) : rawMsg;
    const xiuxianKeywords = ["修仙", "修仙帮助", "修仙指令", "修仙菜单", "创建", "注册", "创建角色", "加入修仙", "我的角色", "角色信息", "信息", "状态", "修炼", "闭关", "开始修炼", "停止修炼", "结算修炼", "出关", "结束修炼", "修炼状态", "突破", "突破境界", "炼体突破", "背包", "纳戒", "我的背包", "装备", "我的装备", "穿戴", "卸下", "使用", "吃药", "使用丹药", "打怪", "战斗", "历练", "刷怪", "切磋", "恢复", "回血", "商店", "商城", "购买", "出售", "签到", "每日签到", "排行榜", "排行", "战力榜", "财富榜", "炼丹", "炼丹配方", "丹方", "锻造", "锻造配方", "锻造图", "强化", "捕捉仙宠", "抓宠", "喂养", "我的仙宠", "仙宠", "仙宠信息", "释放仙宠", "创建宗门", "加入宗门", "退出宗门", "宗门信息", "我的宗门", "宗门列表", "宗门捐赠", "宗门升级", "怪物列表", "丹药列表", "仙宠列表", "镇妖塔", "爬塔", "挑战塔", "每日任务", "任务", "领取任务", "职业列表", "转职", "功法列表", "我的功法", "赌大小", "赌单双", "存款", "取款", "钱庄", "我的存款", "聚宝堂", "交易市场", "上架", "购买市场", "赠送", "拜师", "收徒", "拒绝拜师", "申请列表", "出师", "逐出师门", "背叛师门", "离开师门", "师徒信息", "我的师父", "师徒任务", "求婚", "结婚", "结为道侣", "同意求婚", "同意结婚", "拒绝求婚", "拒绝结婚", "求婚申请", "结婚申请", "夫妻互动", "互动", "双修", "送礼", "婚姻信息", "我的配偶", "配偶", "离婚", "和离", "轮回", "开始轮回", "轮回信息", "我的轮回", "轮回属性", "轮回说明"];
    for (const kw of xiuxianKeywords) {
      if (checkMsg === kw || checkMsg.startsWith(kw + " ")) return true;
    }
    return false;
  })();
  
  if (isXiuxianCommand && isFeatureEnabled(groupId, "xiuxian")) {
    try {
      const checkMsg = rawMsg.startsWith("#") ? rawMsg.substring(1) : rawMsg;
      
      // 处理切磋指令（需要@目标）
      let targetQq = null;
      if (checkMsg.startsWith("切磋 ") && atUsers.length > 0) {
        targetQq = atUsers[0];
      }
      
      const result = xiuxian.handleCommand(checkMsg, String(userId), sender.nickname || "玩家", "", targetQq);
      
      // 调试日志
      addLog("info", `[修仙] 指令结果 type=${result.type} success=${result.success} message长度=${(result.message || "").length}`);
      
      // 根据结果类型发送消息
      if (result.type === 'help') {
        // 修仙帮助：根据helpType生成不同的帮助图片
        try {
          let helpText = result.message || '';
          const helpType = result.helpType || 'simple';
          
          // 完整帮助底部加提示
          if (helpType === 'full') {
            helpText += '\n\n💡 发送 修仙帮助 查看精简版指令';
          }
          
          const helpImgBuf = superlotusImage.convertSimple(helpText, "修仙帮助", null, true);
          await sendGroupImage(groupId, helpImgBuf);
        } catch (e) {
          addLog("warn", "[修仙] 帮助图片生成失败，降级为文字: " + e.message);
          if (result.message) sendGroupMessage(groupId, result.message);
        }
      } else if (result.type === 'info' || result.type === 'create' || result.type === 'error') {
        if (result.message) {
          sendGroupMessage(groupId, result.message);
        } else {
          addLog("warn", `[修仙] 结果message为空，type=${result.type}`);
        }
      } else if (result.type === 'playerinfo' && result.info) {
        // 角色信息用图片发送
        try {
          const info = result.info;
          let text = `【角色信息】\n\n`;
          text += `道号：${info.nickname}\n`;
          text += `境界：${info.realm?.name || '未知'} ${info.realmLevel}层\n`;
          text += `修为：${info.exp} / ${info.expNeeded} (${info.expPercent.toFixed(1)}%)\n`;
          text += `灵根：${info.linggen?.attribute}（${info.linggen?.type}）\n`;
          text += `修炼效率：${info.linggen?.eff}x\n\n`;
          text += `攻击：${info.atk}\n`;
          text += `防御：${info.def}\n`;
          text += `生命：${info.hp}/${info.maxHp}\n`;
          text += `暴击率：${(info.critRate * 100).toFixed(0)}%\n`;
          text += `暴击伤害：${(info.critDamage * 100).toFixed(0)}%\n\n`;
          text += `灵石：${info.gold}\n`;
          text += `战力：${info.power}\n`;
          text += `背包：${info.inventoryCount}件物品\n`;
          if (info.cultivating) {
            text += `\n状态：修炼中...\n`;
          }
          const imgBuf = superlotusImage.convertSimple(text, "修仙", null, true);
          await sendGroupImage(groupId, imgBuf);
        } catch (e) {
          addLog("warn", "[修仙] 角色信息图片生成失败: " + e.message);
          sendGroupMessage(groupId, result.message || "获取角色信息失败");
        }
      } else if (result.type === 'inventory' && result.inventory) {
        // 背包信息
        let text = `【我的背包】\n\n`;
        text += `灵石：${result.inventory.gold}\n`;
        text += `物品数量：${result.inventory.count}\n\n`;
        if (result.inventory.items.length === 0) {
          text += `背包空空如也，去 #商店 购买物品吧！\n`;
        } else {
          result.inventory.items.forEach((item, i) => {
            text += `${i+1}. ${item.name} x${item.count || 1}（${item.type || '物品'}）\n`;
          });
        }
        text += `\n使用 #使用 物品名 使用丹药\n`;
        text += `使用 #装备 物品名 装备物品\n`;
        sendGroupMessage(groupId, text);
      } else if (result.type === 'equipment' && result.equipment) {
        // 装备信息
        let text = `【我的装备】\n\n`;
        text += `武器：${result.equipment.weapon?.name || '无'}\n`;
        if (result.equipment.weapon) text += `  攻击+${result.equipment.weapon.atk || 0} 防御+${result.equipment.weapon.def || 0} 生命+${result.equipment.weapon.hp || 0}\n`;
        text += `防具：${result.equipment.armor?.name || '无'}\n`;
        if (result.equipment.armor) text += `  攻击+${result.equipment.armor.atk || 0} 防御+${result.equipment.armor.def || 0} 生命+${result.equipment.armor.hp || 0}\n`;
        text += `法宝：${result.equipment.treasure?.name || '无'}\n`;
        if (result.equipment.treasure) text += `  攻击+${result.equipment.treasure.atk || 0} 防御+${result.equipment.treasure.def || 0} 生命+${result.equipment.treasure.hp || 0}\n`;
        text += `\n总攻击：${result.equipment.totalAtk}\n`;
        text += `总防御：${result.equipment.totalDef}\n`;
        text += `总生命：${result.equipment.totalHp}\n`;
        text += `\n使用 #卸下 武器/防具/法宝 卸下装备\n`;
        sendGroupMessage(groupId, text);
      } else if (result.type === 'battle' && result.result) {
        // 战斗结果
        sendGroupMessage(groupId, result.result.message);
      } else if (result.type === 'shop' && result.items) {
        // 商店
        let text = `【修仙商店】\n\n`;
        result.items.forEach((item, i) => {
          text += `${i+1}. ${item.name}（${item.type}）\n`;
          text += `   价格：${item.price}灵石 | 品级：${item.grade}\n`;
          if (item.atk) text += `   攻击+${item.atk}`;
          if (item.def) text += ` 防御+${item.def}`;
          if (item.hp) text += ` 生命+${item.hp}`;
          text += `\n`;
        });
        text += `\n使用 #购买 物品名 数量 购买物品\n`;
        text += `使用 #出售 物品名 数量 出售物品\n`;
        sendGroupMessage(groupId, text);
      } else if (result.type === 'ranking' && result.ranking) {
        // 排行榜
        let text = `【${result.rankType}】\n\n`;
        if (result.ranking.length === 0) {
          text += `暂无排行数据\n`;
        } else {
          result.ranking.forEach((p, i) => {
            const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i+1}.`;
            text += `${medal} ${p.nickname}\n`;
            text += `   ${p.realm} ${p.realmLevel}层 | 战力：${p.power}\n`;
          });
        }
        sendGroupMessage(groupId, text);
      } else {
        sendGroupMessage(groupId, result.message || '处理失败');
      }
      
      addLog("info", `[修仙] 群${groupId} 指令: ${rawMsg}`);
    } catch (e) {
      addLog("warn", "[修仙] 指令处理失败: " + e.message);
      sendGroupMessage(groupId, "修仙功能处理失败，请稍后重试");
    }
    return;
  }

// 检查是否是WF指令（包括标准指令和自定义别名，支持#前缀和无前缀）
  const isWfCommand = (() => {
    // 去掉#前缀后再检查（支持#前缀和无前缀）
    const checkMsg = rawMsg.startsWith("#") ? rawMsg.substring(1) : rawMsg;
    // 标准关键词（包含新功能）
    const wfKeywords = ["突击", "虚空商人", "baro", "仲裁", "裂缝", "普通裂缝", "钢铁裂缝", "虚空风暴", "风暴", "钢铁风暴", "夜灵", "奥布", "魔胎", "火卫二", "入侵", "钢铁", "警报", "深层科研", "深岩", "时光科研", "网件", "平原时间", "wm", "market", "市场", "wf帮助", "warframe", "电波", "午夜电波", "nightwave", "nw", "darvo", "Darvo", "每日特惠", "特惠", "回廊", "无尽回廊", "duviri", "descents", "全部", "all", "平原", "时间", "sortie", "alert", "invasion", "steelpath", "voidtrader", "kahl", "Kahl", "卡尔", "kahl任务", "赏金", "bounty", "赏金任务", "日历", "1999", "calendar", "1999日历", "arbitration", "仲裁任务", "紫卡", "riven", "紫卡查询"];
    for (const kw of wfKeywords) {
      if (checkMsg === kw || checkMsg.startsWith(kw + " ") || checkMsg.includes(kw)) return true;
    }
    // 自定义别名
    try {
      const wfAliases = (currentConfig && currentConfig.wfAliases) || {};
      for (const alias of Object.keys(wfAliases)) {
        const checkAlias = alias.startsWith("#") ? alias.substring(1) : alias;
        if (checkMsg === checkAlias || checkMsg.startsWith(checkAlias + " ")) return true;
      }
    } catch (e) {}
    return false;
  })();
  
  // Warframe 国际服查询（图片发送）
  if (isFeatureEnabled(groupId, "warframe") && isWfCommand) {
    if (!checkRateLimit(userId, 5000)) return;
    const wfResult = await handleWarframeCommand(rawMsg, groupId);
    if (wfResult) {
      // 提取标题（第一行，去掉emoji）
      const titleMatch = wfResult.match(/^(.+)$/m);
      const title = titleMatch ? titleMatch[1].replace(/[🌌⚔️🛒🚨🗺️🏆🛡️💰🔬⏳📻]/g, "").trim() : "Warframe查询";
      // 转成超级小莲风格图片发送（根据功能类型选择不同的UI样式）
      try {
        let buffer;
        // 根据标题或内容判断功能类型，调用对应的图片生成方法
        if (title.includes("平原") || title.includes("时间") || wfResult.includes("平原昼夜")) {
          // 平原查询专用UI（紫色系）
          buffer = superlotusImage.convertPlain(wfResult, title);
        } else if (title.includes("紫卡") || wfResult.includes("紫卡") || rawMsg.includes("紫卡") || rawMsg.includes("riven")) {
          // 紫卡查询专用UI（宽度600px，紫色系）
          buffer = superlotusImage.convertRiven(wfResult, title);
        } else if (title.includes("科研") || wfResult.includes("深层科研") || wfResult.includes("时光科研")) {
          // 科研查询专用UI
          buffer = superlotusImage.convertResearch(wfResult, title, null, true);
        } else {
          // 通用UI（赏金、午夜电波、日历、WM市场、裂缝、突击等）
          buffer = superlotusImage.convertSimple(wfResult, title, null, true);
        }
        const imagePath = require("path").join(__dirname, "data", "wf_" + Date.now() + ".png");
        fs.writeFileSync(imagePath, buffer);
        // 用sendGroupMessage发送图片（双模式下自动用官方机器人发送）
        sendGroupMessage(groupId, [{ type: "image", data: { file: imagePath } }]);
        addLog("success", `[Warframe] 超级小莲风格图片发送成功 群${groupId} 指令: ${rawMsg}`);
        // 30秒后清理临时文件
        setTimeout(() => { try { fs.unlinkSync(imagePath); } catch(e) {} }, 30000);
      } catch (e) {
        addLog("warn", `[Warframe] 超级小莲风格图片生成失败，改用文本: ${e.message}`);
        sendGroupMessage(groupId, wfResult);
      }
      addLog("info", `[Warframe] 群${groupId} 指令: ${rawMsg}`);
      return;
    }
  }

  if (isFeatureEnabled(groupId, "hitokoto") && (rawMsg === "#一言" || rawMsg === "#鸡汤")) {
    const list = cfg.hitokotoList;
    sendGroupMessage(groupId, list[Math.floor(Math.random() * list.length)]);
    addLog("info", `[每日一言] 群${groupId} 触发`);
    return;
  }

  // 网站查询频率限制
  const isWebsiteQuery = rawMsg.startsWith("#搜索") || rawMsg.startsWith("#search") || rawMsg === "#随机游戏" || rawMsg === "#随机" || rawMsg === "#random" || rawMsg.startsWith("#分类") || rawMsg.startsWith("#category") || rawMsg.startsWith("#标签") || rawMsg.startsWith("#tag") || rawMsg.startsWith("#游戏") || rawMsg.startsWith("#game");
  if (isWebsiteQuery && !checkRateLimit(userId, 3000)) return;

  // 网站查询：搜索游戏
  if (isFeatureEnabled(groupId, "websiteQuery") && (rawMsg.startsWith("#搜索") || rawMsg.startsWith("#search"))) {
    const keyword = rawMsg.replace(/^#(搜索|search)\s*/, "").trim();
    if (!keyword) { sendGroupMessage(groupId, "用法：#搜索 游戏名"); return; }
    try {
      const posts = await searchPosts(keyword, 5);
      if (posts.length === 0) { sendGroupMessage(groupId, `未找到与"${keyword}"相关的游戏`); return; }
      
      const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
      const groupIdMap = (currentConfig.dualMode && currentConfig.dualMode.groupIdMap) || {};
      const groupOpenId = dualEnabled ? groupIdMap[String(groupId)] : null;
      
      // 双模式：用 Markdown + 底部复制按钮
      if (dualEnabled && groupOpenId) {
        try {
          let md = `## 🔍 搜索"${keyword}"找到 ${posts.length} 个结果\n\n`;
          posts.forEach((p, i) => {
            const title = stripHtml(p.title?.rendered || "无标题");
            const excerpt = stripHtml(p.excerpt?.rendered || "").slice(0, 60);
            md += `${i + 1}. **${title}**\n`;
            if (excerpt) md += `   ${excerpt}...\n`;
            md += `\n`;
          });
          md += `---\n点击下方按钮复制全部游戏链接`;
          
          const allLinks = posts.map((p, i) => `${i + 1}. ${stripHtml(p.title?.rendered || "")}\n${p.link || ""}`).join("\n\n");
          const copyBtn = officialBot.buildCopyButton("复制全部链接", allLinks, "copy_all");
          const keyboard = officialBot.buildKeyboard([[copyBtn]]);
          await officialBot.sendOfficialMarkdownMessage(groupOpenId, md, keyboard);
          addLog("success", `[搜索] 官方卡片发送成功: ${keyword}`);
        } catch (e) {
          addLog("warn", `[搜索] 官方卡片发送失败: ${e.message}`);
          // fallback 到纯文本
          let msg = `🔍 搜索"${keyword}"找到 ${posts.length} 个结果：\n\n`;
          posts.forEach((p, i) => {
            const title = stripHtml(p.title?.rendered || "无标题");
            msg += `${i + 1}. ${title}\n   ${p.link}\n\n`;
          });
          sendGroupMessage(groupId, msg.trim());
        }
      } else {
        // 非双模式：纯文本
        let msg = `🔍 搜索"${keyword}"找到 ${posts.length} 个结果：\n\n`;
        posts.forEach((p, i) => {
          const title = stripHtml(p.title?.rendered || "无标题");
          msg += `${i + 1}. ${title}\n   ${p.link}\n\n`;
        });
        sendGroupMessage(groupId, msg.trim());
      }
    } catch (e) {
      sendGroupMessage(groupId, "搜索失败，请稍后重试");
      addLog("warn", `[搜索] 失败: ${e.message}`);
    }
    return;
  }

  // 网站查询：随机推荐
  if (isFeatureEnabled(groupId, "websiteQuery") && (rawMsg === "#随机游戏" || rawMsg === "#随机" || rawMsg === "#random")) {
    try {
      const post = await getRandomPost();
      if (!post) { sendGroupMessage(groupId, "暂无游戏数据"); return; }
      sendGroupMessage(groupId, formatPostBrief(post));
    } catch (e) {
      sendGroupMessage(groupId, "获取失败，请稍后重试");
    }
    return;
  }

  // 网站查询：分类浏览
  if (isFeatureEnabled(groupId, "websiteQuery") && (rawMsg.startsWith("#分类") || rawMsg.startsWith("#category"))) {
    const catName = rawMsg.replace(/^#(分类|category)\s*/, "").trim();
    if (!catName) {
      try {
        const cats = await getCategories();
        if (cats.length === 0) { sendGroupMessage(groupId, "暂无分类"); return; }
        let msg = "📂 所有分类：\n";
        cats.forEach((c) => { msg += `  ${c.name}（${c.count}个）\n`; });
        msg += "\n用法：#分类 分类名";
        sendGroupMessage(groupId, msg);
      } catch (e) { sendGroupMessage(groupId, "获取分类失败"); }
      return;
    }
    try {
      const { category, posts } = await getPostsByCategory(catName, 8);
      if (!category) { sendGroupMessage(groupId, `未找到分类"${catName}"，发送 #分类 查看所有分类`); return; }
      if (posts.length === 0) { sendGroupMessage(groupId, `分类"${category.name}"下暂无游戏`); return; }
      let msg = `📂 分类：${category.name}（共${category.count}个，显示前${posts.length}个）\n\n`;
      posts.forEach((p, i) => {
        const title = stripHtml(p.title?.rendered || "无标题");
        msg += `${i + 1}. ${title}\n   ${p.link}\n`;
      });
      sendGroupMessage(groupId, msg);
    } catch (e) {
      sendGroupMessage(groupId, "获取分类游戏失败");
    }
    return;
  }

  // 网站查询：标签搜索
  if (isFeatureEnabled(groupId, "websiteQuery") && (rawMsg.startsWith("#标签") || rawMsg.startsWith("#tag"))) {
    const tagName = rawMsg.replace(/^#(标签|tag)\s*/, "").trim();
    if (!tagName) {
      try {
        const tags = await getTags();
        if (tags.length === 0) { sendGroupMessage(groupId, "暂无标签"); return; }
        let msg = "🏷️ 热门标签：\n";
        tags.slice(0, 20).forEach((t) => { msg += `  ${t.name}（${t.count}个）\n`; });
        msg += "\n用法：#标签 标签名";
        sendGroupMessage(groupId, msg);
      } catch (e) { sendGroupMessage(groupId, "获取标签失败"); }
      return;
    }
    try {
      const { tag, posts } = await getPostsByTag(tagName, 8);
      if (!tag) { sendGroupMessage(groupId, `未找到标签"${tagName}"，发送 #标签 查看所有标签`); return; }
      if (posts.length === 0) { sendGroupMessage(groupId, `标签"${tag.name}"下暂无游戏`); return; }
      
      const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
      const groupIdMap = (currentConfig.dualMode && currentConfig.dualMode.groupIdMap) || {};
      const groupOpenId = dualEnabled ? groupIdMap[String(groupId)] : null;
      
      // 双模式：用 Markdown + 底部复制按钮
      if (dualEnabled && groupOpenId) {
        try {
          let md = `## 🏷️ 标签：${tag.name}（共${tag.count}个，显示前${posts.length}个）\n\n`;
          posts.forEach((p, i) => {
            const title = stripHtml(p.title?.rendered || "无标题");
            const excerpt = stripHtml(p.excerpt?.rendered || "").slice(0, 60);
            md += `${i + 1}. **${title}**\n`;
            if (excerpt) md += `   ${excerpt}...\n`;
            md += `\n`;
          });
          md += `---\n点击下方按钮复制全部游戏链接`;
          
          const allLinks = posts.map((p, i) => `${i + 1}. ${stripHtml(p.title?.rendered || "")}\n${p.link || ""}`).join("\n\n");
          const copyBtn = officialBot.buildCopyButton("复制全部链接", allLinks, "copy_all");
          const keyboard = officialBot.buildKeyboard([[copyBtn]]);
          await officialBot.sendOfficialMarkdownMessage(groupOpenId, md, keyboard);
          addLog("success", `[标签] 官方卡片发送成功: ${tag.name}`);
        } catch (e) {
          addLog("warn", `[标签] 官方卡片发送失败: ${e.message}`);
          // fallback 到纯文本
          let msg = `🏷️ 标签：${tag.name}（共${tag.count}个，显示前${posts.length}个）\n\n`;
          posts.forEach((p, i) => {
            const title = stripHtml(p.title?.rendered || "无标题");
            msg += `${i + 1}. ${title}\n   ${p.link}\n`;
          });
          sendGroupMessage(groupId, msg);
        }
      } else {
        // 非双模式：纯文本
        let msg = `🏷️ 标签：${tag.name}（共${tag.count}个，显示前${posts.length}个）\n\n`;
        posts.forEach((p, i) => {
          const title = stripHtml(p.title?.rendered || "无标题");
          msg += `${i + 1}. ${title}\n   ${p.link}\n`;
        });
        sendGroupMessage(groupId, msg);
      }
    } catch (e) {
      sendGroupMessage(groupId, "获取标签游戏失败");
    }
    return;
  }

  // 网站查询：游戏详情
  if (isFeatureEnabled(groupId, "websiteQuery") && (rawMsg.startsWith("#游戏") || rawMsg.startsWith("#game"))) {
    const keyword = rawMsg.replace(/^#(游戏|game)\s*/, "").trim();
    if (!keyword) { sendGroupMessage(groupId, "用法：#游戏 游戏名"); return; }
    try {
      const posts = await searchPosts(keyword, 5);
      if (posts.length === 0) { sendGroupMessage(groupId, `未找到"${keyword}"相关游戏`); return; }
      
      const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
      const groupIdMap = (currentConfig.dualMode && currentConfig.dualMode.groupIdMap) || {};
      const groupOpenId = dualEnabled ? groupIdMap[String(groupId)] : null;
      
      // 只有1个结果时显示详情
      if (posts.length === 1) {
        const detail = await getPostDetail(posts[0].id);
        const title = stripHtml(detail.title?.rendered || "无标题");
        const link = detail.link || "";
        const content = stripHtml(detail.content?.rendered || "").slice(0, 200);
        const img = detail._embedded?.["wp:featuredmedia"]?.[0]?.source_url;
        
        // 双模式：使用 Embed 卡片
        if (dualEnabled && groupOpenId) {
          try {
            const extraFields = [];
            if (content) extraFields.push({ name: "游戏介绍", value: content + "..." });
            await officialBot.sendOfficialGameCard(groupOpenId, title, "", img, link, extraFields);
            addLog("success", `[游戏详情] 官方卡片发送成功: ${title}`);
          } catch (e) {
            addLog("warn", `[游戏详情] 官方卡片发送失败: ${e.message}`);
            // fallback 到文本
            let msg = `🎮 ${title}\n\n`;
            if (content) msg += `${content}...\n\n`;
            if (img) msg += `🖼️ ${img}\n\n`;
            msg += `👉 详情+下载：${link}`;
            sendGroupMessage(groupId, msg);
          }
        } else {
          let msg = `🎮 ${title}\n\n`;
          if (content) msg += `${content}...\n\n`;
          if (img) msg += `🖼️ ${img}\n\n`;
          msg += `👉 详情+下载：${link}`;
          sendGroupMessage(groupId, msg);
        }
      } else {
        // 多个结果时显示列表
        // 双模式：使用 Markdown 卡片，展示所有结果
        if (dualEnabled && groupOpenId) {
          try {
            // 构造结果列表
            const resultList = posts.map(p => ({
              title: stripHtml(p.title?.rendered || "无标题"),
              excerpt: stripHtml(p.excerpt?.rendered || "").slice(0, 60),
              link: p.link || ""
            }));
            await officialBot.sendOfficialMultiResultCard(groupOpenId, keyword, resultList);
            addLog("success", `[游戏详情] 官方多结果卡片发送成功: ${keyword}`);
          } catch (e) {
            addLog("warn", `[游戏详情] 官方多结果卡片发送失败: ${e.message}`);
            // fallback 到文本
            let msg = `🎮 搜索"${keyword}"找到 ${posts.length} 个结果：\n\n`;
            posts.forEach((p, i) => {
              const title = stripHtml(p.title?.rendered || "无标题");
              const link = p.link || "";
              const excerpt = stripHtml(p.excerpt?.rendered || "").slice(0, 60);
              msg += `${i + 1}. ${title}\n`;
              if (excerpt) msg += `   ${excerpt}...\n`;
              msg += `   👉 ${link}\n\n`;
            });
            msg += `共找到 ${posts.length} 个同名游戏，点击链接查看详情`;
            sendGroupMessage(groupId, msg.trim());
          }
        } else {
          let msg = `🎮 搜索"${keyword}"找到 ${posts.length} 个结果：\n\n`;
          posts.forEach((p, i) => {
            const title = stripHtml(p.title?.rendered || "无标题");
            const link = p.link || "";
            const excerpt = stripHtml(p.excerpt?.rendered || "").slice(0, 60);
            msg += `${i + 1}. ${title}\n`;
            if (excerpt) msg += `   ${excerpt}...\n`;
            msg += `   👉 ${link}\n\n`;
          });
          msg += `共找到 ${posts.length} 个同名游戏，点击链接查看详情`;
          sendGroupMessage(groupId, msg.trim());
        }
      }
    } catch (e) {
      sendGroupMessage(groupId, "获取游戏详情失败");
      addLog("warn", `[游戏详情] 失败: ${e.message}`);
    }
    return;
  }

  if (rawMsg === "#帮助" || rawMsg === "#help" || rawMsg === "帮助") {
    sendHelpMenu(groupId);
    return;
  }

  if (isFeatureEnabled(groupId, "admin")) {
    if (handleAdminCommands(groupId, userId, rawMsg, isAdmin, atUsers, cfg)) return;
  }

  if (isFeatureEnabled(groupId, "keywordReply")) {
    for (const item of cfg.keywordReplies) {
      let matched = item.mode === "exact" ? rawMsg === item.keyword : rawMsg.includes(item.keyword);
      if (matched) {
        sendGroupMessage(groupId, item.reply);
        addLog("info", `[关键词] 群${groupId} 用户${userId} 命中"${item.keyword}"`);
        break;
      }
    }
  }

  // 默认回复（所有指令都没匹配到时，非#开头的消息）
  const _sysDef = currentConfig.system || {};
  const _rawMsgDef = (data.raw_message || "").trim();
  if (!_rawMsgDef.startsWith("#") && _sysDef.defaultReply && _sysDef.defaultReply.trim()) {
    sendGroupMessage(data.group_id, _sysDef.defaultReply);
  }
}

// ==================== 群管指令 ====================
function handleAdminCommands(groupId, userId, rawMsg, isAdmin, atUsers, cfg) {
  if (rawMsg.startsWith("#踢")) {
    if (!isAdmin) { sendGroupMessage(groupId, "只有群主或管理员才能使用此指令"); return true; }
    if (atUsers.length === 0) { sendGroupMessage(groupId, "用法：#踢 @某人"); return true; }
    atUsers.forEach((targetId) => {
      sendAction("set_group_kick", { group_id: groupId, user_id: targetId });
      sendGroupMessage(groupId, `已将 ${targetId} 移出群聊`);
      addLog("info", `[群管] 群${groupId} 踢人 ${targetId}（操作者${userId}）`);
    });
    return true;
  }
  if (rawMsg.startsWith("#禁言")) {
    if (!isAdmin) { sendGroupMessage(groupId, "只有群主或管理员才能使用此指令"); return true; }
    if (atUsers.length === 0) { sendGroupMessage(groupId, "用法：#禁言 @某人 10（分钟，0=解除）"); return true; }
    const match = rawMsg.match(/#禁言\s+(\d+)/);
    const minutes = match ? parseInt(match[1]) : 10;
    const seconds = Math.min(minutes * 60, 30 * 24 * 3600);
    atUsers.forEach((targetId) => {
      sendAction("set_group_ban", { group_id: groupId, user_id: targetId, duration: seconds });
      sendGroupMessage(groupId, seconds === 0 ? `已解除 ${targetId} 的禁言` : `已禁言 ${targetId} ${minutes} 分钟`);
      addLog("info", `[群管] 群${groupId} 禁言 ${targetId} ${minutes}分钟（操作者${userId}）`);
    });
    return true;
  }
  if (rawMsg === "#全员禁言") {
    if (!isAdmin) { sendGroupMessage(groupId, "只有群主或管理员才能使用此指令"); return true; }
    sendAction("set_group_whole_ban", { group_id: groupId, enable: true });
    sendGroupMessage(groupId, "已开启全员禁言");
    addLog("info", `[群管] 群${groupId} 全员禁言（操作者${userId}）`);
    return true;
  }
  if (rawMsg === "#解除全员禁言") {
    if (!isAdmin) { sendGroupMessage(groupId, "只有群主或管理员才能使用此指令"); return true; }
    sendAction("set_group_whole_ban", { group_id: groupId, enable: false });
    sendGroupMessage(groupId, "已解除全员禁言");
    addLog("info", `[群管] 群${groupId} 解除全员禁言（操作者${userId}）`);
    return true;
  }
  return false;
}

function sendHelpMenu(groupId) {
  const helpText = `🤖 小熊机器人功能菜单

【🎮 游戏查询】
#搜索 游戏名  搜索网站游戏
#随机游戏  随机推荐一个游戏
#分类  查看所有分类
#分类 动作  浏览指定分类游戏
#标签  查看所有标签
#标签 3D  浏览指定标签游戏
#游戏 游戏名  查看游戏详情+下载

【💬 通用指令】
#帮助  显示本帮助菜单
#一言  随机一句励志名言

【⚙️ 群管指令】（仅群主/管理员可用）
#踢 @某人  移出群成员
#禁言 @某人 10  禁言指定分钟（0=解除）
#全员禁言  开启全员禁言
#解除全员禁言  关闭全员禁言

【✨ 自动功能】
✓ 新成员入群自动欢迎
✓ 成员退群自动提醒
✓ 关键词自动回复
✓ 网站新游自动推送

💡 提示：所有指令均支持双模式免@响应`;
  
  // 转成超级小莲风格图片发送
  try {
    const buffer = superlotusImage.convertSimple(helpText, "小熊机器人功能菜单", null, true);
    const imagePath = require("path").join(__dirname, "data", "help_" + Date.now() + ".png");
    fs.writeFileSync(imagePath, buffer);
    // 用sendGroupMessage发送图片（双模式下自动用官方机器人发送）
    sendGroupMessage(groupId, [{ type: "image", data: { file: imagePath } }]);
    addLog("success", `[帮助菜单] 图片发送成功 群${groupId}`);
    // 30秒后清理临时文件
    setTimeout(() => { try { fs.unlinkSync(imagePath); } catch(e) {} }, 30000);
  } catch (e) {
    addLog("warn", `[帮助菜单] 图片生成失败，改用文本: ${e.message}`);
    sendGroupMessage(groupId, helpText);
  }
}

// ==================== 在线更新模块 ====================
function downloadText(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith("https://") ? https : http;
    client.get(url, { headers: { "User-Agent": "XiaoXiongBot/1.0" } }, (res) => {
      let data = "";
      res.on("data", (c) => data += c);
      res.on("end", () => {
        if (res.statusCode < 200 || res.statusCode >= 300) { reject(new Error(`HTTP ${res.statusCode}`)); return; }
        resolve(data);
      });
    }).on("error", reject);
  });
}

function downloadFile(url, dest) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith("https://") ? https : http;
    const file = fs.createWriteStream(dest);
    client.get(url, { headers: { "User-Agent": "XiaoXiongBot/1.0" } }, (res) => {
      if (res.statusCode < 200 || res.statusCode >= 300) { file.close(); fs.unlinkSync(dest); reject(new Error(`HTTP ${res.statusCode}`)); return; }
      res.pipe(file);
      file.on("finish", () => { file.close(); resolve(); });
    }).on("error", (e) => { file.close(); if (fs.existsSync(dest)) fs.unlinkSync(dest); reject(e); });
  });
}

function extractZip(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    const psCmd = `Expand-Archive -Path '${zipPath}' -DestinationPath '${destDir}' -Force`;
    exec(`powershell -NoProfile -Command "${psCmd}"`, (error, stdout, stderr) => {
      if (error) reject(new Error(stderr || error.message)); else resolve();
    });
  });
}

function copyDir(src, dest) {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  const resolvedDest = path.resolve(dest);
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.resolve(dest, entry.name);
    // 路径遍历防护：确保目标路径在目标目录内
    if (!destPath.startsWith(resolvedDest + path.sep) && destPath !== resolvedDest) {
      addLog("warn", `[安全] 跳过可疑路径: ${entry.name}`);
      continue;
    }
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function compareVersion(v1, v2) {
  const a = v1.split(".").map(Number);
  const b = v2.split(".").map(Number);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const x = a[i] || 0, y = b[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

// 获取最近活跃的群列表
ipcMain.handle("get-recent-groups", async () => {
  return { success: true, groups: currentConfig.recentActiveGroups || [] };
});

// ==================== IPC 通信 ====================
function setupIpc() {
  ipcMain.handle("config:get", () => currentConfig);
  ipcMain.handle("config:save", (_, config) => {
    // 保护运行时状态不被前端覆盖（如lastPostId等）
    const runtimeLastPostId = currentConfig.website ? currentConfig.website.lastPostId : undefined;
    const runtimePushedPostIds = currentConfig.website ? currentConfig.website.pushedPostIds : undefined;
    const result = saveConfig(config);
    // 恢复运行时状态
    if (result) {
      if (runtimeLastPostId !== undefined) currentConfig.website.lastPostId = runtimeLastPostId;
      if (runtimePushedPostIds !== undefined) currentConfig.website.pushedPostIds = runtimePushedPostIds;
      // 再次保存以确保持久化
      fs.writeFileSync(CONFIG_PATH, JSON.stringify(currentConfig, null, 2), "utf-8");
    }
    return { success: result };
  });

  ipcMain.handle("bot:connect", async () => {
    try {
      if (!currentConfig) {
        return { success: false, error: "配置未加载，请重启软件" };
      }
      const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
      
      if (dualEnabled) {
        addLog("info", "双模式：同时连接 OneBot 和官方机器人");
        connectBot();
        setTimeout(() => { connectOfficialBotMode(); }, 1000);
      } else {
        officialMode = currentConfig.officialMode === true;
        if (officialMode) {
          addLog("info", "当前模式：官方机器人模式");
          await connectOfficialBotMode();
        } else {
          addLog("info", "当前模式：OneBot模式");
          connectBot();
        }
      }
      console.log("[bot:connect] 连接指令已发送");
      return { success: true };
    } catch (e) {
      console.error("[bot:connect] 连接出错:", e);
      addLog("error", "连接出错: " + e.message);
      return { success: false, error: e.message + "\n" + e.stack };
    }
  });
  ipcMain.handle("bot:disconnect", () => {
    const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
    if (dualEnabled || officialMode) {
      disconnectOfficialBotMode();
    }
    if (dualEnabled || !officialMode) {
      disconnectBot();
    }
    return { success: true };
  });
  ipcMain.handle("bot:status", () => ({ status: botStatus, logs: logBuffer, botQQ }));
  ipcMain.handle("bot:clear-logs", () => { logBuffer = []; return { success: true }; });
  
  // WF指令别名管理
  ipcMain.handle("wf:get-aliases", () => {
    try {
      const aliases = (currentConfig && currentConfig.wfAliases) || {};
      return { success: true, aliases };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  
  ipcMain.handle("wf:save-aliases", (_, aliases) => {
    try {
      if (!currentConfig) currentConfig = {};
      currentConfig.wfAliases = aliases;
      saveConfig(currentConfig);
      addLog("info", "WF指令别名已保存，共" + Object.keys(aliases).length + "个别名");
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  
  ipcMain.handle("wf:reset-aliases", () => {
    try {
      const defaultAliases = {
        "#裂": "#裂缝", "#钢": "#钢铁裂缝", "#风": "#虚空风暴",
        "#突": "#突击", "#商": "#虚空商人", "#仲": "#仲裁",
        "#入": "#入侵", "#警": "#警报", "#钢侵": "#钢铁侵袭",
        "#平": "#平原时间", "#夜": "#夜灵", "#奥": "#奥布",
        "#魔": "#魔胎", "#深": "#深层科研", "#时": "#时光科研"
      };
      if (!currentConfig) currentConfig = {};
      currentConfig.wfAliases = defaultAliases;
      saveConfig(currentConfig);
      addLog("info", "WF指令别名已恢复默认");
      return { success: true, aliases: defaultAliases };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 官方机器人模式
  ipcMain.handle("official:connect", async () => {
    try {
      await connectOfficialBotMode();
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("official:disconnect", () => { disconnectOfficialBotMode(); return { success: true }; });
  ipcMain.handle("official:status", () => ({ status: officialStatus, info: officialBot.getOfficialStatus() }));
  ipcMain.handle("official:send-group", async (_, groupId, content, msgId) => {
    try {
      const result = await sendOfficialGroupMessage(groupId, content, msgId);
      return { success: true, result };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("official:set-mode", (_, mode) => {
    officialMode = mode === "official";
    addLog("info", `切换到${officialMode ? "官方机器人" : "OneBot"}模式`);
    return { success: true, mode: officialMode ? "official" : "onebot" };
  });
  ipcMain.handle("official:get-mode", () => ({ mode: officialMode ? "official" : "onebot" }));

  // 网站对接
  ipcMain.handle("website:test", async () => {
    try {
      const posts = await fetchLatestPosts(3);
      return { success: true, posts };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("website:push-now", async () => {
    try {
      addLog("info", "[立即推送] 开始获取最新文章...");
      const posts = await fetchLatestPosts(1);
      if (posts && posts[0]) {
        const post = posts[0];
        const title = (post.title && post.title.rendered) ? post.title.rendered.replace(/<[^>]+>/g, "") : "无标题";
        addLog("info", `[立即推送] 获取到文章: ${title} (ID: ${post.id})`);
        // 检查推送群配置
        const pushGroups = currentConfig.website.pushGroups || [];
        addLog("info", `[立即推送] 配置的推送群: ${pushGroups.length > 0 ? pushGroups.join(", ") : "无"}`);
        if (pushGroups.length === 0) {
          addLog("warn", "[立即推送] 未配置推送群，请在网站设置中添加推送群");
          return { success: false, error: "未配置推送群" };
        }
        // 检查图片
        let imageUrl = "";
        if (post._embedded && post._embedded["wp:featuredmedia"] && post._embedded["wp:featuredmedia"][0]) {
          imageUrl = post._embedded["wp:featuredmedia"][0].source_url || "";
        }
        if (!imageUrl && post.content && post.content.rendered) {
          imageUrl = extractFirstImage(post.content.rendered);
        }
        addLog("info", `[立即推送] 图片: ${imageUrl ? "有" : "无"}`);
        pushPostToGroups(post);
        currentConfig.website.lastPostId = post.id;
        saveConfig();
        addLog("success", `[立即推送] 推送完成: ${title}`);
        return { success: true, post: post };
      }
      addLog("warn", "[立即推送] 没有获取到文章");
      return { success: false, error: "没有获取到文章" };
    } catch (e) {
      addLog("error", `[立即推送] 失败: ${e.message}`);
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("website:check-now", () => { checkWebsiteAndPush(); return { success: true }; });

  // 群设置
  ipcMain.handle("group-settings:get", (_, groupId) => {
    const gid = String(groupId);
    const groupCfg = currentConfig.groupSettings[gid] || {};
    const merged = { ...currentConfig.defaults, ...groupCfg };
    return { groupId: gid, settings: merged, isCustom: !!currentConfig.groupSettings[gid] };
  });
  ipcMain.handle("group-settings:save", (_, groupId, settings) => {
    const gid = String(groupId);
    currentConfig.groupSettings[gid] = { ...settings };
    saveConfig();
    return { success: true };
  });
  ipcMain.handle("group-settings:reset", (_, groupId) => {
    const gid = String(groupId);
    delete currentConfig.groupSettings[gid];
    saveConfig();
    return { success: true };
  });
  ipcMain.handle("group-settings:list", () => {
    return Object.keys(currentConfig.groupSettings).map(gid => ({
      groupId: gid,
      settings: { ...currentConfig.defaults, ...currentConfig.groupSettings[gid] },
    }));
  });

  // 推送群管理
  ipcMain.handle("push-groups:add", (_, groupId) => {
    const gid = String(groupId);
    if (!currentConfig.website.pushGroups.includes(gid)) {
      currentConfig.website.pushGroups.push(gid);
      saveConfig();
    }
    return { success: true, pushGroups: currentConfig.website.pushGroups };
  });
  ipcMain.handle("push-groups:remove", (_, groupId) => {
    const gid = String(groupId);
    currentConfig.website.pushGroups = currentConfig.website.pushGroups.filter(g => g !== gid);
    saveConfig();
    return { success: true, pushGroups: currentConfig.website.pushGroups };
  });

  ipcMain.handle("config:export", async () => {
    const result = await dialog.showSaveDialog(mainWindow, {
      title: "导出配置", defaultPath: "qq-bot-config.json",
      filters: [{ name: "JSON文件", extensions: ["json"] }],
    });
    if (!result.canceled && result.filePath) {
      fs.writeFileSync(result.filePath, JSON.stringify(currentConfig, null, 2), "utf-8");
      return { success: true };
    }
    return { success: false };
  });

ipcMain.handle("config:import", async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: "导入配置", filters: [{ name: "JSON文件", extensions: ["json"] }],
      properties: ["openFile"],
    });
    if (!result.canceled && result.filePaths.length > 0) {
      try {
        const imported = JSON.parse(fs.readFileSync(result.filePaths[0], "utf-8"));
        currentConfig = deepMerge(DEFAULT_CONFIG, imported);
        saveConfig();
        return { success: true, config: currentConfig };
      } catch (e) {
        return { success: false, error: e.message };
      }
    }
    return { success: false };
  });

  // 窗口控制
  ipcMain.handle("window:minimize", () => { if (mainWindow) mainWindow.minimize(); });
  ipcMain.handle("window:maximize", () => {
    if (!mainWindow) return;
    if (mainWindow.isMaximized()) mainWindow.unmaximize(); else mainWindow.maximize();
  });
  ipcMain.handle("window:close", () => { if (mainWindow) mainWindow.close(); });
  ipcMain.handle("window:is-maximized", () => ({ maximized: mainWindow ? mainWindow.isMaximized() : false }));

  // 在线更新
  ipcMain.handle("update:get-version", () => ({ version: APP_VERSION }));
  ipcMain.handle("update:check", async () => {
    try {
      const data = await downloadText(UPDATE_URL + "version.json");
      const remote = JSON.parse(data);
      const hasUpdate = compareVersion(remote.version, APP_VERSION) > 0;
      return { success: true, hasUpdate, latestVersion: remote.version, notes: remote.notes || "", currentVersion: APP_VERSION };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("update:download", async () => {
    try {
      const verData = await downloadText(UPDATE_URL + "version.json");
      const remote = JSON.parse(verData);
      const fileName = remote.file || "update.zip";
      // 支持完整URL或相对路径
      const downloadUrl = fileName.startsWith("http") ? fileName : UPDATE_URL + fileName;
      const tempZip = path.join(app.getPath("temp"), "xiaoxiong-update.zip");
      await downloadFile(downloadUrl, tempZip);
      const tempDir = path.join(app.getPath("temp"), "xiaoxiong-update");
      if (fs.existsSync(tempDir)) fs.rmSync(tempDir, { recursive: true, force: true });
      fs.mkdirSync(tempDir, { recursive: true });
      await extractZip(tempZip, tempDir);
      const appDir = app.getAppPath();
      copyDir(tempDir, appDir);
      fs.rmSync(tempDir, { recursive: true, force: true });
      fs.unlinkSync(tempZip);
      return { success: true, message: "更新完成，请重启应用" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("update:restart", () => { app.relaunch(); app.exit(0); });

  // Warframe 平台设置
  ipcMain.handle("warframe:get-platform", () => ({ platform: WF_PLATFORM }));
  ipcMain.handle("warframe:set-platform", (_, platform) => {
    const valid = ["pc", "ps4", "xb1", "swi"];
    if (valid.includes(platform)) { WF_PLATFORM = platform; return { success: true }; }
    return { success: false, error: "无效平台" };
  });

  // 本地更新包（选择本地zip直接更新）
  ipcMain.handle("update:local", async () => {
    try {
      const result = await dialog.showOpenDialog(mainWindow, {
        title: "选择更新包", filters: [{ name: "更新包", extensions: ["zip"] }],
        properties: ["openFile"],
      });
      if (result.canceled || result.filePaths.length === 0) return { success: false, error: "已取消" };
      const zipPath = result.filePaths[0];
      const tempDir = path.join(app.getPath("temp"), "xiaoxiong-local-update");
      if (fs.existsSync(tempDir)) fs.rmSync(tempDir, { recursive: true, force: true });
      fs.mkdirSync(tempDir, { recursive: true });
      await extractZip(zipPath, tempDir);
      const appDir = app.getAppPath();
      copyDir(tempDir, appDir);
      fs.rmSync(tempDir, { recursive: true, force: true });
      return { success: true, message: "本地更新包已安装，请重启应用" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // ==================== 修仙管理 IPC 接口 ====================
  const xiuxian = require('./xiuxian.js');
  const XIUXIAN_DATA_DIR = path.join(__dirname, 'data', 'xiuxian');
  const XIUXIAN_PLAYERS_DIR = path.join(XIUXIAN_DATA_DIR, 'players');
  const XIUXIAN_SECTS_DIR = path.join(XIUXIAN_DATA_DIR, 'sects');
  const XIUXIAN_MARKET_PATH = path.join(XIUXIAN_DATA_DIR, 'market.json');

  ipcMain.handle('xiuxian-get-stats', () => {
    try {
      let totalPlayers = 0, activePlayers = 0, totalSects = 0, marketItems = 0;
      if (fs.existsSync(XIUXIAN_PLAYERS_DIR)) {
        const files = fs.readdirSync(XIUXIAN_PLAYERS_DIR).filter(f => f.endsWith('.json'));
        totalPlayers = files.length;
        const today = new Date().toDateString();
        files.forEach(f => {
          try {
            const p = JSON.parse(fs.readFileSync(path.join(XIUXIAN_PLAYERS_DIR, f), 'utf-8'));
            if (p.lastUpdate && new Date(p.lastUpdate).toDateString() === today) activePlayers++;
          } catch (e) {}
        });
      }
      if (fs.existsSync(XIUXIAN_SECTS_DIR)) {
        totalSects = fs.readdirSync(XIUXIAN_SECTS_DIR).filter(f => f.endsWith('.json')).length;
      }
      if (fs.existsSync(XIUXIAN_MARKET_PATH)) {
        try {
          const market = JSON.parse(fs.readFileSync(XIUXIAN_MARKET_PATH, 'utf-8'));
          marketItems = (market.items || []).length;
        } catch (e) {}
      }
      return { success: true, data: { totalPlayers, activePlayers, totalSects, marketItems } };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

    ipcMain.handle('xiuxian-get-players', () => {
    try {
      const players = [];
      if (fs.existsSync(XIUXIAN_PLAYERS_DIR)) {
        const files = fs.readdirSync(XIUXIAN_PLAYERS_DIR).filter(f => f.endsWith('.json'));
        files.forEach(f => {
          try {
            const p = JSON.parse(fs.readFileSync(path.join(XIUXIAN_PLAYERS_DIR, f), 'utf-8'));
            // 适配新修仙核心模块的数据格式（中文字段名）
            const qq = p.qq || p.id || f.replace('.json', '');
            const nickname = p.nickname || p.名号 || '未知';
            const realmId = p.realmId || p.level_id || 1;
            const realmLevel = p.realmLevel || 1;
            const atk = p.atk || p.攻击 || p.攻击加成 || 0;
            const def = p.def || p.防御 || p.防御加成 || 0;
            const maxHp = p.maxHp || p.生命 || p.生命加成 || p.当前血量 || 100;
            const gold = p.gold || p.灵石 || 0;
            const exp = p.exp || p.修为 || 0;
            const banned = p.banned || false;
            
            // 尝试获取境界名称
            let realmName = '练气期';
            try {
              const realmConfig = xiuxian.config && (xiuxian.config.境界体系 || xiuxian.config.境界列表 || xiuxian.config.练气境界);
              if (Array.isArray(realmConfig)) {
                const realm = realmConfig.find(r => (r.id === realmId) || (r.level_id === realmId) || (r.ID === realmId));
                if (realm) realmName = realm.name || realm.level || realm.名称 || '练气期';
              }
            } catch (e) {}
            
            const playerData = {
              qq: qq,
              nickname: nickname,
              realm: realmName,
              realmId: realmId,
              realmLevel: realmLevel,
              power: atk + def + maxHp,
              gold: gold,
              exp: exp,
              banned: banned
            };
            console.log('[修仙管理] 玩家数据:', JSON.stringify(playerData));
            players.push(playerData);
          } catch (e) {
            console.log('[修仙管理] 玩家数据解析失败:', f, e.message);
          }
        });
        players.sort((a, b) => b.power - a.power);
      }
      return { success: true, data: { players } };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
    ipcMain.handle('xiuxian-get-player-detail', (_, { qq }) => {
    try {
      const p = xiuxian.readPlayer(qq);
      if (!p) return { success: false, error: '玩家不存在' };
      // 适配新数据格式
      const atk = p.atk || p.攻击 || p.攻击加成 || 0;
      const def = p.def || p.防御 || p.防御加成 || 0;
      const maxHp = p.maxHp || p.生命 || p.生命加成 || p.当前血量 || 100;
      const realmId = p.realmId || p.level_id || 1;
      
      // 尝试获取境界名称
      let realmName = '练气期';
      try {
        const realmConfig = xiuxian.config && (xiuxian.config.境界体系 || xiuxian.config.境界列表 || xiuxian.config.练气境界);
        if (Array.isArray(realmConfig)) {
          const realm = realmConfig.find(r => (r.id === realmId) || (r.level_id === realmId));
          if (realm) realmName = realm.name || realm.level || realm.名称 || '练气期';
        }
      } catch (e) {}
      
      // 调试：打印玩家数据中的灵根相关字段
      console.log('[修仙管理-详情] 玩家字段:', Object.keys(p).filter(k => k.includes('灵') || k.includes('ling') || k.includes('根')));
      console.log('[修仙管理-详情] 灵根值:', JSON.stringify(p.灵根 || p.linggen || null));
      
      // 适配所有字段
      const playerData = {
        ...p,
        qq: p.qq || p.id || qq,
        nickname: p.nickname || p.名号 || '未知',
        realm: realmName,
        realmId: realmId,
        realmLevel: p.realmLevel || 1,
        atk: atk,
        def: def,
        hp: p.hp || p.当前血量 || maxHp,
        maxHp: maxHp,
        power: atk + def + maxHp,
        gold: p.gold || p.灵石 || 0,
        exp: p.exp || p.修为 || 0,
        banned: p.banned || false,
        // 灵根：linggen可能是空数组，要用灵根字段
        linggen: (p.linggen && p.linggen.length > 0) ? p.linggen : (p.灵根 || null),
        // 宗门
        sect: p.sect || p.宗门 || null,
        // 仙宠
        pet: p.pet || p.仙宠 || null,
        // 职业
        occupation: p.occupation || p.职业 || '散修',
        // 配偶
        spouse: p.spouse || null,
        // 师父
        master: p.master || null,
        // 创建时间
        createTime: p.createTime || Date.now()
      };
      
      return { 
        success: true, 
        data: playerData
      };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

    ipcMain.handle('xiuxian-get-config', () => {
    try {
      // 直接读取config.json文件，因为xiuxian.config是GameConfig类实例，结构不对
      const configPath = path.join(__dirname, 'data', 'xiuxian', 'config.json');
      let c = {};
      if (fs.existsSync(configPath)) {
        c = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      } else {
        // 兜底：从GameConfig实例中获取
        const gc = xiuxian.config;
        c = gc.configs || gc || {};
      }
      console.log('[修仙管理-配置] 境界体系数量:', (c.境界体系 || []).length);
      console.log('[修仙管理-配置] 灵根天赋数量:', (c.灵根天赋 || []).length);
      return { success: true, data: {
        realms: c.境界体系 || [], linggen: c.灵根天赋 || [],
        weapons: (c.武器列表 || []).length, armors: (c.防具列表 || []).length,
        treasures: (c.法宝列表 || []).length, pills: c.丹药列表 || [],
        monsters: c.怪物列表 || [], occupations: c.职业列表 || []
      }};
    } catch (e) {
      console.log('[修仙管理-配置] 读取失败:', e.message);
      return { success: false, error: e.message };
    }
  });

  // 获取物品列表
  ipcMain.handle('xiuxian-get-items', (_, { type }) => {
    try {
      const itemPath = path.join(__dirname, 'data', 'xiuxian', 'game-data', 'item', type + '.json');
      let items = [];
      if (fs.existsSync(itemPath)) {
        items = JSON.parse(fs.readFileSync(itemPath, 'utf-8'));
        if (!Array.isArray(items)) items = [items];
      } else {
        // 兜底：从config.json中获取
        const configPath = path.join(__dirname, 'data', 'xiuxian', 'config.json');
        if (fs.existsSync(configPath)) {
          const c = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
          items = c[type] || [];
        }
      }
      console.log('[修仙管理-物品] 类型:', type, '数量:', items.length);
      return { success: true, data: { items } };
    } catch (e) {
      console.log('[修仙管理-物品] 读取失败:', e.message);
      return { success: false, error: e.message };
    }
  });

  // 获取高级系统数据
  ipcMain.handle('xiuxian-get-advanced-data', (_, { type }) => {
    try {
      let result = { stats: {}, list: [], info: null };
      
      // 读取所有玩家数据用于统计
      const playersDir = path.join(__dirname, 'data', 'xiuxian', 'players');
      const players = [];
      if (fs.existsSync(playersDir)) {
        const files = fs.readdirSync(playersDir).filter(f => f.endsWith('.json'));
        files.forEach(f => {
          try {
            const p = JSON.parse(fs.readFileSync(path.join(playersDir, f), 'utf-8'));
            players.push(p);
          } catch (e) {}
        });
      }
      
      switch (type) {
        case 'casino': // 赌坊
          result.stats = {
            '总玩家数': players.length,
            '参与赌坊': players.filter(p => p.金银坊胜场 || p.金银坊败场).length,
            '总胜场': players.reduce((sum, p) => sum + (p.金银坊胜场 || 0), 0),
            '总败场': players.reduce((sum, p) => sum + (p.金银坊败场 || 0), 0),
          };
          result.list = players.filter(p => p.金银坊胜场 || p.金银坊败场).map(p => ({
            '玩家': p.名号 || p.nickname || '未知',
            '胜场': p.金银坊胜场 || 0,
            '败场': p.金银坊败场 || 0,
            '收入': p.金银坊收入 || 0,
            '支出': p.金银坊支出 || 0,
          }));
          break;
          
        case 'bank': // 钱庄
          result.stats = {
            '总玩家数': players.length,
            '有存款': players.filter(p => p.钱庄存款 || p.存款).length,
            '总存款': players.reduce((sum, p) => sum + (p.钱庄存款 || p.存款 || 0), 0),
          };
          result.list = players.filter(p => p.钱庄存款 || p.存款).map(p => ({
            '玩家': p.名号 || p.nickname || '未知',
            '存款': p.钱庄存款 || p.存款 || 0,
          }));
          break;
          
        case 'master': // 师徒
          result.stats = {
            '总玩家数': players.length,
            '有师父': players.filter(p => p.master).length,
            '有徒弟': players.filter(p => p.apprentices && p.apprentices.length > 0).length,
          };
          result.list = players.filter(p => p.master || (p.apprentices && p.apprentices.length > 0)).map(p => ({
            '玩家': p.名号 || p.nickname || '未知',
            '师父': p.master ? (p.master.nickname || '有') : '无',
            '徒弟数': p.apprentices ? p.apprentices.length : 0,
          }));
          break;
          
        case 'marriage': // 婚姻
          result.stats = {
            '总玩家数': players.length,
            '已婚': players.filter(p => p.spouse).length,
          };
          result.list = players.filter(p => p.spouse).map(p => ({
            '玩家': p.名号 || p.nickname || '未知',
            '配偶': p.spouse ? (p.spouse.nickname || '有') : '无',
            '亲密度': p.亲密度 || 0,
          }));
          break;
          
        case 'reincarnation': // 轮回
          result.stats = {
            '总玩家数': players.length,
            '已轮回': players.filter(p => p.lunhui > 0).length,
            '总轮回次数': players.reduce((sum, p) => sum + (p.lunhui || 0), 0),
            '总轮回点': players.reduce((sum, p) => sum + (p.轮回点 || 0), 0),
          };
          result.list = players.filter(p => p.lunhui > 0 || p.轮回点 > 0).map(p => ({
            '玩家': p.名号 || p.nickname || '未知',
            '轮回次数': p.lunhui || 0,
            '轮回点': p.轮回点 || 0,
          }));
          break;
          
        case 'secret': // 秘境
          const secretPath = path.join(__dirname, 'data', 'xiuxian', 'game-data', 'item', '宗门秘境.json');
          if (fs.existsSync(secretPath)) {
            const secrets = JSON.parse(fs.readFileSync(secretPath, 'utf-8'));
            result.stats = { '秘境总数': Array.isArray(secrets) ? secrets.length : 1 };
            result.list = Array.isArray(secrets) ? secrets : [secrets];
          }
          break;
          
        case 'boss': // 世界BOSS
          result.stats = {
            '总玩家数': players.length,
            '神界次数': players.reduce((sum, p) => sum + (p.神界次数 || 0), 0),
          };
          result.info = { note: '世界BOSS数据存储在运行时内存中，重启后重置' };
          break;
          
        case 'god': // 神界
          result.stats = {
            '总玩家数': players.length,
            '已飞升': players.filter(p => p.race && p.race > 1).length,
            '神界次数': players.reduce((sum, p) => sum + (p.神界次数 || 0), 0),
          };
          result.list = players.filter(p => p.race && p.race > 1).map(p => ({
            '玩家': p.名号 || p.nickname || '未知',
            '种族': p.race || 1,
            '神界次数': p.神界次数 || 0,
          }));
          break;
          
        case 'tower': // 镇妖塔
          result.stats = {
            '总玩家数': players.length,
            '已挑战': players.filter(p => p.镇妖塔层数 > 0).length,
            '最高层数': Math.max(...players.map(p => p.镇妖塔层数 || 0), 0),
          };
          result.list = players.filter(p => p.镇妖塔层数 > 0).sort((a, b) => (b.镇妖塔层数 || 0) - (a.镇妖塔层数 || 0)).map(p => ({
            '玩家': p.名号 || p.nickname || '未知',
            '层数': p.镇妖塔层数 || 0,
            '神魄段数': p.神魄段数 || 0,
          }));
          break;
      }
      
      console.log('[修仙管理-高级] 类型:', type, '统计:', JSON.stringify(result.stats));
      return { success: true, data: result };
    } catch (e) {
      console.log('[修仙管理-高级] 读取失败:', e.message);
      return { success: false, error: e.message };
    }
  });

  // 获取限时物品
  ipcMain.handle('xiuxian-get-timelimit-items', (_, { type }) => {
    try {
      const timelimitPath = path.join(__dirname, 'data', 'xiuxian', 'game-data', 'Timelimit', type + '.json');
      let items = [];
      if (fs.existsSync(timelimitPath)) {
        items = JSON.parse(fs.readFileSync(timelimitPath, 'utf-8'));
        if (!Array.isArray(items)) items = [items];
      }
      console.log('[修仙管理-限时] 类型:', type, '数量:', items.length);
      return { success: true, data: { items } };
    } catch (e) {
      console.log('[修仙管理-限时] 读取失败:', e.message);
      return { success: false, error: e.message };
    }
  });

  // 更新玩家所有属性
  ipcMain.handle('xiuxian-update-player-attributes', (_, { qq, updates }) => {
    try {
      const playerPath = path.join(__dirname, 'data', 'xiuxian', 'players', String(qq) + '.json');
      if (!fs.existsSync(playerPath)) {
        return { success: false, error: '玩家不存在' };
      }
      const player = JSON.parse(fs.readFileSync(playerPath, 'utf-8'));
      
      // 更新属性（兼容中英文双字段名）
      if (updates.atk !== undefined) { player.攻击 = updates.atk; player.atk = updates.atk; }
      if (updates.def !== undefined) { player.防御 = updates.def; player.def = updates.def; }
      if (updates.maxHp !== undefined) { player.血量上限 = updates.maxHp; player.maxHp = updates.maxHp; }
      if (updates.hp !== undefined) { player.当前血量 = updates.hp; player.hp = updates.hp; }
      if (updates.gold !== undefined) { player.灵石 = updates.gold; player.gold = updates.gold; }
      if (updates.exp !== undefined) { player.修为 = updates.exp; player.exp = updates.exp; }
      if (updates.realmId !== undefined) { player.level_id = updates.realmId; player.realmId = updates.realmId; }
      if (updates.lunhuiPoint !== undefined) { player.轮回点 = updates.lunhuiPoint; }
      
      fs.writeFileSync(playerPath, JSON.stringify(player, null, 2), 'utf-8');
      console.log('[修仙管理] 已更新玩家属性:', qq, JSON.stringify(updates));
      return { success: true };
    } catch (e) {
      console.log('[修仙管理] 更新玩家属性失败:', e.message);
      return { success: false, error: e.message };
    }
  });

  // 重置玩家数据
  ipcMain.handle('xiuxian-reset-player', (_, { qq }) => {
    try {
      const playerPath = path.join(__dirname, 'data', 'xiuxian', 'players', String(qq) + '.json');
      if (!fs.existsSync(playerPath)) {
        return { success: false, error: '玩家不存在' };
      }
      // 备份后删除
      const backupPath = playerPath + '.backup.' + Date.now();
      fs.copyFileSync(playerPath, backupPath);
      fs.unlinkSync(playerPath);
      console.log('[修仙管理] 已重置玩家数据:', qq, '备份:', backupPath);
      return { success: true };
    } catch (e) {
      console.log('[修仙管理] 重置玩家数据失败:', e.message);
      return { success: false, error: e.message };
    }
  });

  // 保存配置JSON
  ipcMain.handle('xiuxian-save-config', (_, { configJson }) => {
    try {
      const configPath = path.join(__dirname, 'data', 'xiuxian', 'config.json');
      const config = JSON.parse(configJson); // 验证JSON格式
      // 备份原配置
      if (fs.existsSync(configPath)) {
        fs.copyFileSync(configPath, configPath + '.backup.' + Date.now());
      }
      fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf-8');
      console.log('[修仙管理] 配置已保存');
      return { success: true };
    } catch (e) {
      console.log('[修仙管理] 保存配置失败:', e.message);
      return { success: false, error: e.message };
    }
  });

  // 获取配置原始JSON
  ipcMain.handle('xiuxian-get-config-raw', () => {
    try {
      const configPath = path.join(__dirname, 'data', 'xiuxian', 'config.json');
      const config = fs.readFileSync(configPath, 'utf-8');
      return { success: true, data: config };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 获取宗门成员列表
  ipcMain.handle('xiuxian-get-sect-members', (_, { sectName }) => {
    try {
      const playersDir = path.join(__dirname, 'data', 'xiuxian', 'players');
      const members = [];
      if (fs.existsSync(playersDir)) {
        const files = fs.readdirSync(playersDir).filter(f => f.endsWith('.json'));
        files.forEach(f => {
          try {
            const p = JSON.parse(fs.readFileSync(path.join(playersDir, f), 'utf-8'));
            const playerSect = p.宗门 || p.sect;
            if (playerSect && (playerSect.name === sectName || playerSect === sectName)) {
              members.push({
                qq: p.qq || p.id || f.replace('.json', ''),
                nickname: p.名号 || p.nickname || '未知',
                realm: p.level_id || 1,
                contribution: playerSect.contribution || playerSect.贡献 || 0,
                role: playerSect.role || playerSect.职位 || '成员'
              });
            }
          } catch (e) {}
        });
      }
      return { success: true, data: { members } };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 强制移除宗门成员
  ipcMain.handle('xiuxian-remove-sect-member', (_, { qq }) => {
    try {
      const playerPath = path.join(__dirname, 'data', 'xiuxian', 'players', String(qq) + '.json');
      if (!fs.existsSync(playerPath)) return { success: false, error: '玩家不存在' };
      const p = JSON.parse(fs.readFileSync(playerPath, 'utf-8'));
      p.宗门 = null;
      p.sect = null;
      fs.writeFileSync(playerPath, JSON.stringify(p, null, 2), 'utf-8');
      console.log('[修仙管理] 已强制移除宗门成员:', qq);
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 操作日志
  const OPERATION_LOG_FILE = path.join(__dirname, 'data', 'xiuxian', 'operation-logs.json');
  function addOperationLog(action, detail, admin = 'admin') {
    try {
      let logs = [];
      if (fs.existsSync(OPERATION_LOG_FILE)) {
        logs = JSON.parse(fs.readFileSync(OPERATION_LOG_FILE, 'utf-8'));
      }
      logs.unshift({
        time: new Date().toISOString(),
        action,
        detail,
        admin
      });
      if (logs.length > 500) logs = logs.slice(0, 500);
      fs.writeFileSync(OPERATION_LOG_FILE, JSON.stringify(logs, null, 2), 'utf-8');
    } catch (e) {
      console.log('[修仙管理] 操作日志写入失败:', e.message);
    }
  }

  // 获取操作日志
  ipcMain.handle('xiuxian-get-operation-logs', (_, { limit = 100 }) => {
    try {
      let logs = [];
      if (fs.existsSync(OPERATION_LOG_FILE)) {
        logs = JSON.parse(fs.readFileSync(OPERATION_LOG_FILE, 'utf-8'));
      }
      return { success: true, data: { logs: logs.slice(0, limit) } };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 数据备份
  ipcMain.handle('xiuxian-backup-data', () => {
    try {
      const backupDir = path.join(__dirname, 'data', 'xiuxian', 'backups');
      if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupPath = path.join(backupDir, 'backup-' + timestamp + '.zip');
      
      // 简单备份：复制players目录和config.json
      const backupDataDir = path.join(backupDir, 'backup-' + timestamp);
      fs.mkdirSync(backupDataDir, { recursive: true });
      
      // 复制玩家数据
      const playersDir = path.join(__dirname, 'data', 'xiuxian', 'players');
      if (fs.existsSync(playersDir)) {
        const destPlayers = path.join(backupDataDir, 'players');
        fs.mkdirSync(destPlayers, { recursive: true });
        fs.readdirSync(playersDir).filter(f => f.endsWith('.json')).forEach(f => {
          fs.copyFileSync(path.join(playersDir, f), path.join(destPlayers, f));
        });
      }
      
      // 复制配置
      const configPath = path.join(__dirname, 'data', 'xiuxian', 'config.json');
      if (fs.existsSync(configPath)) {
        fs.copyFileSync(configPath, path.join(backupDataDir, 'config.json'));
      }
      
      addOperationLog('数据备份', '备份创建成功: ' + timestamp);
      console.log('[修仙管理] 数据备份成功:', backupDataDir);
      return { success: true, data: { backupPath: backupDataDir, timestamp } };
    } catch (e) {
      console.log('[修仙管理] 数据备份失败:', e.message);
      return { success: false, error: e.message };
    }
  });

  // 获取备份列表
  ipcMain.handle('xiuxian-get-backups', () => {
    try {
      const backupDir = path.join(__dirname, 'data', 'xiuxian', 'backups');
      const backups = [];
      if (fs.existsSync(backupDir)) {
        fs.readdirSync(backupDir).filter(d => d.startsWith('backup-')).forEach(d => {
          const stat = fs.statSync(path.join(backupDir, d));
          backups.push({ name: d, time: stat.mtime, size: 0 });
        });
      }
      backups.sort((a, b) => new Date(b.time) - new Date(a.time));
      return { success: true, data: { backups } };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 获取统计数据
  ipcMain.handle('xiuxian-get-stats-dashboard', () => {
    try {
      const playersDir = path.join(__dirname, 'data', 'xiuxian', 'players');
      const players = [];
      if (fs.existsSync(playersDir)) {
        fs.readdirSync(playersDir).filter(f => f.endsWith('.json')).forEach(f => {
          try {
            players.push(JSON.parse(fs.readFileSync(path.join(playersDir, f), 'utf-8')));
          } catch (e) {}
        });
      }
      
      // 境界分布
      const realmDistribution = {};
      players.forEach(p => {
        const realm = p.level_id || 1;
        realmDistribution[realm] = (realmDistribution[realm] || 0) + 1;
      });
      
      // 职业分布
      const occupationDistribution = {};
      players.forEach(p => {
        const occ = p.occupation || '散修';
        occupationDistribution[occ] = (occupationDistribution[occ] || 0) + 1;
      });
      
      // 灵根分布
      const linggenDistribution = {};
      players.forEach(p => {
        const lg = p.灵根 || p.linggen;
        if (lg && lg.type) {
          linggenDistribution[lg.type] = (linggenDistribution[lg.type] || 0) + 1;
        }
      });
      
      const stats = {
        totalPlayers: players.length,
        totalGold: players.reduce((sum, p) => sum + (p.灵石 || p.gold || 0), 0),
        totalExp: players.reduce((sum, p) => sum + (p.修为 || p.exp || 0), 0),
        avgLevel: Math.round(players.reduce((sum, p) => sum + (p.level_id || 1), 0) / (players.length || 1)),
        bannedCount: players.filter(p => p.banned).length,
        hasPetCount: players.filter(p => p.仙宠 || p.pet).length,
        hasSectCount: players.filter(p => p.宗门 || p.sect).length,
        marriedCount: players.filter(p => p.spouse).length,
        realmDistribution,
        occupationDistribution,
        linggenDistribution
      };
      
      return { success: true, data: stats };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  ipcMain.handle('xiuxian-open-config', () => {
    try {
      shell.openPath(path.join(XIUXIAN_DATA_DIR, 'config.json'));
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  ipcMain.handle('xiuxian-get-sects', () => {
    try {
      const sects = [];
      if (fs.existsSync(XIUXIAN_SECTS_DIR)) {
        const files = fs.readdirSync(XIUXIAN_SECTS_DIR).filter(f => f.endsWith('.json'));
        files.forEach(f => {
          try {
            const s = JSON.parse(fs.readFileSync(path.join(XIUXIAN_SECTS_DIR, f), 'utf-8'));
            const founder = xiuxian.readPlayer(s.founder);
            sects.push({ ...s, founderName: founder?.nickname || '未知' });
          } catch (e) {}
        });
      }
      return { success: true, data: { sects } };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  ipcMain.handle('xiuxian-get-market', () => {
    try {
      let items = [];
      if (fs.existsSync(XIUXIAN_MARKET_PATH)) {
        const market = JSON.parse(fs.readFileSync(XIUXIAN_MARKET_PATH, 'utf-8'));
        items = market.items || [];
      }
      return { success: true, data: { items } };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 玩家数据编辑
  ipcMain.handle('xiuxian-update-player', (_, { qq, updates }) => {
    try { return xiuxian.updatePlayerData(qq, updates); }
    catch (e) { return { success: false, error: e.message }; }
  });
  ipcMain.handle('xiuxian-add-gold', (_, { qq, amount }) => {
    try { return xiuxian.addPlayerGold(qq, amount); }
    catch (e) { return { success: false, error: e.message }; }
  });
  ipcMain.handle('xiuxian-add-exp', (_, { qq, amount }) => {
    try { return xiuxian.addPlayerExp(qq, amount); }
    catch (e) { return { success: false, error: e.message }; }
  });

  // 封禁管理
  ipcMain.handle('xiuxian-ban-player', (_, { qq, reason, duration }) => {
    try { return xiuxian.banPlayer(qq, reason, duration); }
    catch (e) { return { success: false, error: e.message }; }
  });
  ipcMain.handle('xiuxian-unban-player', (_, { qq }) => {
    try { return xiuxian.unbanPlayer(qq); }
    catch (e) { return { success: false, error: e.message }; }
  });

  // 邮件系统
  ipcMain.handle('xiuxian-send-mail', (_, { toQq, title, content, rewards }) => {
    try { return xiuxian.sendMail(toQq, title, content, rewards); }
    catch (e) { return { success: false, error: e.message }; }
  });
  ipcMain.handle('xiuxian-send-global-mail', (_, { title, content, rewards }) => {
    try { return xiuxian.sendGlobalMail(title, content, rewards); }
    catch (e) { return { success: false, error: e.message }; }
  });

  // 宗门管理
  ipcMain.handle('xiuxian-disband-sect', (_, { sectName }) => {
    try { return xiuxian.disbandSect(sectName); }
    catch (e) { return { success: false, error: e.message }; }
  });
  ipcMain.handle('xiuxian-update-sect-level', (_, { sectName, level }) => {
    try { return xiuxian.updateSectLevel(sectName, level); }
    catch (e) { return { success: false, error: e.message }; }
  });
  ipcMain.handle('xiuxian-update-sect-announcement', (_, { sectName, announcement }) => {
    try { return xiuxian.updateSectAnnouncement(sectName, announcement); }
    catch (e) { return { success: false, error: e.message }; }
  });

  // 市场管理
  ipcMain.handle('xiuxian-remove-market-item', (_, { itemId }) => {
    try { return xiuxian.removeMarketItem(itemId); }
    catch (e) { return { success: false, error: e.message }; }
  });

  // 数据导出
  ipcMain.handle('xiuxian-export-players', (_, { format }) => {
    try {
      const result = xiuxian.exportPlayersData(format || 'json');
      const exportPath = path.join(app.getPath('desktop'), 'xiuxian_players_' + Date.now() + '.' + (format || 'json'));
      fs.writeFileSync(exportPath, result.data, 'utf-8');
      return { success: true, message: '数据已导出到桌面', path: exportPath, count: result.count };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });

  // 活动管理
  ipcMain.handle('xiuxian-create-activity', (_, { name, type, value, startTime, endTime, description }) => {
    try { return xiuxian.createActivity(name, type, value, startTime, endTime, description); }
    catch (e) { return { success: false, error: e.message }; }
  });
  ipcMain.handle('xiuxian-update-activity', (_, { activityId, updates }) => {
    try { return xiuxian.updateActivity(activityId, updates); }
    catch (e) { return { success: false, error: e.message }; }
  });
  ipcMain.handle('xiuxian-delete-activity', (_, { activityId }) => {
    try { return xiuxian.deleteActivity(activityId); }
    catch (e) { return { success: false, error: e.message }; }
  });
  ipcMain.handle('xiuxian-get-activities', () => {
    try { return { success: true, data: xiuxian.getAllActivities() }; }
    catch (e) { return { success: false, error: e.message }; }
  });

  // 打开修仙管理独立窗口
  ipcMain.handle('open-xiuxian-admin', () => {
    if (xiuxianAdminWindow && !xiuxianAdminWindow.isDestroyed()) {
      xiuxianAdminWindow.focus();
      return { success: true };
    }
    xiuxianAdminWindow = new BrowserWindow({
      width: 1400, height: 900, minWidth: 1000, minHeight: 700,
      title: '修仙管理后台',
      icon: path.join(__dirname, 'icon.png'),
      backgroundColor: '#0f0f23',
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        contextIsolation: true, nodeIntegration: false,
      },
    });
    xiuxianAdminWindow.setMenuBarVisibility(false);
    xiuxianAdminWindow.loadFile(path.join(__dirname, 'renderer', 'xiuxian-admin.html'));
    xiuxianAdminWindow.on('closed', () => { xiuxianAdminWindow = null; });
    console.log('[修仙管理] 独立窗口已打开');
    return { success: true };
  });

}

// ==================== 窗口创建 ====================
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100, height: 720, minWidth: 900, minHeight: 600,
    title: "小熊机器人",
    icon: path.join(__dirname, "icon.png"),
    frame: false,
    backgroundColor: "#0f0f23",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true, nodeIntegration: false,
    },
  });
  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile(path.join(__dirname, "renderer", "index.html"));
  mainWindow.on("closed", () => { mainWindow = null; });
  mainWindow.on("maximize", () => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send("window:maximized", true); });
  mainWindow.on("unmaximize", () => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send("window:maximized", false); });
}

// ==================== App 生命周期 ====================

// 全局错误处理
process.on("uncaughtException", (err) => {
  console.error("未捕获的异常:", err);
  try { addLog("error", "系统异常: " + err.message); } catch(e) {}
});
process.on("unhandledRejection", (reason, promise) => {
  console.error("未处理的Promise拒绝:", reason);
  try { addLog("error", "异步错误: " + (reason.message || reason)); } catch(e) {}
});

app.whenReady().then(() => {
  loadConfig();
  setupIpc();
  createWindow();
    // 启动定期缓存清理（清理频率限制、缓存、欢迎缓存，防止内存泄漏）
  startCacheCleanup();
  
  // 启动后自动连接机器人（延迟3秒，等待页面加载完成）
  setTimeout(() => {
    try {
      if (currentConfig) {
        // 检查是否开启了自动连接（默认关闭）
        const autoConnectEnabled = currentConfig.system && currentConfig.system.autoConnect === true;
        if (!autoConnectEnabled) {
          addLog("info", "自动连接未开启，需手动点击连接");
          return;
        }
        
        const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
        if (dualEnabled) {
          addLog("info", "启动自动连接：双模式（OneBot + 官方机器人）");
          connectBot();
          setTimeout(() => { connectOfficialBotMode(); }, 1000);
        } else {
          officialMode = currentConfig.officialMode === true;
          if (officialMode) {
            addLog("info", "启动自动连接：官方机器人模式");
            connectOfficialBotMode();
          } else {
            addLog("info", "启动自动连接：OneBot模式");
            connectBot();
          }
        }
      }
    } catch (e) {
      addLog("warn", "启动自动连接失败: " + e.message);
    }
  }, 3000);
  
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  disconnectBot();
  if (process.platform !== "darwin") app.quit();
});
