﻿// ============== 预加载脚本：IPC 桥接 v3.0 ==============
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("api", {
  // 配置
  getConfig: () => ipcRenderer.invoke("config:get"),
  saveConfig: (config) => ipcRenderer.invoke("config:save", config),
  exportConfig: () => ipcRenderer.invoke("config:export"),
  importConfig: () => ipcRenderer.invoke("config:import"),
  selectImage: () => ipcRenderer.invoke("image:select"),

  // 机器人控制
  connect: () => ipcRenderer.invoke("bot:connect"),
  disconnect: () => ipcRenderer.invoke("bot:disconnect"),
  getStatus: () => ipcRenderer.invoke("bot:status"),
  clearLogs: () => ipcRenderer.invoke("bot:clear-logs"),

  // 网站对接
  websiteTest: () => ipcRenderer.invoke("website:test"),
  websitePushNow: () => ipcRenderer.invoke("website:push-now"),
  websiteCheckNow: () => ipcRenderer.invoke("website:check-now"),

  // 推送群管理
  pushGroupsAdd: (groupId) => ipcRenderer.invoke("push-groups:add", groupId),
  pushGroupsRemove: (groupId) => ipcRenderer.invoke("push-groups:remove", groupId),

  // 群设置
  groupSettingsGet: (groupId) => ipcRenderer.invoke("group-settings:get", groupId),
  groupSettingsSave: (groupId, settings) => ipcRenderer.invoke("group-settings:save", groupId, settings),
  groupSettingsReset: (groupId) => ipcRenderer.invoke("group-settings:reset", groupId),
  groupSettingsList: () => ipcRenderer.invoke("group-settings:list"),
  getRecentGroups: () => ipcRenderer.invoke("get-recent-groups"),

  // 事件监听
  onLog: (callback) => ipcRenderer.on("bot:log", (_, data) => callback(data)),
  onStatus: (callback) => ipcRenderer.on("bot:status", (_, data) => callback(data)),
  onWindowMaximized: (callback) => ipcRenderer.on("window:maximized", (_, data) => callback(data)),
  onOfficialGroupAdded: (callback) => ipcRenderer.on("official:group_added", (_, data) => callback(data)),

  // 窗口控制
  windowMinimize: () => ipcRenderer.invoke("window:minimize"),
  windowMaximize: () => ipcRenderer.invoke("window:maximize"),
  windowClose: () => ipcRenderer.invoke("window:close"),
  windowIsMaximized: () => ipcRenderer.invoke("window:is-maximized"),

  // 在线更新
  updateGetVersion: () => ipcRenderer.invoke("update:get-version"),
  getVersion: () => ipcRenderer.invoke("update:get-version"),
    updateCheck: () => ipcRenderer.invoke("update:check"),
  updateDownload: () => ipcRenderer.invoke("update:download"),
  updateRestart: () => ipcRenderer.invoke("update:restart"),
  updateLocal: () => ipcRenderer.invoke("update:local"),

  // Warframe
  wfGetPlatform: () => ipcRenderer.invoke("warframe:get-platform"),
  wfSetPlatform: (platform) => ipcRenderer.invoke("warframe:set-platform", platform),
  
  // WF指令别名
  wfGetAliases: () => ipcRenderer.invoke("wf:get-aliases"),
  wfSaveAliases: (aliases) => ipcRenderer.invoke("wf:save-aliases", aliases),
  wfResetAliases: () => ipcRenderer.invoke("wf:reset-aliases"),
  
  // 修仙管理
  xiuxianGetStats: () => ipcRenderer.invoke("xiuxian-get-stats"),
  xiuxianGetPlayers: () => ipcRenderer.invoke("xiuxian-get-players"),
  xiuxianGetPlayerDetail: (qq) => ipcRenderer.invoke("xiuxian-get-player-detail", { qq }),
  xiuxianGetConfig: () => ipcRenderer.invoke("xiuxian-get-config"),
  xiuxianOpenConfig: () => ipcRenderer.invoke("xiuxian-open-config"),
  xiuxianGetSects: () => ipcRenderer.invoke("xiuxian-get-sects"),
  xiuxianGetMarket: () => ipcRenderer.invoke("xiuxian-get-market"),
  
  // 修仙高级管理
  xiuxianUpdatePlayer: (qq, updates) => ipcRenderer.invoke("xiuxian-update-player", { qq, updates }),
  xiuxianAddGold: (qq, amount) => ipcRenderer.invoke("xiuxian-add-gold", { qq, amount }),
  xiuxianAddExp: (qq, amount) => ipcRenderer.invoke("xiuxian-add-exp", { qq, amount }),
  xiuxianBanPlayer: (qq, reason, duration) => ipcRenderer.invoke("xiuxian-ban-player", { qq, reason, duration }),
  xiuxianUnbanPlayer: (qq) => ipcRenderer.invoke("xiuxian-unban-player", { qq }),
  xiuxianSendMail: (toQq, title, content, rewards) => ipcRenderer.invoke("xiuxian-send-mail", { toQq, title, content, rewards }),
  xiuxianSendGlobalMail: (title, content, rewards) => ipcRenderer.invoke("xiuxian-send-global-mail", { title, content, rewards }),
  xiuxianDisbandSect: (sectName) => ipcRenderer.invoke("xiuxian-disband-sect", { sectName }),
  xiuxianUpdateSectLevel: (sectName, level) => ipcRenderer.invoke("xiuxian-update-sect-level", { sectName, level }),
  xiuxianUpdateSectAnnouncement: (sectName, announcement) => ipcRenderer.invoke("xiuxian-update-sect-announcement", { sectName, announcement }),
  xiuxianRemoveMarketItem: (itemId) => ipcRenderer.invoke("xiuxian-remove-market-item", { itemId }),
  xiuxianExportPlayers: (format) => ipcRenderer.invoke("xiuxian-export-players", { format }),
  xiuxianCreateActivity: (name, type, value, startTime, endTime, description) => ipcRenderer.invoke("xiuxian-create-activity", { name, type, value, startTime, endTime, description }),
  xiuxianUpdateActivity: (activityId, updates) => ipcRenderer.invoke("xiuxian-update-activity", { activityId, updates }),
  xiuxianDeleteActivity: (activityId) => ipcRenderer.invoke("xiuxian-delete-activity", { activityId }),
  xiuxianGetActivities: () => ipcRenderer.invoke("xiuxian-get-activities"),
  xiuxianGetActiveActivities: () => ipcRenderer.invoke("xiuxian-get-active-activities"),
  
  // 修仙物品装备管理
  xiuxianGetItems: (type) => ipcRenderer.invoke("xiuxian-get-items", { type }),
  
  // 修仙高级系统管理
  xiuxianGetAdvancedData: (type) => ipcRenderer.invoke("xiuxian-get-advanced-data", { type }),
  
  // 修仙限时活动管理
  xiuxianGetTimelimitItems: (type) => ipcRenderer.invoke("xiuxian-get-timelimit-items", { type }),
  
  // 修仙玩家详情管理
  xiuxianUpdatePlayerAttributes: (qq, updates) => ipcRenderer.invoke("xiuxian-update-player-attributes", { qq, updates }),
  xiuxianResetPlayer: (qq) => ipcRenderer.invoke("xiuxian-reset-player", { qq }),
  
  // 打开修仙管理独立窗口
  openXiuxianAdmin: () => ipcRenderer.invoke("open-xiuxian-admin"),
  
  // 修仙配置管理
  xiuxianSaveConfig: (configJson) => ipcRenderer.invoke("xiuxian-save-config", { configJson }),
  xiuxianGetConfigRaw: () => ipcRenderer.invoke("xiuxian-get-config-raw"),
  
  // 修仙宗门管理
  xiuxianGetSectMembers: (sectName) => ipcRenderer.invoke("xiuxian-get-sect-members", { sectName }),
  xiuxianRemoveSectMember: (qq) => ipcRenderer.invoke("xiuxian-remove-sect-member", { qq }),
  
  // 修仙系统功能
  xiuxianGetOperationLogs: (limit) => ipcRenderer.invoke("xiuxian-get-operation-logs", { limit }),
  xiuxianBackupData: () => ipcRenderer.invoke("xiuxian-backup-data"),
  xiuxianGetBackups: () => ipcRenderer.invoke("xiuxian-get-backups"),
  xiuxianGetStatsDashboard: () => ipcRenderer.invoke("xiuxian-get-stats-dashboard"),
});
