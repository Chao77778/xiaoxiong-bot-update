﻿// ==================== 超级小莲风格图片生成器（JavaScript版）====================
// 移植自 superlotus/utils/text_to_image.py
// 使用 node-canvas 实现相同的配色方案和排版效果
// 包含5个专门的图片生成方法，每个功能有不同的UI样式

const { createCanvas, registerFont, loadImage } = require("@napi-rs/canvas");
const path = require("path");
const fs = require("fs");

// 注册字体（使用系统字体，确保中文正常显示）
const FONT_FAMILY = "Microsoft YaHei, SimHei, sans-serif";

// 背景图片目录
const BG_DIR = path.join(__dirname, "data", "backgrounds");

class TextToImageConverter {
  constructor() {
    // 配置 - 450宽度，字体分级
    this.fontSize = 16;           // 正文字体 (T4)
    this.titleFontSize = 40;      // 标题字体 (T1)
    this.tierFontSize = 18;       // 等级标题字体
    this.taskFontSize = 20;       // 深层科研任务字体
    this.timestampFontSize = 12;  // 时间标注字体
    this.lineSpacing = 8;         // 行间距
    this.padding = 15;            // 边距
    this.maxWidth = 450;          // 默认宽度
    
    // 背景图片缓存
    this._bgCache = {};
    this._bgLoading = {};

    // 猫娘风格配色方案
    this.colors = {
      bg: "#FFF8FC",              // 极浅粉色背景
      text: "#645078",            // 深紫色文字
      title: "#FF8CB4",           // 浅粉色标题
      tier: "#C850A0",            // 玫紫色等级标题
      steel: "#FF6478",           // 粉红色钢铁任务
      normal: "#A08CDC",          // 淡紫色普通任务
      stats: "#8C78A0",           // 中紫色统计信息
      border: "#FFB4C8",          // 浅粉色边框
      timestamp: "#FF5050",       // 时间标注红色

      // 赏金任务配色
      bountyTitle: "#FF6478",
      bountyTask: "#B464C8",
      bountyDesc: "#6478B4",
      bountyZariman: "#FF8C64",
      bountyEntra: "#64B4A0",
      bountyHex: "#B464B4",

      // 深层科研配色
      archimedeaTitle: "#FF7850",
      archimedeaTask: "#B478C8",
      archimedeaCondition: "#648CB4",
      archimedeaVar: "#64B48C",

      // 市场报告配色
      marketWarframe: "#FF8C50",
      marketWeapon: "#50B48C",
      marketMod: "#8C64C8",

      // 日历配色
      calendarDate: "#FF7864",
      calendarChallenge: "#B464C8",
      calendarDesc: "#6478A0",
      calendarReward: "#64B48C",
      calendarUpgrade: "#C88C50",

      // 午夜电波配色
      nightwaveDaily: "#FF8C64",
      nightwaveWeekly: "#64B4A0",
      nightwaveElite: "#B464C8",

      // 平原专用配色（紫色系）
      plainBg: "#FFF8FC",
      plainText: "#645078",
      plainTitle: "#B464C8",
      plainSection: "#A050B4",
      plainTime: "#DC5064",
      plainBorder: "#DCB4DC",

      // 紫卡专用配色（紫色系）
      rivenBg: "#FFF8FC",
      rivenText: "#645078",
      rivenTitle: "#B464C8",
      rivenSection: "#A050B4",
      rivenPrice: "#DC5064",
      rivenBorder: "#DCB4DC",
      rivenSeller: "#64A064",
      rivenHint: "#C878A0"
    };

    // T1-T4 统一样式配置
    this.TStyles = {
      T1: { fontSize: 40, color: this.colors.title, align: "center" },
      T2: { fontSize: 22, color: "#FF8C64", align: "left" },
      T3: { fontSize: 20, color: this.colors.bountyTask, align: "left" },
      T4: { fontSize: 16, color: this.colors.bountyDesc, align: "left" }
    };
    
    // 当前功能类型，用于选择不同的人物形象
    // list: 列表型（裂缝、警报、入侵、钢铁侵袭）-> 妖娆坐姿
    // detail: 详情型（科研、午夜电波、赏金）-> 妖娆站姿
    // query: 查询型（平原时间、紫卡、market）-> 妖娆跪姿
    // default: 默认 -> 参考图形象
    this.currentFunction = "default";
  }
  
  // ==================== 背景图片方法 ====================
  
  // 预加载人物形象，把纯色背景变成透明
  async preloadBackgrounds() {
    // 需要预加载的人物形象列表
    const characters = [
      { key: "default", file: "character_reference.png" },
      { key: "sit", file: "character_seductive_sit.png" },
      { key: "stand", file: "character_seductive_stand.png" },
      { key: "kneel", file: "character_seductive_kneel.png" },
      { key: "help", file: "character_help.png" }
    ];
    
    for (const char of characters) {
      const charPath = path.join(BG_DIR, char.file);
      if (fs.existsSync(charPath) && !this._bgCache[char.key]) {
        try {
          if (char.key === "help") {
            // help人物形象已经是透明背景PNG，直接加载
            const buffer = fs.readFileSync(charPath);
            const image = await loadImage(buffer);
            const canvas = createCanvas(image.width, image.height);
            const ctx = canvas.getContext("2d");
            ctx.drawImage(image, 0, 0);
            this._bgCache[char.key] = canvas;
            console.log("人物形象预加载完成(直接加载):", char.key, "(", char.file, ")");
          } else {
            const canvas = await this._makeCharacterTransparent(charPath);
            this._bgCache[char.key] = canvas;
            console.log("人物形象预加载完成:", char.key, "(", char.file, ")");
          }
        } catch (e) {
          console.error("预加载人物形象失败", char.key, ":", e.message);
        }
      }
    }
  }
  
  // 把人物图片的背景替换成画布背景色 #FFF8FC（这样贴在纯色背景上就完全看不出背景了）
  async _makeCharacterTransparent(imagePath) {
    const buffer = fs.readFileSync(imagePath);
    const image = await loadImage(buffer);
    
    const tempCanvas = createCanvas(image.width, image.height);
    const tempCtx = tempCanvas.getContext("2d");
    tempCtx.drawImage(image, 0, 0);
    
    const imageData = tempCtx.getImageData(0, 0, image.width, image.height);
    const data = imageData.data;
    const width = image.width;
    const height = image.height;
    
    // 第一步：从四个角和边缘取样，检测主要背景颜色
    const samplePoints = [
      {x: 5, y: 5},
      {x: width - 5, y: 5},
      {x: 5, y: height - 5},
      {x: width - 5, y: height - 5},
      {x: Math.floor(width / 2), y: 5},
      {x: 5, y: Math.floor(height / 2)},
      {x: width - 5, y: Math.floor(height / 2)},
      {x: Math.floor(width / 2), y: height - 5}
    ];
    
    let bgR = 0, bgG = 0, bgB = 0;
    for (const point of samplePoints) {
      const idx = (point.y * width + point.x) * 4;
      bgR += data[idx];
      bgG += data[idx + 1];
      bgB += data[idx + 2];
    }
    bgR = Math.round(bgR / samplePoints.length);
    bgG = Math.round(bgG / samplePoints.length);
    bgB = Math.round(bgB / samplePoints.length);
    
    console.log("检测到主要背景颜色: R=" + bgR + ", G=" + bgG + ", B=" + bgB);
    
    // 判断是否是近白色背景（R>245, G>225, B>225，包括偏粉的白色）
    const isWhiteBackground = (bgR > 245 && bgG > 225 && bgB > 225);
    
    if (isWhiteBackground) {
      // 近白色背景：使用洪水填充从边缘开始，只把与边缘相连的近白色像素变成透明
      // 这样人物内部的浅色部分（脸、身体）因为被轮廓包围，不会被变成透明
      console.log("检测到近白色背景，使用洪水填充透明处理");
      
      const whiteThreshold = 30; // 白色阈值，更小，避免渗透到头部和尾巴的浅色高光
      const visited = new Uint8Array(width * height);
      const queue = [];
      
      // 从四条边缘开始
      for (let x = 0; x < width; x++) {
        queue.push({x, y: 0});
        queue.push({x, y: height - 1});
      }
      for (let y = 0; y < height; y++) {
        queue.push({x: 0, y});
        queue.push({x: width - 1, y});
      }
      
      let transparentCount = 0;
      
      while (queue.length > 0) {
        const {x, y} = queue.pop();
        const idx = y * width + x;
        
        if (visited[idx]) continue;
        visited[idx] = 1;
        
        const pixelIdx = idx * 4;
        const r = data[pixelIdx];
        const g = data[pixelIdx + 1];
        const b = data[pixelIdx + 2];
        
        // 判断是否接近白色（RGB都大于255-threshold）
        if (r > 255 - whiteThreshold && g > 255 - whiteThreshold && b > 255 - whiteThreshold) {
          data[pixelIdx + 3] = 0; // 完全透明
          transparentCount++;
          
          // 向四周扩散
          if (x > 0 && !visited[idx - 1]) queue.push({x: x - 1, y});
          if (x < width - 1 && !visited[idx + 1]) queue.push({x: x + 1, y});
          if (y > 0 && !visited[idx - width]) queue.push({x, y: y - 1});
          if (y < height - 1 && !visited[idx + width]) queue.push({x, y: y + 1});
        }
      }
      
      console.log("已将", transparentCount, "个近白色背景像素变成完全透明（洪水填充）");
      
      tempCtx.putImageData(imageData, 0, 0);
      return tempCanvas;
    }
    
    // 非纯白色背景：使用之前的洪水填充 + 背景色替换方法
    const totalPixels = width * height;
    const targetPixels = Math.floor(totalPixels * 0.25);
    
    let bestThreshold = 8;
    for (let testThreshold = 8; testThreshold <= 40; testThreshold += 2) {
      const testVisited = new Uint8Array(width * height);
      const testQueue = [];
      
      for (let x = 0; x < width; x++) {
        testQueue.push({x, y: 0});
        testQueue.push({x, y: height - 1});
      }
      for (let y = 0; y < height; y++) {
        testQueue.push({x: 0, y});
        testQueue.push({x: width - 1, y});
      }
      
      let testCount = 0;
      while (testQueue.length > 0) {
        const {x, y} = testQueue.pop();
        const idx = y * width + x;
        
        if (testVisited[idx]) continue;
        testVisited[idx] = 1;
        
        const pixelIdx = idx * 4;
        const r = data[pixelIdx];
        const g = data[pixelIdx + 1];
        const b = data[pixelIdx + 2];
        
        const dist = Math.sqrt(
          Math.pow(r - bgR, 2) + 
          Math.pow(g - bgG, 2) + 
          Math.pow(b - bgB, 2)
        );
        
        if (dist < testThreshold) {
          testCount++;
          if (x > 0 && !testVisited[idx - 1]) testQueue.push({x: x - 1, y});
          if (x < width - 1 && !testVisited[idx + 1]) testQueue.push({x: x + 1, y});
          if (y > 0 && !testVisited[idx - width]) testQueue.push({x, y: y - 1});
          if (y < height - 1 && !testVisited[idx + width]) testQueue.push({x, y: y + 1});
        }
      }
      
      if (testCount >= targetPixels) {
        bestThreshold = testThreshold;
        break;
      }
      bestThreshold = testThreshold;
    }
    
    console.log("自动检测阈值:", bestThreshold);
    
    // 第三步：使用洪水填充，把与边缘相连的背景像素替换成画布背景色 #FFF8FC
    const visited = new Uint8Array(width * height);
    const queue = [];
    
    for (let x = 0; x < width; x++) {
      queue.push({x, y: 0});
      queue.push({x, y: height - 1});
    }
    for (let y = 0; y < height; y++) {
      queue.push({x: 0, y});
      queue.push({x: width - 1, y});
    }
    
    let replacedCount = 0;
    
    while (queue.length > 0) {
      const {x, y} = queue.pop();
      const idx = y * width + x;
      
      if (visited[idx]) continue;
      visited[idx] = 1;
      
      const pixelIdx = idx * 4;
      const r = data[pixelIdx];
      const g = data[pixelIdx + 1];
      const b = data[pixelIdx + 2];
      
      const dist = Math.sqrt(
        Math.pow(r - bgR, 2) + 
        Math.pow(g - bgG, 2) + 
        Math.pow(b - bgB, 2)
      );
      
      if (dist < bestThreshold) {
        // 替换成画布背景色 #FFF8FC
        data[pixelIdx] = 255;
        data[pixelIdx + 1] = 248;
        data[pixelIdx + 2] = 252;
        data[pixelIdx + 3] = 255;
        replacedCount++;
        
        if (x > 0 && !visited[idx - 1]) queue.push({x: x - 1, y});
        if (x < width - 1 && !visited[idx + 1]) queue.push({x: x + 1, y});
        if (y > 0 && !visited[idx - width]) queue.push({x, y: y - 1});
        if (y < height - 1 && !visited[idx + width]) queue.push({x, y: y + 1});
      }
    }
    
    // 第四步：边缘膨胀处理，把人物边缘的背景残留也替换掉
    // 遍历所有像素，如果一个像素周围有被替换的背景像素，并且颜色接近背景色，也替换掉
    const expandIterations = 10; // 膨胀10次，确保人物周围的背景残留都处理干净
    for (let iter = 0; iter < expandIterations; iter++) {
      const toReplace = [];
      
      for (let y = 1; y < height - 1; y++) {
        for (let x = 1; x < width - 1; x++) {
          const idx = y * width + x;
          const pixelIdx = idx * 4;
          
          // 如果已经是画布背景色，跳过
          if (data[pixelIdx] === 255 && data[pixelIdx + 1] === 248 && data[pixelIdx + 2] === 252) continue;
          
          // 检查周围8个像素是否有画布背景色
          let hasBgNeighbor = false;
          for (let dy = -1; dy <= 1; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
              if (dx === 0 && dy === 0) continue;
              const nIdx = (y + dy) * width + (x + dx);
              const nPixelIdx = nIdx * 4;
              if (data[nPixelIdx] === 255 && data[nPixelIdx + 1] === 248 && data[nPixelIdx + 2] === 252) {
                hasBgNeighbor = true;
                break;
              }
            }
            if (hasBgNeighbor) break;
          }
          
          // 如果周围有背景色，并且当前颜色接近背景色，也替换掉
          if (hasBgNeighbor) {
            const r = data[pixelIdx];
            const g = data[pixelIdx + 1];
            const b = data[pixelIdx + 2];
            const dist = Math.sqrt(
              Math.pow(r - bgR, 2) + 
              Math.pow(g - bgG, 2) + 
              Math.pow(b - bgB, 2)
            );
            if (dist < bestThreshold + 25) { // 膨胀时阈值大很多，确保处理干净
              toReplace.push(idx);
            }
          }
        }
      }
      
      for (const idx of toReplace) {
        const pixelIdx = idx * 4;
        data[pixelIdx] = 255;
        data[pixelIdx + 1] = 248;
        data[pixelIdx + 2] = 252;
        data[pixelIdx + 3] = 255;
        replacedCount++;
      }
    }
    
    console.log("已将", replacedCount, "个背景像素替换成画布背景色 #FFF8FC（包括膨胀处理）");
    
    tempCtx.putImageData(imageData, 0, 0);
    return tempCanvas;
  }
  
  // 绘制背景（渐变背景+装饰光点+右边人物形象，根据功能类型选择不同人物）
  drawBackground(ctx, width, height, bgName = "daily", overlayOpacity = 0.75) {
    // 绘制背景
    if (this.currentFunction === "help") {
      // 帮助菜单：纯白色背景
      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(0, 0, width, height);
    } else {
      // 日常风格：从上到下的浅粉渐变背景
      const gradient = ctx.createLinearGradient(0, 0, 0, height);
      gradient.addColorStop(0, "#FFF0F6"); // 顶部稍深的粉色
      gradient.addColorStop(0.5, "#FFF8FC"); // 中间原色
      gradient.addColorStop(1, "#FFF0F6"); // 底部稍深的粉色
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);
    }
    
    // 绘制装饰光点（半透明的粉色光点，增加梦幻感）
    this._drawDecorativeDots(ctx, width, height);
    
    // 根据功能类型选择人物形象
    // list: 列表型 -> 妖娆坐姿
    // detail: 详情型 -> 妖娆站姿
    // query: 查询型 -> 妖娆跪姿
    // default: 默认 -> 参考图形象
    let charKey = "default";
    let charWidthRatio = 0.6; // 默认人物宽度比例
    
    if (this.currentFunction === "list") {
      charKey = "sit";
      charWidthRatio = 0.55; // 列表型内容多，人物小一点
    } else if (this.currentFunction === "detail") {
      charKey = "stand";
      charWidthRatio = 0.58; // 详情型内容中等
    } else if (this.currentFunction === "query") {
      charKey = "kneel";
      charWidthRatio = 0.6; // 查询型内容少，人物大一点
    } else if (this.currentFunction === "help") {
      charKey = "help";
      charWidthRatio = 0.7; // 帮助菜单人物更大
    }
    
    // 高度判断：图片高度小于500px时不显示人物形象（避免短文本图片人物太大不协调）
    const minHeightForCharacter = 500;
    if (height < minHeightForCharacter) {
      console.log("[图片生成] 图片高度不足", height, "px，不显示人物形象");
      return;
    }
    
    // 在右边绘制人物形象（背景已透明，自然融合）
    const charCanvas = this._bgCache[charKey];
    if (charCanvas) {
      const charWidth = width * charWidthRatio;
      const scale = charWidth / charCanvas.width;
      const scaledWidth = charWidth;
      const scaledHeight = charCanvas.height * scale;
      const x = width - scaledWidth; // 右对齐
      const y = height - scaledHeight; // 底部对齐
      
      ctx.drawImage(charCanvas, x, y, scaledWidth, scaledHeight);
    }
  }
  
  // 绘制装饰光点（半透明的粉色光点，增加梦幻感）
  _drawDecorativeDots(ctx, width, height) {
    // 使用固定的伪随机数，确保每次生成的图片光点位置一致
    const dots = [
      {x: 0.08, y: 0.12, r: 3, a: 0.3},
      {x: 0.15, y: 0.25, r: 2, a: 0.25},
      {x: 0.05, y: 0.45, r: 4, a: 0.2},
      {x: 0.12, y: 0.65, r: 2.5, a: 0.3},
      {x: 0.08, y: 0.85, r: 3, a: 0.25},
      {x: 0.2, y: 0.08, r: 2, a: 0.2},
      {x: 0.25, y: 0.55, r: 3.5, a: 0.15},
      {x: 0.18, y: 0.78, r: 2, a: 0.3},
      {x: 0.3, y: 0.15, r: 2.5, a: 0.2},
      {x: 0.35, y: 0.88, r: 3, a: 0.25},
      {x: 0.02, y: 0.35, r: 2, a: 0.3},
      {x: 0.22, y: 0.42, r: 1.5, a: 0.35}
    ];
    
    for (const dot of dots) {
      const x = width * dot.x;
      const y = height * dot.y;
      const r = dot.r;
      const a = dot.a;
      
      // 绘制光点（径向渐变，中心亮，边缘透明）
      const dotGradient = ctx.createRadialGradient(x, y, 0, x, y, r * 2);
      dotGradient.addColorStop(0, `rgba(255, 180, 200, ${a})`);
      dotGradient.addColorStop(0.5, `rgba(255, 200, 220, ${a * 0.5})`);
      dotGradient.addColorStop(1, "rgba(255, 220, 230, 0)");
      ctx.fillStyle = dotGradient;
      ctx.beginPath();
      ctx.arc(x, y, r * 2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // ==================== 工具方法 ====================

  // 绘制美化标题（纯渐变文字 + 左右装饰线，去掉背景框）
  _drawStyledTitle(ctx, title, maxWidth, y, titleFontSize, titleColor) {
    const titleWidth = this._getTextWidth(title, titleFontSize);
    const x = (maxWidth - titleWidth) / 2;
    
    // 绘制标题左右装饰线（带渐变效果）
    const lineY = y + titleFontSize / 2;
    const lineLength = 40;
    const lineGap = 15;
    
    // 左边装饰线（从透明到粉色渐变）
    const leftGradient = ctx.createLinearGradient(x - lineGap - lineLength, lineY, x - lineGap, lineY);
    leftGradient.addColorStop(0, "rgba(255, 150, 180, 0)");
    leftGradient.addColorStop(1, "rgba(255, 150, 180, 0.6)");
    ctx.strokeStyle = leftGradient;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x - lineGap - lineLength, lineY);
    ctx.lineTo(x - lineGap, lineY);
    ctx.stroke();
    
    // 右边装饰线（从粉色到透明渐变）
    const rightGradient = ctx.createLinearGradient(x + titleWidth + lineGap, lineY, x + titleWidth + lineGap + lineLength, lineY);
    rightGradient.addColorStop(0, "rgba(255, 150, 180, 0.6)");
    rightGradient.addColorStop(1, "rgba(255, 150, 180, 0)");
    ctx.strokeStyle = rightGradient;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x + titleWidth + lineGap, lineY);
    ctx.lineTo(x + titleWidth + lineGap + lineLength, lineY);
    ctx.stroke();
    
    // 绘制装饰线两端的小星星
    const starSize = 3;
    ctx.fillStyle = "rgba(255, 150, 180, 0.7)";
    this._drawStar(ctx, x - lineGap - lineLength, lineY, starSize);
    this._drawStar(ctx, x + titleWidth + lineGap + lineLength, lineY, starSize);
    
    // 绘制渐变标题文字
    const textGradient = ctx.createLinearGradient(x, y, x, y + titleFontSize);
    textGradient.addColorStop(0, titleColor || "#FF6B9D");
    textGradient.addColorStop(0.5, "#FF8CB4");
    textGradient.addColorStop(1, "#FF6B9D");
    
    ctx.font = `${titleFontSize}px ${FONT_FAMILY}`;
    ctx.fillStyle = textGradient;
    ctx.fillText(title, x, y + titleFontSize);
    
    return y + titleFontSize + this.lineSpacing * 2;
  }
  
  // 绘制小星星
  _drawStar(ctx, cx, cy, r) {
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const angle = (i * 4 * Math.PI) / 5 - Math.PI / 2;
      const x = cx + Math.cos(angle) * r;
      const y = cy + Math.sin(angle) * r;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
  }
  
  // 绘制美化时间戳（带背景条）
  _drawStyledTimestamp(ctx, maxWidth, y) {
    const timestamp = this._getTimestampText();
    ctx.font = `${this.timestampFontSize}px ${FONT_FAMILY}`;
    const textWidth = ctx.measureText(timestamp).width;
    
    // 绘制时间戳背景条
    const bgPaddingX = 8;
    const bgPaddingY = 3;
    const bgX = maxWidth - textWidth - this.padding - bgPaddingX;
    const bgY = y - bgPaddingY;
    const bgWidth = textWidth + bgPaddingX * 2;
    const bgHeight = this.timestampFontSize + bgPaddingY * 2;
    
    ctx.fillStyle = "rgba(255, 180, 200, 0.25)";
    ctx.beginPath();
    ctx.roundRect(bgX, bgY, bgWidth, bgHeight, 4);
    ctx.fill();
    
    // 绘制时间戳文字
    ctx.fillStyle = this.colors.timestamp;
    ctx.fillText(timestamp, maxWidth - textWidth - this.padding, y + this.timestampFontSize);
  }
  
  _getTimestampText() {
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const seconds = String(now.getSeconds()).padStart(2, "0");
    return `小熊机器人 ${month}-${day} ${hours}:${minutes}:${seconds}`;
  }

  _getTextWidth(text, fontSize) {
    const canvas = createCanvas(1, 1);
    const ctx = canvas.getContext("2d");
    ctx.font = `${fontSize}px ${FONT_FAMILY}`;
    return ctx.measureText(text).width;
  }

  _wrapText(text, fontSize, maxWidth) {
    const words = text.split("");
    const lines = [];
    let currentLine = "";

    for (const char of words) {
      const testLine = currentLine + char;
      if (this._getTextWidth(testLine, fontSize) > maxWidth && currentLine) {
        lines.push(currentLine);
        currentLine = char;
      } else {
        currentLine = testLine;
      }
    }
    if (currentLine) lines.push(currentLine);
    return lines;
  }

  _drawTimestamp(ctx, maxWidth, y) {
    const timestamp = this._getTimestampText();
    ctx.font = `${this.timestampFontSize}px ${FONT_FAMILY}`;
    ctx.fillStyle = this.colors.timestamp;
    const textWidth = ctx.measureText(timestamp).width;
    ctx.fillText(timestamp, maxWidth - textWidth - this.padding, y + this.timestampFontSize);
  }

  _drawBorder(ctx, maxWidth, totalHeight, color) {
    const borderColor = color || this.colors.border;
    const cornerRadius = 12; // 圆角半径
    
    // 绘制外层圆角边框
    ctx.strokeStyle = borderColor;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cornerRadius, 1);
    ctx.lineTo(maxWidth - cornerRadius, 1);
    ctx.quadraticCurveTo(maxWidth - 1, 1, maxWidth - 1, cornerRadius);
    ctx.lineTo(maxWidth - 1, totalHeight - cornerRadius);
    ctx.quadraticCurveTo(maxWidth - 1, totalHeight - 1, maxWidth - cornerRadius, totalHeight - 1);
    ctx.lineTo(cornerRadius, totalHeight - 1);
    ctx.quadraticCurveTo(1, totalHeight - 1, 1, totalHeight - cornerRadius);
    ctx.lineTo(1, cornerRadius);
    ctx.quadraticCurveTo(1, 1, cornerRadius, 1);
    ctx.closePath();
    ctx.stroke();
    
    // 绘制内层虚线边框
    ctx.strokeStyle = "rgba(255, 180, 200, 0.4)";
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    const innerOffset = 5;
    const innerRadius = cornerRadius - 3;
    ctx.moveTo(innerOffset + innerRadius, innerOffset);
    ctx.lineTo(maxWidth - innerOffset - innerRadius, innerOffset);
    ctx.quadraticCurveTo(maxWidth - innerOffset, innerOffset, maxWidth - innerOffset, innerOffset + innerRadius);
    ctx.lineTo(maxWidth - innerOffset, totalHeight - innerOffset - innerRadius);
    ctx.quadraticCurveTo(maxWidth - innerOffset, totalHeight - innerOffset, maxWidth - innerOffset - innerRadius, totalHeight - innerOffset);
    ctx.lineTo(innerOffset + innerRadius, totalHeight - innerOffset);
    ctx.quadraticCurveTo(innerOffset, totalHeight - innerOffset, innerOffset, totalHeight - innerOffset - innerRadius);
    ctx.lineTo(innerOffset, innerOffset + innerRadius);
    ctx.quadraticCurveTo(innerOffset, innerOffset, innerOffset + innerRadius, innerOffset);
    ctx.closePath();
    ctx.stroke();
    ctx.setLineDash([]);
    
    // 绘制角落装饰（小星星）
    this._drawCornerDecorations(ctx, maxWidth, totalHeight);
  }
  
  // 绘制角落装饰（小星星/蝴蝶结）
  _drawCornerDecorations(ctx, maxWidth, totalHeight) {
    const decorations = [
      {x: 8, y: 8},
      {x: maxWidth - 8, y: 8},
      {x: 8, y: totalHeight - 8},
      {x: maxWidth - 8, y: totalHeight - 8}
    ];
    
    for (const dec of decorations) {
      ctx.save();
      ctx.translate(dec.x, dec.y);
      
      // 绘制小五角星
      ctx.fillStyle = "rgba(255, 150, 180, 0.6)";
      ctx.beginPath();
      for (let i = 0; i < 5; i++) {
        const angle = (i * 4 * Math.PI) / 5 - Math.PI / 2;
        const r = i % 2 === 0 ? 4 : 2;
        const x = Math.cos(angle) * r;
        const y = Math.sin(angle) * r;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      
      ctx.restore();
    }
  }

  // ==================== 方法1: convertSimple（通用转换）====================
  // 支持日历、午夜电波、赏金等多种格式

  convertSimple(text, title = "", maxWidth = null, noWrap = false) {
    if (maxWidth === null) maxWidth = this.maxWidth;
    
    // 根据标题自动判断功能类型，选择不同的人物形象
    // list: 列表型（裂缝、警报、入侵、钢铁侵袭）-> 妖娆坐姿
    // detail: 详情型（科研、午夜电波、赏金）-> 妖娆站姿
    // query: 查询型（平原时间、紫卡、market）-> 妖娆跪姿
    const titleLower = title.toLowerCase();
    if (titleLower.includes("裂缝") || titleLower.includes("警报") || titleLower.includes("入侵") || 
        titleLower.includes("钢铁") || titleLower.includes("侵袭") || titleLower.includes("void") ||
        titleLower.includes("fissure") || titleLower.includes("alert") || titleLower.includes("invasion")) {
      this.currentFunction = "list";
    } else if (titleLower.includes("科研") || titleLower.includes("电波") || titleLower.includes("赏金") ||
               titleLower.includes("research") || titleLower.includes("nightwave") || titleLower.includes("bounty") ||
               titleLower.includes("archimedea")) {
      this.currentFunction = "detail";
    } else if (titleLower.includes("平原") || titleLower.includes("紫卡") || titleLower.includes("market") ||
               titleLower.includes("riven") || titleLower.includes("wm") || titleLower.includes("plain")) {
      this.currentFunction = "query";
    } else if (titleLower.includes("功能菜单") || titleLower.includes("帮助")) {
      this.currentFunction = "help";
    } else {
      this.currentFunction = "default";
    }
    
    // 帮助格式：使用分栏显示
    if (this.currentFunction === "help") {
      return this.convertHelp(text, title, maxWidth);
    }

    const lines = text.split("\n");
    const formattedLines = [];

    let inBountySection = false;
    let lastWasBountyTask = false;
    let inArchimedeaSection = false;
    let inCalendarSection = false;
    let inNightwaveSection = false;
    let inVoidTraderSection = false;

    for (let line of lines) {
      const lineStripped = line.trim();

      if (!lineStripped) {
        formattedLines.push({ content: "", type: "spacer" });
        continue;
      }

      // 检测区域
      if (lineStripped.includes("赏金任务") || lineStripped.includes("【地球") || lineStripped.includes("【金星") || lineStripped.includes("【火卫二") || lineStripped.includes("【扎里曼") || lineStripped.includes("【英择谛") || lineStripped.includes("【1999】")) {
        inBountySection = true;
        inArchimedeaSection = false;
        inCalendarSection = false;
        inNightwaveSection = false;
      }
      if (lineStripped.includes("深层科研") || lineStripped.includes("时光科研")) {
        inArchimedeaSection = true;
        inBountySection = false;
      }
      if (lineStripped.includes("日历") || lineStripped.includes("今日活动")) {
        inCalendarSection = true;
        inBountySection = false;
      }
      if (lineStripped.includes("午夜电波") || lineStripped.includes("每日挑战") || lineStripped.includes("每周挑战")) {
        inNightwaveSection = true;
        inBountySection = false;
      }

      // 行类型识别
      let type = "text";

      // 标题行（【...】）
      if (lineStripped.startsWith("【") && lineStripped.endsWith("】")) {
        if (inBountySection) {
          type = "bounty_title";
        } else if (inArchimedeaSection) {
          type = "archimedea_title";
        } else if (inCalendarSection) {
          type = "calendar_header";
        } else if (inNightwaveSection) {
          type = "nightwave_title";
        } else {
          type = "title";
        }
        formattedLines.push({ content: lineStripped, type });
        lastWasBountyTask = false;
        continue;
      }

      // 任务行（数字开头）
      if (/^\d+\./.test(lineStripped)) {
        if (inBountySection) {
          type = "bounty_task";
          lastWasBountyTask = true;
        } else if (inArchimedeaSection) {
          type = "archimedea_task";
        } else if (inNightwaveSection) {
          type = "nightwave_challenge";
        } else {
          type = "task";
        }
        formattedLines.push({ content: lineStripped, type });
        continue;
      }

      // 描述行（缩进或包含特定关键词）
      if (lineStripped.startsWith("  ") || lineStripped.includes("段位") || lineStripped.includes("奖励") || lineStripped.includes("条件")) {
        if (inBountySection && lastWasBountyTask) {
          type = "bounty_desc";
        } else if (inArchimedeaSection) {
          type = "archimedea_condition";
        } else {
          type = "desc";
        }
        formattedLines.push({ content: lineStripped, type });
        continue;
      }

      // 午夜电波挑战
      if (inNightwaveSection && lineStripped.includes("[声望+")) {
        type = "nightwave_challenge";
        formattedLines.push({ content: lineStripped, type });
        continue;
      }

      // 日历相关
      if (inCalendarSection) {
        if (lineStripped.includes("剩余") || lineStripped.includes("结束")) {
          type = "calendar_countdown";
        } else if (lineStripped.match(/^\d+月\d+日/)) {
          type = "calendar_date";
        } else {
          type = "calendar_desc";
        }
        formattedLines.push({ content: lineStripped, type });
        continue;
      }

      // 普通文本
      formattedLines.push({ content: lineStripped, type: "text" });
      lastWasBountyTask = false;
    }

    // 计算图片高度
    let totalHeight = this.padding * 2;

    // 标题高度（自动缩小）
    let titleFontSize = this.titleFontSize;
    if (title) {
      const availableWidth = maxWidth - this.padding * 2;
      while (this._getTextWidth(title, titleFontSize) > availableWidth && titleFontSize > 16) {
        titleFontSize -= 2;
      }
      totalHeight += titleFontSize + this.lineSpacing * 2;
    }

    // noWrap模式：计算所有行的宽度，找到最长的一行，自适应宽度
    if (noWrap) {
      let maxLineWidth = 0;
      for (const { content, type } of formattedLines) {
        if (!content.trim()) continue;
        let fontSize = this.fontSize;
        switch (type) {
          case "title":
          case "bounty_title":
          case "archimedea_title":
          case "calendar_header":
          case "nightwave_title":
            fontSize = this.tierFontSize;
            break;
          case "bounty_task":
          case "archimedea_task":
          case "task":
            fontSize = this.taskFontSize;
            break;
          default:
            fontSize = this.fontSize;
        }
        const lineWidth = this._getTextWidth(content, fontSize);
        if (lineWidth > maxLineWidth) maxLineWidth = lineWidth;
      }
      // 标题也要计算
      if (title) {
        const titleWidth = this._getTextWidth(title, this.titleFontSize);
        if (titleWidth > maxLineWidth) maxLineWidth = titleWidth;
      }
      // 设置宽度为最长行宽度 + 边距，最小450
      maxWidth = Math.max(450, maxLineWidth + this.padding * 2);
    }

    // 正文高度
    for (const { content, type } of formattedLines) {
      if (!content.trim()) {
        totalHeight += this.lineSpacing;
        continue;
      }

      let fontSize = this.fontSize;
      switch (type) {
        case "title":
        case "bounty_title":
        case "archimedea_title":
        case "calendar_header":
        case "nightwave_title":
          fontSize = this.tierFontSize;
          break;
        case "bounty_task":
        case "archimedea_task":
        case "task":
          fontSize = this.taskFontSize;
          break;
        default:
          fontSize = this.fontSize;
      }

      // 自动换行（noWrap模式下不换行）
      if (noWrap) {
        totalHeight += fontSize + this.lineSpacing;
      } else {
        const availableWidth = maxWidth - this.padding * 2;
        const wrappedLines = this._wrapText(content, fontSize, availableWidth);
        totalHeight += (fontSize + this.lineSpacing) * wrappedLines.length;
      }
    }

    // 时间标注高度
    totalHeight += this.timestampFontSize + this.lineSpacing * 2;
    
    // 最小高度逻辑：
    // - 内容高度 >= 500px：会显示人物，保持较大最小高度确保人物完整
    // - 内容高度 < 500px：不显示人物，高度根据内容自适应，只设较小最小高度
    const characterThreshold = 500;
    if (totalHeight >= characterThreshold) {
      // 会显示人物，设置足够的最小高度
      const minHeight = Math.max(500, maxWidth * 0.9);
      if (totalHeight < minHeight) {
        totalHeight = minHeight;
      }
    } else {
      // 不显示人物，高度根据内容自适应，最小200px
      const minHeight = 200;
      if (totalHeight < minHeight) {
        totalHeight = minHeight;
      }
    }

    // 创建画布
    const canvas = createCanvas(maxWidth, totalHeight);
    const ctx = canvas.getContext("2d");

    // 绘制日常风格背景
    this.drawBackground(ctx, maxWidth, totalHeight, "daily", 0.5);

    let y = this.padding;

    // 绘制标题（自动缩小，带美化）
    if (title) {
      const availableWidth = maxWidth - this.padding * 2;
      let tFontSize = this.titleFontSize;
      while (this._getTextWidth(title, tFontSize) > availableWidth && tFontSize > 16) {
        tFontSize -= 2;
      }
      y = this._drawStyledTitle(ctx, title, maxWidth, y, tFontSize, this.colors.title);
    }

    // 绘制正文
    for (const { content, type } of formattedLines) {
      if (!content.trim()) {
        y += this.lineSpacing;
        continue;
      }

      let fontSize = this.fontSize;
      let color = this.colors.text;

      switch (type) {
        case "title":
          fontSize = this.tierFontSize;
          color = this.colors.tier;
          break;
        case "bounty_title":
          fontSize = this.tierFontSize;
          if (content.includes("扎里曼")) color = this.colors.bountyZariman;
          else if (content.includes("英择谛")) color = this.colors.bountyEntra;
          else if (content.includes("1999")) color = this.colors.bountyHex;
          else color = this.colors.bountyTitle;
          break;
        case "bounty_task":
          fontSize = this.taskFontSize;
          color = this.colors.bountyTask;
          break;
        case "bounty_desc":
          fontSize = this.fontSize;
          color = this.colors.bountyDesc;
          break;
        case "archimedea_title":
          fontSize = this.tierFontSize;
          color = this.colors.archimedeaTitle;
          break;
        case "archimedea_task":
          fontSize = this.taskFontSize;
          if (content.startsWith("1.")) color = "#FF8C50";
          else if (content.startsWith("2.")) color = "#50B48C";
          else if (content.startsWith("3.")) color = "#8C64C8";
          else color = this.colors.archimedeaTask;
          break;
        case "archimedea_condition":
          fontSize = this.fontSize;
          color = this.colors.archimedeaCondition;
          break;
        case "calendar_header":
          fontSize = this.tierFontSize;
          color = this.colors.calendarDate;
          break;
        case "calendar_countdown":
          fontSize = this.fontSize;
          color = this.colors.bountyZariman;
          break;
        case "calendar_date":
          fontSize = this.tierFontSize;
          color = this.colors.calendarDate;
          break;
        case "calendar_desc":
          fontSize = this.fontSize;
          color = this.colors.calendarDesc;
          break;
        case "nightwave_title":
          fontSize = this.tierFontSize;
          color = this.colors.bountyTask;
          break;
        case "nightwave_challenge":
          fontSize = this.fontSize;
          if (content.includes("[声望+1000]") || content.includes("[声望+3000]")) color = this.colors.nightwaveDaily;
          else if (content.includes("[声望+4500]")) color = this.colors.nightwaveWeekly;
          else if (content.includes("[声望+7000]") || content.includes("[声望+5000]")) color = this.colors.nightwaveElite;
          else color = this.colors.text;
          break;
        case "task":
          fontSize = this.taskFontSize;
          color = this.colors.bountyTask;
          break;
        case "desc":
          fontSize = this.fontSize;
          color = this.colors.bountyDesc;
          break;
        default:
          fontSize = this.fontSize;
          color = this.colors.text;
      }

      // 自动换行
      const availableWidth = maxWidth - this.padding * 2;
      const wrappedLines = this._wrapText(content, fontSize, availableWidth);

      ctx.font = `${fontSize}px ${FONT_FAMILY}`;
      ctx.fillStyle = color;

      for (const line of wrappedLines) {
        ctx.fillText(line, this.padding, y + fontSize);
        y += fontSize + this.lineSpacing;
      }
    }

    // 时间标注（美化）
    y += this.lineSpacing;
    this._drawStyledTimestamp(ctx, maxWidth, y);

    // 边框
    this._drawBorder(ctx, maxWidth, totalHeight);

    return canvas.toBuffer("image/png");
  }

  // ==================== 方法2: convertPlain（平原查询专用）====================
  // 紫色系配色，简化版本

  convertPlain(text, title = "", maxWidth = 450) {
    // 平原查询 -> 查询型 -> 妖娆跪姿
    this.currentFunction = "query";
    
    const lines = text.split("\n");

    // 计算高度
    let totalHeight = this.padding * 2;
    if (title) totalHeight += this.titleFontSize + this.lineSpacing * 2;

    for (const line of lines) {
      if (line.trim()) {
        totalHeight += this.fontSize + this.lineSpacing;
      } else {
        totalHeight += this.lineSpacing;
      }
    }
    totalHeight += this.timestampFontSize + this.lineSpacing * 2;
    
    // 平原查询专用：直接设置足够的最小高度，确保显示人物
    // 平原查询内容较少，但用户希望显示人物形象
    const plainMinHeight = Math.max(520, maxWidth * 0.95);
    if (totalHeight < plainMinHeight) {
      totalHeight = plainMinHeight;
    }

    // 创建画布
    const canvas = createCanvas(maxWidth, totalHeight);
    const ctx = canvas.getContext("2d");

    // 绘制日常风格背景
    this.drawBackground(ctx, maxWidth, totalHeight, "daily", 0.5);

    let y = this.padding;

    // 标题（自动缩小，带美化）
    if (title) {
      const availableWidth = maxWidth - this.padding * 2;
      let titleFontSize = this.titleFontSize;
      while (this._getTextWidth(title, titleFontSize) > availableWidth && titleFontSize > 16) {
        titleFontSize -= 2;
      }
      y = this._drawStyledTitle(ctx, title, maxWidth, y, titleFontSize, this.colors.plainTitle);
    }

    // 正文
    for (let line of lines) {
      line = line.trim();
      if (!line) {
        y += this.lineSpacing;
        continue;
      }

      let color = this.colors.plainText;
      let fontSize = this.fontSize;

      if (line.includes("平原昼夜状态查询")) {
        color = this.colors.plainTitle;
        fontSize = this.tierFontSize;
      } else if (line.includes("===") || line.includes("---")) {
        color = this.colors.plainBorder;
      } else if (line.startsWith("【") && line.endsWith("】")) {
        color = this.colors.plainSection;
        fontSize = this.tierFontSize;
      } else if (line.includes("剩余时间:") || line.includes("切换时间:")) {
        color = this.colors.plainTime;
      }

      ctx.font = `${fontSize}px ${FONT_FAMILY}`;
      ctx.fillStyle = color;
      ctx.fillText(line, this.padding, y + fontSize);
      y += fontSize + this.lineSpacing;
    }

    // 时间标注（美化）
    y += this.lineSpacing;
    this._drawStyledTimestamp(ctx, maxWidth, y);

    // 边框（平原专用）
    this._drawBorder(ctx, maxWidth, totalHeight, this.colors.plainBorder);

    return canvas.toBuffer("image/png");
  }

  // ==================== 方法3: convertRiven（紫卡查询专用）====================
  // 宽度600px，紫色系配色

  convertRiven(text, title = "", maxWidth = 600) {
    // 紫卡查询 -> 查询型 -> 妖娆跪姿
    this.currentFunction = "query";
    
    const lines = text.split("\n");

    // 计算高度
    let totalHeight = this.padding * 2;
    if (title) totalHeight += this.titleFontSize + this.lineSpacing * 2;

    for (const line of lines) {
      if (line.trim()) {
        totalHeight += this.fontSize + this.lineSpacing;
      } else {
        totalHeight += this.lineSpacing;
      }
    }
    totalHeight += this.timestampFontSize + this.lineSpacing * 2;

    // 创建画布
    const canvas = createCanvas(maxWidth, totalHeight);
    const ctx = canvas.getContext("2d");

    // 绘制日常风格背景
    this.drawBackground(ctx, maxWidth, totalHeight, "daily", 0.5);

    let y = this.padding;

    // 标题（自动缩小）
    if (title) {
      const availableWidth = maxWidth - this.padding * 2;
      let titleFontSize = this.titleFontSize;
      while (this._getTextWidth(title, titleFontSize) > availableWidth && titleFontSize > 16) {
        titleFontSize -= 2;
      }
      const titleWidth = this._getTextWidth(title, titleFontSize);
      const x = (maxWidth - titleWidth) / 2;
      ctx.font = `${titleFontSize}px ${FONT_FAMILY}`;
      ctx.fillStyle = this.colors.rivenTitle;
      ctx.fillText(title, x, y + titleFontSize);
      y += titleFontSize + this.lineSpacing * 2;
    }

    // 正文
    for (let line of lines) {
      line = line.trim();
      if (!line) {
        y += this.lineSpacing;
        continue;
      }

      let color = this.colors.rivenText;

      if (line.includes("喵~ 找到【") && line.includes("】的紫卡啦！")) {
        color = this.colors.rivenTitle;
      } else if (line.includes("价格：")) {
        color = this.colors.rivenPrice;
      } else if (line.includes("【第") && line.includes("条】")) {
        color = this.colors.rivenSection;
      } else if (line.includes("段位要求：") || line.includes("紫卡属性：")) {
        color = this.colors.rivenText;
      } else if (line.includes("卖家：")) {
        color = this.colors.rivenSeller;
      } else if (line.includes("提示：")) {
        color = this.colors.rivenHint;
      }

      ctx.font = `${this.fontSize}px ${FONT_FAMILY}`;
      ctx.fillStyle = color;
      ctx.fillText(line, this.padding, y + this.fontSize);
      y += this.fontSize + this.lineSpacing;
    }

    // 时间标注
    y += this.lineSpacing;
    this._drawTimestamp(ctx, maxWidth, y);

    // 边框（紫卡专用）
    this._drawBorder(ctx, maxWidth, totalHeight, this.colors.rivenBorder);

    return canvas.toBuffer("image/png");
  }

  // ==================== 方法4: convertResearch（科研查询专用 - 小莲三栏布局）====================

  convertResearch(text, title = "", maxWidth = null, noWrap = false) {
    // 科研查询 -> 详情型 -> 妖娆站姿
    this.currentFunction = "detail";
    
    // 解析文本
    const parsed = this._parseResearchText(text);
    const isDeep = parsed.title.includes("深层") || title.includes("深层");
    const mainTitle = isDeep ? "深层科研" : "时光科研";
    
    // 布局参数（紧凑布局，减少空白）
    const padding = 20;
    const titleBarWidth = 100;
    const gap = 20;
    const minTaskGap = 8; // 任务最小间距
    const minVarCardGap = 10; // 可选变量最小间距
    
    // 自适应宽度：完全根据内容计算，初始值为0
    let taskMaxWidth = 0;
    let varMaxWidth = 0;
    
    // 计算任务栏最大宽度
    for (let i = 0; i < parsed.tasks.length; i++) {
      const task = parsed.tasks[i];
      const taskTitleText = `${i + 1}.${task.missionType}`;
      let w = this._getTextWidth(taskTitleText, 22) + 30;
      if (task.faction) w += this._getTextWidth(task.faction, 15) + 30;
      if (w > taskMaxWidth) taskMaxWidth = w;
      
      for (const diff of task.difficulties) {
        if (diff.deviation) {
          const dw = this._getTextWidth(`[普通] [偏差] ${diff.deviation}`, 18) + 20;
          if (dw > taskMaxWidth) taskMaxWidth = dw;
        }
        if (diff.risks) {
          for (const risk of diff.risks) {
            const rw = this._getTextWidth(`[风险] ${risk}`, 18) + 90;
            if (rw > taskMaxWidth) taskMaxWidth = rw;
          }
        }
      }
    }
    
    // 计算可选栏最大宽度（先计算名称宽度，再根据宽度计算描述换行）
    for (const v of parsed.variables) {
      const nw = this._getTextWidth(`[可选] ${v.name}`, 18) + 30;
      if (nw > varMaxWidth) varMaxWidth = nw;
    }
    
    // 根据varMaxWidth计算描述换行，然后更新varMaxWidth
    for (const v of parsed.variables) {
      if (v.desc) {
        const descLines = this._wrapText(v.desc, 15, varMaxWidth - 30);
        for (const line of descLines) {
          const dw = this._getTextWidth(line, 15) + 30;
          if (dw > varMaxWidth) varMaxWidth = dw;
        }
      }
    }
    
    const taskColWidth = taskMaxWidth + 20;
    const varColWidth = varMaxWidth + 20;
    const totalWidth = padding * 2 + titleBarWidth + gap + taskColWidth + gap + varColWidth;
    
    // 计算任务栏最小高度（使用最小间距）
    let taskMinHeight = 0;
    if (parsed.remaining) taskMinHeight += 40; // 剩余时间高度
    for (const task of parsed.tasks) {
      taskMinHeight += 40; // 任务标题高度
      for (const diff of task.difficulties) {
        if (diff.deviation) taskMinHeight += 26;
        if (diff.risks && diff.risks.length > 0) {
          taskMinHeight += 26 * diff.risks.length;
        }
      }
      taskMinHeight += minTaskGap; // 任务最小间距
    }
    
    // 计算可选栏最小高度（使用最小间距）
    let varMinHeight = 40; // 标题高度
    for (const v of parsed.variables) {
      varMinHeight += 32; // 名称高度
      if (v.desc) {
        const descLines = this._wrapText(v.desc, 15, varColWidth - 40);
        varMinHeight += 20 * descLines.length;
      }
      varMinHeight += minVarCardGap; // 可选变量最小间距
    }
    
    // 动态调整间距，使可选栏和任务栏顶部和底部平行
    let taskGap = minTaskGap;
    let varCardGap = minVarCardGap;
    const contentHeight = Math.max(taskMinHeight, varMinHeight);
    
    if (parsed.tasks.length > 0 && contentHeight > taskMinHeight) {
      // 任务栏更矮，增加任务间距
      const extraHeight = contentHeight - taskMinHeight;
      taskGap = minTaskGap + extraHeight / parsed.tasks.length;
    }
    
    if (parsed.variables.length > 0 && contentHeight > varMinHeight) {
      // 可选栏更矮，增加可选变量间距
      const extraHeight = contentHeight - varMinHeight;
      varCardGap = minVarCardGap + extraHeight / parsed.variables.length;
    }
    
    // 底部命令和时间戳高度（只保留时间戳，大幅减少底部空白）
    const bottomHeight = 28;
    
    // 总高度（任务栏和可选栏高度一致，顶部和底部平行）
    const totalHeight = padding * 2 + contentHeight + bottomHeight;
    
    // 创建画布
    const canvas = createCanvas(totalWidth, totalHeight);
    const ctx = canvas.getContext("2d");
    
    // 绘制日常风格背景
    this.drawBackground(ctx, totalWidth, totalHeight, "daily", 0.5);
    
    // 优化后的科研配色方案（浅色背景，深色文字，高对比度）
    const researchColors = {
      bg: this.colors.bg || "#FFF8FC", // 浅色背景（恢复原来的）
      titleBarBg: this.colors.cardBg || "#16213e", // 左侧标题栏背景（深色）
      archimedeaTitle: "#FF9966", // 竖排大标题：暖橙色（在深色背景上清晰）
      remaining: "#E67340", // 剩余时间：深橙色（在浅色背景上清晰）
      task1: "#E67340", // 任务1：深橙色
      task2: "#3DA880", // 任务2：深青绿色
      task3: "#8050C0", // 任务3：深紫色
      task4: "#4080C0", // 任务4：深蓝色
      task5: "#E05080", // 任务5：深粉红色
      faction: "#666666", // 派系标签：深灰色（在浅色背景上清晰可见）
      diffNormal: "#3DA880", // 普通难度：深青绿色
      diffHard: "#E04040", // 困难难度：深红色
      deviation: "#4080C0", // 偏差内容：深蓝色
      risk: "#E68040", // 风险内容：深橙色
      varTitle: "#E67340", // 可选风险标题：深橙色
      varName: "#C89000", // 可选变量名称：深金色
      varDesc: "#555555", // 可选变量描述：深灰色（在浅色背景上清晰可见）
      varCardBg: "rgba(0, 0, 0, 0.05)", // 可选卡片背景：浅色半透明（在浅色背景上更协调）
      timestamp: "#888888", // 时间戳：灰色
      command: "#666666" // 命令文字：深灰色
    };
    
    // 左侧标题栏背景（深色）
    ctx.fillStyle = researchColors.titleBarBg;
    ctx.fillRect(0, 0, titleBarWidth + padding, totalHeight);
    
    // 竖排大标题（竖向居中，橙色在深色背景上清晰）
    ctx.save();
    const titleFontSize = 56;
    const titleLineHeight = 66;
    ctx.font = `bold ${titleFontSize}px ${FONT_FAMILY}`;
    ctx.fillStyle = researchColors.archimedeaTitle;
    ctx.textAlign = "center";
    const titleChars = mainTitle.split("");
    const titleTotalHeight = titleChars.length * titleLineHeight;
    // 命令提示区域高度（标题栏底部）
    const cmdHintHeight = 80;
    // 在内容区域中竖向居中（不包括底部时间区域和标题栏底部的命令提示）
    const contentAreaHeight = totalHeight - bottomHeight - padding - cmdHintHeight;
    const titleStartY = (contentAreaHeight - titleTotalHeight) / 2 + padding + titleFontSize / 2;
    titleChars.forEach((char, i) => {
      ctx.fillText(char, (titleBarWidth + padding) / 2, titleStartY + i * titleLineHeight);
    });
    
    // 标题栏底部的命令提示（竖向排列，小字体，浅灰色）
    ctx.font = `12px ${FONT_FAMILY}`;
    ctx.fillStyle = researchColors.timestamp;
    const cmdHintX = (titleBarWidth + padding) / 2;
    const cmdHintStartY = totalHeight - bottomHeight - cmdHintHeight + 15;
    ctx.fillText("科研命令", cmdHintX, cmdHintStartY);
    ctx.fillStyle = researchColors.command;
    ctx.fillText("深层科研", cmdHintX, cmdHintStartY + 22);
    ctx.fillText("时光科研", cmdHintX, cmdHintStartY + 44);
    ctx.restore();
    
    // 中间任务栏
    const taskX = padding + titleBarWidth + gap;
    let taskY = padding;
    
    // 剩余时间（紧凑高度）
    if (parsed.remaining) {
      ctx.font = `bold 20px ${FONT_FAMILY}`;
      ctx.fillStyle = researchColors.remaining;
      ctx.fillText(`剩余时间: ${parsed.remaining}`, taskX, taskY + 20);
      taskY += 40;
    }
    
    // 任务列表（紧凑高度）
    const taskColors = [researchColors.task1, researchColors.task2, researchColors.task3, researchColors.task4, researchColors.task5];
    parsed.tasks.forEach((task, idx) => {
      const color = taskColors[idx % taskColors.length];
      
      // 任务编号和类型
      ctx.font = `bold 22px ${FONT_FAMILY}`;
      ctx.fillStyle = color;
      const taskTitleText = `${idx + 1}.${task.missionType}`;
      ctx.fillText(taskTitleText, taskX, taskY + 22);
      const taskTitleWidth = ctx.measureText(taskTitleText).width;
      
      // 派系标签（深灰色在浅色背景上清晰可见）
      if (task.faction) {
        const factionText = task.faction;
        ctx.font = `15px ${FONT_FAMILY}`;
        const factionX = taskX + taskTitleWidth + 12;
        ctx.fillStyle = researchColors.faction;
        ctx.fillText(factionText, factionX, taskY + 22);
      }
      taskY += 40;
      
      // 偏差和风险（紧凑高度）
      task.difficulties.forEach((diff, dIdx) => {
        const diffName = diff.type === "CD_HARD" ? "困难" : "普通";
        const diffColor = diff.type === "CD_HARD" ? researchColors.diffHard : researchColors.diffNormal;
        
        // 偏差
        if (diff.deviation) {
          ctx.font = `18px ${FONT_FAMILY}`;
          ctx.fillStyle = diffColor;
          ctx.fillText(`[${diffName}]`, taskX, taskY + 18);
          
          ctx.fillStyle = researchColors.deviation;
          ctx.fillText(`[偏差] ${diff.deviation}`, taskX + 70, taskY + 18);
          taskY += 26;
        }
        
        // 风险（每个风险占一行，紧凑高度）
        if (diff.risks && diff.risks.length > 0) {
          diff.risks.forEach((risk, rIdx) => {
            if (rIdx === 0 && !diff.deviation) {
              ctx.font = `18px ${FONT_FAMILY}`;
              ctx.fillStyle = diffColor;
              ctx.fillText(`[${diffName}]`, taskX, taskY + 18);
            }
            ctx.font = `18px ${FONT_FAMILY}`;
            ctx.fillStyle = researchColors.risk;
            ctx.fillText(`[风险] ${risk}`, taskX + 70, taskY + 18);
            taskY += 26;
          });
        }
      });
      
      taskY += taskGap;
    });
    
    // 右侧可选风险栏
    const varX = taskX + taskColWidth + gap;
    let varY = padding;
    
    // 可选风险标题（紧凑高度）
    ctx.font = `bold 18px ${FONT_FAMILY}`;
    ctx.fillStyle = researchColors.varTitle;
    ctx.fillText("【可选】风险变量", varX, varY + 18);
    varY += 40;
    
    // 可选风险列表（紧凑高度，去掉背景填充）
    parsed.variables.forEach((v, idx) => {
      // 风险名称（紧凑高度）
      ctx.font = `bold 18px ${FONT_FAMILY}`;
      ctx.fillStyle = researchColors.varName;
      ctx.fillText(`[可选] ${v.name}`, varX, varY + 20);
      varY += 32;
      
      // 风险描述（紧凑高度）
      if (v.desc) {
        ctx.font = `15px ${FONT_FAMILY}`;
        ctx.fillStyle = researchColors.varDesc;
        const descLines = this._wrapText(v.desc, 15, varColWidth - 40);
        descLines.forEach((line) => {
          ctx.fillText(line, varX, varY + 15);
          varY += 20;
        });
      }
      
      varY += varCardGap;
    });
    
    // 时间戳（底部居中偏右，减少底部空白）
    const now = new Date();
    const timeStr = `${now.getFullYear()}.${String(now.getMonth() + 1).padStart(2, "0")}.${String(now.getDate()).padStart(2, "0")} ${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}`;
    ctx.font = `11px ${FONT_FAMILY}`;
    ctx.fillStyle = "#555";
    ctx.textAlign = "right";
    ctx.fillText(`小熊机器人 ${timeStr}`, totalWidth - padding, totalHeight - 10);
    
    // 边框
    this._drawBorder(ctx, totalWidth, totalHeight);
    
    return canvas.toBuffer("image/png");
  }
  
  // 解析科研文本
  _parseResearchText(text) {
    const result = {
      title: "",
      remaining: "",
      tasks: [],
      variables: []
    };
    
    const lines = text.split("\n").map(l => l.trim()).filter(l => l);
    let section = "";
    
    for (const line of lines) {
      if (line.includes("深层科研") || line.includes("时光科研") || line.includes("Archimedea")) {
        result.title = line;
        continue;
      }
      if (line.startsWith("剩余时间")) {
        result.remaining = line.replace("剩余时间:", "").replace("剩余时间：", "").trim();
        continue;
      }
      if (line.includes("任务列表")) {
        section = "tasks";
        continue;
      }
      if (line.includes("可选风险") || line.includes("风险变量")) {
        section = "variables";
        continue;
      }
      
      if (section === "tasks" && /^\d+\./.test(line)) {
        const task = this._parseTaskLine(line);
        result.tasks.push(task);
      } else if (section === "variables" && /^\d+\./.test(line)) {
        const v = this._parseVariableLine(line);
        result.variables.push(v);
      }
    }
    
    return result;
  }
  
  _parseTaskLine(line) {
    const task = {
      missionType: "",
      faction: "",
      difficulties: []
    };
    
    // 提取任务类型和派系
    const typeMatch = line.match(/^\d+\.\s*([^（(]+)/);
    if (typeMatch) task.missionType = typeMatch[1].trim();
    
    const factionMatch = line.match(/[（(]([^）)]+)[）)]/);
    if (factionMatch) task.faction = factionMatch[1].trim();
    
    // 提取难度信息
    const diffPattern = /\[(普通|困难)\][^\[]*/g;
    let diffMatch;
    while ((diffMatch = diffPattern.exec(line)) !== null) {
      const diffText = diffMatch[0];
      const diff = {
        type: diffText.includes("困难") ? "CD_HARD" : "CD_NORMAL",
        deviation: "",
        risks: []
      };
      
      const devMatch = diffText.match(/偏差[:：]\s*([^\s\[]+)/);
      if (devMatch) diff.deviation = devMatch[1].trim();
      
      const riskMatch = diffText.match(/风险[:：]\s*(.+)/);
      if (riskMatch) {
        diff.risks = riskMatch[1].split(/[,，、]/).map(r => r.trim()).filter(r => r);
      }
      
      task.difficulties.push(diff);
    }
    
    if (task.difficulties.length === 0) {
      task.difficulties.push({ type: "CD_NORMAL", deviation: "", risks: [] });
    }
    
    return task;
  }
  
  _parseVariableLine(line) {
    const v = { name: "", desc: "" };
    const match = line.match(/^\d+\.\s*([^-—]+)[-—]\s*(.+)/);
    if (match) {
      v.name = match[1].trim();
      v.desc = match[2].trim();
    } else {
      v.name = line.replace(/^\d+\.\s*/, "").trim();
    }
    return v;
  }

  // ==================== 方法5: convertStructured（结构化数据）====================
  // 支持T1-T4字体样式

  convertStructured(content, maxWidth = null) {
    if (maxWidth === null) maxWidth = this.maxWidth;
    
    // 结构化数据默认使用 default 形象
    this.currentFunction = "default";

    // 计算高度
    let totalHeight = this.padding * 2;

    for (const item of content) {
      const text = item.text || "";
      const tType = item.type || "T4";

      if (!text.trim()) {
        totalHeight += this.lineSpacing;
        continue;
      }

      const style = this.TStyles[tType] || this.TStyles.T4;
      totalHeight += style.fontSize + this.lineSpacing;
    }

    totalHeight += this.timestampFontSize + this.lineSpacing * 2;

    // 创建画布
    const canvas = createCanvas(maxWidth, totalHeight);
    const ctx = canvas.getContext("2d");

    // 绘制日常风格背景
    this.drawBackground(ctx, maxWidth, totalHeight, "daily", 0.5);

    let y = this.padding;

    for (const item of content) {
      const text = item.text || "";
      const tType = item.type || "T4";
      const align = item.align || "left";

      if (!text.trim()) {
        y += this.lineSpacing;
        continue;
      }

      const style = this.TStyles[tType] || this.TStyles.T4;
      const fontSize = style.fontSize;
      const color = style.color;
      const defaultAlign = style.align || "left";
      const finalAlign = align || defaultAlign;

      ctx.font = `${fontSize}px ${FONT_FAMILY}`;
      ctx.fillStyle = color;

      let x;
      if (finalAlign === "center") {
        const textWidth = this._getTextWidth(text, fontSize);
        x = (maxWidth - textWidth) / 2;
      } else {
        x = this.padding;
      }

      ctx.fillText(text, x, y + fontSize);
      y += fontSize + this.lineSpacing;
    }

    // 时间标注
    y += this.lineSpacing;
    this._drawTimestamp(ctx, maxWidth, y);

    // 边框
    this._drawBorder(ctx, maxWidth, totalHeight);

    return canvas.toBuffer("image/png");
  }

  // ==================== 帮助专用：分栏显示 ====================
  convertHelp(text, title = "", maxWidth = null) {
    if (maxWidth === null) maxWidth = this.maxWidth;
    
    const lines = text.split("\n");
    
    // 按分类分组
    const categories = [];
    let currentCategory = null;
    let headerLines = [];
    let inHeader = true;
    
    for (const line of lines) {
      const trimmed = line.trim();
      
      // 检测分类标题（━━━ 分类名 ━━━）
      if (trimmed.startsWith("━━━") && trimmed.endsWith("━━━")) {
        inHeader = false;
        const catName = trimmed.replace(/━/g, '').trim();
        currentCategory = { name: catName, lines: [] };
        categories.push(currentCategory);
        continue;
      }
      
      if (inHeader) {
        if (trimmed) headerLines.push(trimmed);
      } else if (currentCategory) {
        currentCategory.lines.push(trimmed);
      }
    }
    
    // 如果没有检测到分类，退化为单栏显示
    if (categories.length === 0) {
      this.currentFunction = "default";
      return this.convertSimple(text, title, maxWidth, true);
    }
    
    // 帮助专用字体大小（超大字体，确保清晰易读）
    const helpFontSize = this.fontSize + 26;  // 42px
    const helpTierFontSize = this.tierFontSize + 26;  // 44px
    const helpLineSpacing = this.lineSpacing + 18;  // 26px
    
    // 计算每个分类的高度
    const categoryHeights = categories.map(cat => {
      let h = helpTierFontSize + helpLineSpacing * 2; // 分类标题高度
      for (const line of cat.lines) {
        if (line) {
          h += helpFontSize + helpLineSpacing;
        } else {
          h += helpLineSpacing * 0.5;
        }
      }
      return h;
    });
    
    // 决定分几栏（超大字体，每栏容纳分类数很少，降低阈值）
    let columnCount = 1;
    if (categories.length >= 12) columnCount = 3;
    else if (categories.length >= 6) columnCount = 2;
    
    // 把分类分配到各栏，使高度尽量均衡
    const columns = Array.from({ length: columnCount }, () => ({ categories: [], height: 0 }));
    
    // 贪心算法：每次把分类放到当前最矮的栏
    for (let i = 0; i < categories.length; i++) {
      let minCol = 0;
      for (let j = 1; j < columnCount; j++) {
        if (columns[j].height < columns[minCol].height) {
          minCol = j;
        }
      }
      columns[minCol].categories.push(categories[i]);
      columns[minCol].height += categoryHeights[i];
    }
    
    // 计算画布尺寸（超大栏宽，确保超大字体不溢出）
    const columnWidth = maxWidth + 380;
    const columnGap = 70;
    const totalWidth = columnWidth * columnCount + columnGap * (columnCount - 1) + this.padding * 2;
    const maxColumnHeight = Math.max(...columns.map(c => c.height));
    
    // 计算总高度
    let totalHeight = this.padding;
    if (title) totalHeight += this.titleFontSize + helpLineSpacing * 2;
    if (headerLines.length > 0) {
      totalHeight += headerLines.length * (helpFontSize + helpLineSpacing);
      totalHeight += helpLineSpacing;
    }
    totalHeight += maxColumnHeight;
    totalHeight += this.timestampFontSize + helpLineSpacing * 2;
    totalHeight += this.padding;
    
    // 创建画布
    const canvas = createCanvas(totalWidth, totalHeight);
    const ctx = canvas.getContext("2d");
    
    // 绘制背景（纯白渐变，不显示人物）
    const gradient = ctx.createLinearGradient(0, 0, 0, totalHeight);
    gradient.addColorStop(0, "#FFF0F6");
    gradient.addColorStop(0.5, "#FFF8FC");
    gradient.addColorStop(1, "#FFF0F6");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, totalWidth, totalHeight);
    
    let y = this.padding;
    
    // 绘制标题
    if (title) {
      const availableWidth = totalWidth - this.padding * 2;
      let tFontSize = this.titleFontSize + 32;  // 72px
      while (this._getTextWidth(title, tFontSize) > availableWidth && tFontSize > 32) {
        tFontSize -= 2;
      }
      y = this._drawStyledTitle(ctx, title, totalWidth, y, tFontSize, this.colors.title);
    }
    
    // 绘制头部信息
    if (headerLines.length > 0) {
      ctx.font = `${helpFontSize}px ${FONT_FAMILY}`;
      ctx.fillStyle = this.colors.text;
      for (const line of headerLines) {
        ctx.fillText(line, this.padding, y + helpFontSize);
        y += helpFontSize + helpLineSpacing;
      }
      y += helpLineSpacing;
    }
    
    // 逐栏绘制分类
    const contentStartY = y;
    for (let colIdx = 0; colIdx < columnCount; colIdx++) {
      const colX = this.padding + colIdx * (columnWidth + columnGap);
      let colY = contentStartY;
      
      for (const cat of columns[colIdx].categories) {
        // 绘制分类标题
        ctx.font = `${helpTierFontSize}px ${FONT_FAMILY}`;
        ctx.fillStyle = this.colors.tier;
        ctx.fillText(`【${cat.name}】`, colX, colY + helpTierFontSize);
        colY += helpTierFontSize + helpLineSpacing * 1.5;
        
        // 绘制分类内容
        ctx.font = `${helpFontSize}px ${FONT_FAMILY}`;
        ctx.fillStyle = this.colors.text;
        for (const line of cat.lines) {
          if (line) {
            ctx.fillText(line, colX, colY + helpFontSize);
            colY += helpFontSize + helpLineSpacing;
          } else {
            colY += helpLineSpacing * 0.5;
          }
        }
        colY += helpLineSpacing * 0.5;
      }
    }
    
    // 时间标注
    y = Math.max(y, contentStartY + maxColumnHeight);
    y += this.lineSpacing;
    this._drawStyledTimestamp(ctx, totalWidth, y);
    
    // 边框
    this._drawBorder(ctx, totalWidth, totalHeight);
    
    return canvas.toBuffer("image/png");
  }
}

// 导出单例
const textToImage = new TextToImageConverter();
module.exports = textToImage;

// 预加载背景图片（异步，不阻塞导出）
textToImage.preloadBackgrounds().catch(err => {
  console.error("预加载背景图片失败:", err.message);
});
