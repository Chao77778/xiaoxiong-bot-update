﻿// 全局Tab切换函数（确保可被onclick调用）

// ============== 自定义美观对话框组件 ==============
(function() {
  // 创建对话框容器
  const dialogOverlay = document.createElement('div');
  dialogOverlay.id = 'custom-dialog-overlay';
  dialogOverlay.style.cssText = `
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0, 0, 0, 0.6);
    display: none; justify-content: center; align-items: center;
    z-index: 99999; backdrop-filter: blur(5px);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
  `;
  
  const dialogBox = document.createElement('div');
  dialogBox.id = 'custom-dialog-box';
  dialogBox.style.cssText = `
    background: linear-gradient(135deg, #1e1e3f 0%, #2a2a5a 100%);
    border-radius: 16px; padding: 0; min-width: 380px; max-width: 500px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.1);
    animation: dialogSlideIn 0.25s ease-out;
    overflow: hidden;
  `;
  
  // 添加动画样式
  const style = document.createElement('style');
  style.textContent = `
    @keyframes dialogSlideIn {
      from { opacity: 0; transform: translateY(-20px) scale(0.95); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    @keyframes dialogSlideOut {
      from { opacity: 1; transform: translateY(0) scale(1); }
      to { opacity: 0; transform: translateY(-20px) scale(0.95); }
    }
    .dialog-closing { animation: dialogSlideOut 0.2s ease-in forwards !important; }
  `;
  document.head.appendChild(style);
  
  // 标题栏
  const dialogTitle = document.createElement('div');
  dialogTitle.id = 'custom-dialog-title';
  dialogTitle.style.cssText = `
    padding: 18px 24px 12px; font-size: 18px; font-weight: 600;
    color: #fff; display: flex; align-items: center; gap: 10px;
  `;
  
  // 内容区
  const dialogContent = document.createElement('div');
  dialogContent.id = 'custom-dialog-content';
  dialogContent.style.cssText = `
    padding: 0 24px 20px; font-size: 15px; color: rgba(255, 255, 255, 0.85);
    line-height: 1.6; word-break: break-word;
  `;
  
  // 输入框（用于prompt）
  const dialogInput = document.createElement('input');
  dialogInput.id = 'custom-dialog-input';
  dialogInput.type = 'text';
  dialogInput.style.cssText = `
    width: 100%; padding: 12px 16px; margin-top: 16px;
    background: rgba(255, 255, 255, 0.1); border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 10px; color: #fff; font-size: 15px; outline: none;
    transition: border-color 0.2s, box-shadow 0.2s; box-sizing: border-box;
  `;
  dialogInput.placeholder = '请输入...';
  dialogInput.addEventListener('focus', () => {
    dialogInput.style.borderColor = 'rgba(100, 150, 255, 0.6)';
    dialogInput.style.boxShadow = '0 0 0 3px rgba(100, 150, 255, 0.15)';
  });
  dialogInput.addEventListener('blur', () => {
    dialogInput.style.borderColor = 'rgba(255, 255, 255, 0.2)';
    dialogInput.style.boxShadow = 'none';
  });
  
  // 按钮区
  const dialogButtons = document.createElement('div');
  dialogButtons.id = 'custom-dialog-buttons';
  dialogButtons.style.cssText = `
    padding: 16px 24px 20px; display: flex; justify-content: flex-end; gap: 12px;
    background: rgba(0, 0, 0, 0.15);
  `;
  
  // 组装
  dialogBox.appendChild(dialogTitle);
  dialogBox.appendChild(dialogContent);
  dialogBox.appendChild(dialogInput);
  dialogBox.appendChild(dialogButtons);
  dialogOverlay.appendChild(dialogBox);
  document.body.appendChild(dialogOverlay);
  
  // 创建按钮
  function createButton(text, type) {
    const btn = document.createElement('button');
    btn.textContent = text;
    const isPrimary = type === 'primary';
    btn.style.cssText = `
      padding: 10px 24px; border-radius: 10px; font-size: 14px; font-weight: 500;
      cursor: pointer; border: none; transition: all 0.2s;
      ${isPrimary 
        ? 'background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);'
        : 'background: rgba(255, 255, 255, 0.1); color: rgba(255, 255, 255, 0.8);'
      }
    `;
    btn.addEventListener('mouseenter', () => {
      btn.style.transform = 'translateY(-2px)';
      if (isPrimary) btn.style.boxShadow = '0 6px 20px rgba(102, 126, 234, 0.5)';
      else btn.style.background = 'rgba(255, 255, 255, 0.15)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.transform = 'translateY(0)';
      if (isPrimary) btn.style.boxShadow = '0 4px 15px rgba(102, 126, 234, 0.4)';
      else btn.style.background = 'rgba(255, 255, 255, 0.1)';
    });
    return btn;
  }
  
  // 显示对话框
  let currentResolve = null;
  let currentType = 'alert';
  
  function showDialog({ title, message, type = 'alert', defaultValue = '', icon = '💬' }) {
    return new Promise((resolve) => {
      currentResolve = resolve;
      currentType = type;
      
      // 设置标题
      dialogTitle.innerHTML = `<span>${icon}</span><span>${title}</span>`;
      
      // 设置内容
      dialogContent.textContent = message;
      
      // 显示/隐藏输入框
      if (type === 'prompt') {
        dialogInput.style.display = 'block';
        dialogInput.value = defaultValue || '';
        setTimeout(() => dialogInput.focus(), 100);
      } else {
        dialogInput.style.display = 'none';
      }
      
      // 清空按钮
      dialogButtons.innerHTML = '';
      
      if (type === 'alert') {
        const okBtn = createButton('确定', 'primary');
        okBtn.addEventListener('click', () => closeDialog(undefined));
        dialogButtons.appendChild(okBtn);
      } else if (type === 'confirm') {
        const cancelBtn = createButton('取消', 'default');
        cancelBtn.addEventListener('click', () => closeDialog(false));
        const okBtn = createButton('确定', 'primary');
        okBtn.addEventListener('click', () => closeDialog(true));
        dialogButtons.appendChild(cancelBtn);
        dialogButtons.appendChild(okBtn);
      } else if (type === 'prompt') {
        const cancelBtn = createButton('取消', 'default');
        cancelBtn.addEventListener('click', () => closeDialog(null));
        const okBtn = createButton('确定', 'primary');
        okBtn.addEventListener('click', () => closeDialog(dialogInput.value));
        dialogButtons.appendChild(cancelBtn);
        dialogButtons.appendChild(okBtn);
      }
      
      // 显示
      dialogOverlay.style.display = 'flex';
      dialogBox.classList.remove('dialog-closing');
    });
  }
  
  function closeDialog(result) {
    dialogBox.classList.add('dialog-closing');
    setTimeout(() => {
      dialogOverlay.style.display = 'none';
      if (currentResolve) {
        currentResolve(result);
        currentResolve = null;
      }
    }, 200);
  }
  
  // 回车键支持
  document.addEventListener('keydown', (e) => {
    if (dialogOverlay.style.display === 'flex') {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (currentType === 'alert') closeDialog(undefined);
        else if (currentType === 'confirm') closeDialog(true);
        else if (currentType === 'prompt') closeDialog(dialogInput.value);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        if (currentType === 'alert') closeDialog(undefined);
        else if (currentType === 'confirm') closeDialog(false);
        else if (currentType === 'prompt') closeDialog(null);
      }
    }
  });
  
  // 暴露全局函数
  window.showAlert = (message, title = '提示') => showDialog({ title, message, type: 'alert', icon: '💬' });
  window.showConfirm = (message, title = '确认') => showDialog({ title, message, type: 'confirm', icon: '❓' });
  window.showPrompt = (message, defaultValue = '', title = '输入') => showDialog({ title, message, type: 'prompt', defaultValue, icon: '✏️' });
  window.showSuccess = (message, title = '成功') => showDialog({ title, message, type: 'alert', icon: '✅' });
  window.showError = (message, title = '错误') => showDialog({ title, message, type: 'alert', icon: '❌' });
  window.showWarning = (message, title = '警告') => showDialog({ title, message, type: 'alert', icon: '⚠️' });
})();
// ============== 自定义对话框组件结束 ==============


// ==================== 自定义对话框（替代Electron不支持的prompt/confirm） ====================
function showInputDialog(title, message, defaultValue) {
  return new Promise((resolve) => {
    const dialog = document.getElementById('customInputDialog');
    const titleEl = document.getElementById('customDialogTitle');
    const messageEl = document.getElementById('customDialogMessage');
    const inputEl = document.getElementById('customDialogInput');
    const confirmBtn = document.getElementById('customDialogConfirm');
    const cancelBtn = document.getElementById('customDialogCancel');
    
    titleEl.textContent = title || '输入';
    messageEl.textContent = message || '';
    inputEl.value = defaultValue || '';
    
    dialog.style.display = 'flex';
    setTimeout(() => inputEl.focus(), 100);
    
    const handleConfirm = () => {
      cleanup();
      resolve(inputEl.value);
    };
    
    const handleCancel = () => {
      cleanup();
      resolve(null);
    };
    
    const handleKeydown = (e) => {
      if (e.key === 'Enter') handleConfirm();
      if (e.key === 'Escape') handleCancel();
    };
    
    const cleanup = () => {
      dialog.style.display = 'none';
      confirmBtn.removeEventListener('click', handleConfirm);
      cancelBtn.removeEventListener('click', handleCancel);
      inputEl.removeEventListener('keydown', handleKeydown);
    };
    
    confirmBtn.addEventListener('click', handleConfirm);
    cancelBtn.addEventListener('click', handleCancel);
    inputEl.addEventListener('keydown', handleKeydown);
  });
}

function showConfirmDialog(title, message) {
  return new Promise((resolve) => {
    const dialog = document.getElementById('customConfirmDialog');
    const titleEl = document.getElementById('customConfirmTitle');
    const messageEl = document.getElementById('customConfirmMessage');
    const confirmBtn = document.getElementById('customConfirmConfirm');
    const cancelBtn = document.getElementById('customConfirmCancel');
    
    titleEl.textContent = title || '确认';
    messageEl.textContent = message || '';
    
    dialog.style.display = 'flex';
    
    const handleConfirm = () => {
      cleanup();
      resolve(true);
    };
    
    const handleCancel = () => {
      cleanup();
      resolve(false);
    };
    
    const handleKeydown = (e) => {
      if (e.key === 'Escape') handleCancel();
    };
    
    const cleanup = () => {
      dialog.style.display = 'none';
      confirmBtn.removeEventListener('click', handleConfirm);
      cancelBtn.removeEventListener('click', handleCancel);
      document.removeEventListener('keydown', handleKeydown);
    };
    
    confirmBtn.addEventListener('click', handleConfirm);
    cancelBtn.addEventListener('click', handleCancel);
    document.addEventListener('keydown', handleKeydown);
  });
}

function switchSettingsTab(tabName) {
  try {
    document.querySelectorAll(".settings-tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".settings-panel").forEach(p => p.classList.remove("active"));
    const tab = document.querySelector('.settings-tab[data-tab="' + tabName + '"]');
    const panel = document.getElementById("panel-" + tabName);
    if (tab) tab.classList.add("active");
    if (panel) panel.classList.add("active");
  } catch (e) {
    console.error("Tab切换失败:", e);
  }
}

// 全局群设置面板切换函数（确保可被onclick调用）
function toggleGroupPanel(gid) {
  try {
    const body = document.getElementById("gsc-body-" + gid);
    const card = document.querySelector('.group-setting-card[data-gid="' + gid + '"]');
    if (!body || !card) {
      console.warn("toggleGroupPanel: 未找到元素, gid=" + gid);
      return;
    }
    const isExpanded = card.classList.contains("expanded");
    if (isExpanded) {
      body.style.display = "none";
      card.classList.remove("expanded");
    } else {
      body.style.display = "block";
      card.classList.add("expanded");
    }
  } catch (e) {
    console.error("toggleGroupPanel错误:", e);
  }
}

// ============== 渲染进程逻辑 v3.0 ==============
let toastTimer = null;
let currentConfig = null;
let keywordEditingList = [];
let welcomeButtonsList = [];

document.addEventListener("DOMContentLoaded", async () => {
  // 先注册事件监听器，确保不会因为后面的错误而丢失事件
  setupEventListeners();
  
  try {
    currentConfig = await window.api.getConfig();
    fillAllForms(currentConfig);
    const status = await window.api.getStatus();
    updateStatusUI(status);
    renderLogs(status.logs || []);
    setupNavigation();
    setupButtons();
    renderPushGroupList();
    renderGroupSettingsList();
    loadRecentGroups();
    loadVersion();
  } catch (e) {
    console.error("初始化出错:", e);
    if (document.getElementById("consoleLog")) {
      appendLog({ time: new Date().toLocaleString(), type: "error", message: "初始化出错: " + e.message });
    }
  }
});


// ==================== 导航 ====================
function setupNavigation() {
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("click", () => {
      const openWindow = item.dataset.openWindow;
      if (openWindow === "xiuxian-admin" && typeof openXiuxianAdminWindow === "function") {
        openXiuxianAdminWindow();
        return;
      }
      switchPage(item.dataset.page);
    });
  });
}
function switchPage(pageName) {
  document.querySelectorAll(".nav-item").forEach((i) => i.classList.remove("active"));
  document.querySelector(`.nav-item[data-page="${pageName}"]`).classList.add("active");
  document.querySelectorAll(".page").forEach((p) => p.classList.remove("active"));
  document.getElementById(`page-${pageName}`).classList.add("active");
  // 切换页面时重置滚动位置到顶部
  const contentArea = document.querySelector(".content");
  if (contentArea) contentArea.scrollTop = 0;
  // 切换到Warframe页面时加载别名
  if (pageName === "warframe" && typeof loadWfAliases === "function") {
    setTimeout(loadWfAliases, 100);
  }
}


// 保存成功动画：按钮显示"✓ 已保存"2秒
function showSaveSuccess(btn) {
  if (!btn) return;
  const originalText = btn.textContent;
  btn.classList.add("btn-save-success");
  btn.textContent = "✓ 已保存";
  btn.disabled = true;
  setTimeout(() => {
    btn.classList.remove("btn-save-success");
    btn.textContent = originalText;
    btn.disabled = false;
  }, 2000);
}

// 复制所有日志
async function copyAllLogs() {
  const logEl = document.getElementById("consoleLog");
  if (!logEl) {
    showToast("日志容器不存在", "error");
    return;
  }
  const entries = logEl.querySelectorAll(".log-entry");
  if (entries.length === 0) {
    showToast("暂无日志可复制", "info");
    return;
  }
  let text = "===== 小熊机器人日志 =====\n";
  text += "导出时间: " + new Date().toLocaleString("zh-CN") + "\n";
  text += "日志数量: " + entries.length + "\n";
  text += "========================\n";
  entries.forEach((entry) => {
    const time = entry.querySelector(".log-time")?.textContent || "";
    const type = entry.querySelector(".log-type")?.textContent || "";
    const msg = entry.querySelector(".log-message")?.textContent || "";
    text += "[" + time + "] [" + type.padEnd(7) + "] " + msg + "\n";
  });
  await fallbackCopy(text);
}

// 复制文本到剪贴板
async function fallbackCopy(text) {
  try {
    // 优先使用现代Clipboard API
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      showToast("日志已复制到剪贴板（共" + text.split("\n").length + "行）", "success");
      return;
    }
  } catch (e) {
    console.warn("Clipboard API失败，尝试备用方法:", e.message);
  }
  // 备用方法：创建临时textarea
  try {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    textarea.style.top = "-9999px";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    const successful = document.execCommand("copy");
    document.body.removeChild(textarea);
    if (successful) {
      showToast("日志已复制到剪贴板", "success");
    } else {
      showToast("复制失败，请手动选择日志文本复制", "error");
    }
  } catch (e) {
    showToast("复制失败: " + e.message, "error");
  }
}


// 渲染欢迎按钮列表
function renderWelcomeButtons() {
  const container = document.getElementById("welcomeButtonsList");
  if (!container) return;
  container.innerHTML = "";
  welcomeButtonsList.forEach((btn, idx) => {
    const row = document.createElement("div");
    row.className = "button-config-row";
    row.innerHTML = '<div><label>按钮文字</label><input type="text" class="input" value="' + escapeHtml(btn.label || "") + '" placeholder="如：点击进入官网" data-idx="' + idx + '" data-field="label"></div>' +
      '<div><label>类型</label><select class="input" data-idx="' + idx + '" data-field="type"><option value="link"' + (btn.type === "link" ? " selected" : "") + '>跳转</option><option value="command"' + (btn.type === "command" ? " selected" : "") + '>指令</option></select></div>' +
      '<div><label>内容</label><input type="text" class="input" value="' + (btn.data || "") + '" placeholder="链接/复制内容/指令" data-idx="' + idx + '" data-field="data"></div>' +
      '<div><label>样式</label><select class="input" data-idx="' + idx + '" data-field="style"><option value="4"' + (btn.style == 4 ? " selected" : "") + '>蓝色背景</option><option value="3"' + (btn.style == 3 ? " selected" : "") + '>红色</option><option value="1"' + (btn.style == 1 ? " selected" : "") + '>蓝色线框</option><option value="0"' + (btn.style == 0 ? " selected" : "") + '>灰色</option></select></div>' +
      '<button class="btn btn-sm btn-danger" data-del-idx="' + idx + '">删除</button>';
    container.appendChild(row);
  });
  container.querySelectorAll("input, select").forEach((el) => {
    el.addEventListener("input", (e) => {
      const idx = parseInt(e.target.dataset.idx);
      const field = e.target.dataset.field;
      welcomeButtonsList[idx][field] = field === "style" ? parseInt(e.target.value) : e.target.value;
    });
  });
  container.querySelectorAll("[data-del-idx]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      welcomeButtonsList.splice(parseInt(e.target.dataset.delIdx), 1);
      renderWelcomeButtons();
    });
  });
}

// 更新欢迎图片预览
function updateWelcomeImagePreview(imageUrl) {
  const preview = document.getElementById("welcomeImagePreview");
  const img = document.getElementById("welcomeImagePreviewImg");
  if (!preview || !img) return;
  if (imageUrl && imageUrl.trim() !== "" && (imageUrl.startsWith("http://") || imageUrl.startsWith("https://"))) {
    img.src = imageUrl;
    preview.classList.add("show");
  } else {
    img.src = "";
    preview.classList.remove("show");
  }
}

// ==================== 按钮事件 ====================
function setupButtons() {
  document.getElementById("btnConnect").addEventListener("click", async () => {
    collectConnectionConfig();
    await saveAllConfig();
    showToast("正在连接...", "info");
    const result = await window.api.connect();
    if (result && result.success) {
      showToast("连接指令已发送", "success");
    } else {
      showToast("连接失败: " + (result ? result.error : "未知错误"), "error");
    }
  });
  document.getElementById("btnDisconnect").addEventListener("click", async () => {
    await window.api.disconnect();
    showToast("已断开连接", "info");
  });
    // 欢迎图片失焦后预览
  document.getElementById("cfgWelcomeImage").addEventListener("blur", (e) => {
    updateWelcomeImagePreview(e.target.value);
  });
document.getElementById("btnClearLog").addEventListener("click", async () => {
    await window.api.clearLogs();
    document.getElementById("consoleLog").innerHTML = "";
  });

  // 各页面保存
  document.getElementById("btnSaveConnection").addEventListener("click", () => { collectConnectionConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveConnection")); });
  document.getElementById("btnSaveWelcome").addEventListener("click", () => { collectWelcomeConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveWelcome")); showToast("欢迎配置已保存"); });
  document.getElementById("btnSaveKeywords").addEventListener("click", () => { collectKeywordsConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveKeywords")); });
  document.getElementById("btnSaveAdmin").addEventListener("click", () => { collectAdminConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveAdmin")); });
  document.getElementById("btnSaveWebsite").addEventListener("click", () => { collectWebsiteConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveWebsite")); });
  document.getElementById("btnSaveDefaults").addEventListener("click", () => { collectDefaultsConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveDefaults")); });

  // 关键词
  document.getElementById("btnAddKeyword").addEventListener("click", () => {
    keywordEditingList.push({ keyword: "", reply: "", mode: "includes" });
    renderKeywordList();
  });

  // 导入导出
  const _btnExport = document.getElementById("btnExport");
  if (_btnExport) _btnExport.addEventListener("click", async () => {
    try {
      const r = await window.api.exportConfig();
      if (r.success) showToast("配置已导出", "success");
      else showToast("导出失败: " + (r.error || ""), "error");
    } catch(e) { showToast("导出失败: " + e.message, "error"); }
  });
  const _btnImport = document.getElementById("btnImport");
  if (_btnImport) _btnImport.addEventListener("click", async () => {
    try {
      const r = await window.api.importConfig();
      if (r.success) {
        currentConfig = r.config;
        loadConfigToUI();
        showToast("配置已导入", "success");
      } else {
        showToast("导入失败: " + (r.error || ""), "error");
      }
    } catch(e) { showToast("导入失败: " + e.message, "error"); }
  });

  // 网站推送
  document.getElementById("btnTestWebsite").addEventListener("click", testWebsite);
  document.getElementById("btnPushNow").addEventListener("click", pushNow);
  document.getElementById("btnCheckNow").addEventListener("click", async () => { collectWebsiteConfig(); await saveAllConfig(false); await window.api.websiteCheckNow(); showToast("已触发检查", "info"); });
  document.getElementById("btnAddPushGroup").addEventListener("click", addPushGroup);

  // 群功能管理
  document.getElementById("btnAddGroup").addEventListener("click", addGroupToManage);
  const btnRefreshRecent = document.getElementById("btnRefreshRecentGroups");
  if (btnRefreshRecent) btnRefreshRecent.addEventListener("click", loadRecentGroups);

  // 自定义标题栏按钮
  document.getElementById("btnMinimize").addEventListener("click", () => window.api.windowMinimize());
  document.getElementById("btnMaximize").addEventListener("click", async () => {
    await window.api.windowMaximize();
    updateMaximizeIcon();
  });
  document.getElementById("btnClose").addEventListener("click", () => window.api.windowClose());
  if (window.api.onWindowMaximized) {
    window.api.onWindowMaximized((maximized) => updateMaximizeIcon(maximized));
  }
  window.api.windowIsMaximized().then((r) => updateMaximizeIcon(r.maximized));

  // 在线更新
  document.getElementById("btnCheckUpdate").addEventListener("click", checkUpdate);
  const btnLocalUpdate = document.getElementById("btnLocalUpdate");
  if (btnLocalUpdate) btnLocalUpdate.addEventListener("click", localUpdate);

  // Warframe 平台设置
  loadWfPlatform();
  document.getElementById("btnSaveWfPlatform").addEventListener("click", async () => {
    const platform = document.getElementById("wfPlatform").value;
    const r = await window.api.wfSetPlatform(platform);
    if (r.success) showToast("Warframe 平台已设置为: " + platform, "success");
    else showToast("设置失败: " + (r.error || "未知错误"), "error");
  });
}

// ==================== 在线更新 ====================
async function loadVersion() {
  try {
    const r = await window.api.updateGetVersion();
    const ver = r.version || "未知";
    const verEl = document.getElementById("appVersion");
    if (verEl) verEl.textContent = `桌面版 v${ver}`;
    const aboutVer = document.getElementById("aboutVersion");
    if (aboutVer) aboutVer.textContent = `版本 v${ver}（OneBot v11 + 网站对接 + 群粒度开关 + 在线更新）`;
  } catch (e) {}
}

async function checkUpdate() {
  const btn = document.getElementById("btnCheckUpdate");
  const result = document.getElementById("updateResult");
  btn.disabled = true;
  btn.textContent = "正在检查...";
  result.style.display = "block";
  result.textContent = "正在连接更新服务器...";
  try {
    const r = await window.api.updateCheck();
    if (!r.success) {
      result.textContent = "检查失败: " + (r.error || "未知错误");
      result.style.color = "#ff6b6b";
    } else if (r.hasUpdate) {
      result.innerHTML = `<strong style="color:#ffd93d;">发现新版本 v${r.latestVersion}</strong><br>${r.notes || ""}<br><br>当前版本: v${r.currentVersion}`;
      btn.textContent = "下载并更新";
      btn.disabled = false;
      btn.onclick = async () => {
        btn.disabled = true;
        btn.textContent = "正在下载更新...";
        result.textContent = "正在下载更新包，请稍候...";
        const dl = await window.api.updateDownload();
        if (dl.success) {
          result.innerHTML = `<strong style="color:#6bcb77;">更新完成！</strong><br>${dl.message}`;
          btn.textContent = "立即重启";
          btn.onclick = () => window.api.updateRestart();
          btn.disabled = false;
        } else {
          result.textContent = "更新失败: " + (dl.error || "未知错误");
          result.style.color = "#ff6b6b";
          btn.textContent = "检查更新";
          btn.onclick = checkUpdate;
          btn.disabled = false;
        }
      };
      return;
    } else {
      result.innerHTML = `<strong style="color:#6bcb77;">已是最新版本</strong><br>当前版本: v${r.currentVersion}`;
    }
  } catch (e) {
    result.textContent = "检查失败: " + e.message;
    result.style.color = "#ff6b6b";
  }
  btn.textContent = "检查更新";
  btn.disabled = false;
}

async function localUpdate() {
  const result = document.getElementById("updateResult");
  result.style.display = "block";
  result.textContent = "请选择本地 update.zip 更新包...";
  try {
    const r = await window.api.updateLocal();
    if (r.success) {
      result.innerHTML = `<strong style="color:#6bcb77;">更新完成！</strong><br>${r.message}<br><br><button class="btn btn-primary" id="btnRestartNow" style="margin-top:8px;">立即重启</button>`;
  const _btnRestartNow = document.getElementById("btnRestartNow");
  if (_btnRestartNow) _btnRestartNow.addEventListener("click", () => { window.api.restartApp(); });
    } else {
      result.textContent = r.error || "更新已取消";
      result.style.color = "#ff6b6b";
    }
  } catch (e) {
    result.textContent = "更新失败: " + e.message;
    result.style.color = "#ff6b6b";
  }
}

async function loadWfPlatform() {
  try {
    const r = await window.api.wfGetPlatform();
    const sel = document.getElementById("wfPlatform");
    if (sel && r.platform) sel.value = r.platform;
  } catch (e) {}
}

function updateMaximizeIcon(maximized) {
  const btn = document.getElementById("btnMaximize");
  if (!btn) return;
  if (maximized) {
    btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12"><rect x="3" y="1.5" width="6" height="6" fill="none" stroke="currentColor" stroke-width="1"/><rect x="1.5" y="3" width="6" height="6" fill="none" stroke="currentColor" stroke-width="1"/></svg>';
    btn.title = "还原";
  } else {
    btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12"><rect x="2.5" y="2.5" width="7" height="7" fill="none" stroke="currentColor" stroke-width="1"/></svg>';
    btn.title = "最大化";
  }

  // 欢迎按钮配置
  document.getElementById("btnAddWelcomeButton").addEventListener("click", () => {
    welcomeButtonsList.push({ label: "新按钮", type: "link", data: "https://", style: 1 });
    renderWelcomeButtons();
  });

  // 图片上传
  const _btnUploadWelcomeImage = document.getElementById("btnUploadWelcomeImage");
  if (_btnUploadWelcomeImage) _btnUploadWelcomeImage.addEventListener("click", async () => {
    try {
      const result = await window.api.selectImage();
      if (result && result.success) {
        document.getElementById("cfgWelcomeImage").value = result.dataUrl;
        updateWelcomeImagePreview(result.dataUrl);
        showToast("图片已上传 (" + result.fileSize + ")");
      }
    } catch(e) {
      showToast("选择图片失败: " + e.message, "error");
    }
  });

  // 复制日志
  
  // ========== 系统设置 ==========
  // Tab切换（事件委托，确保可点击）
  document.addEventListener("click", (e) => {
    const tab = e.target.closest(".settings-tab");
    if (tab) {
      e.preventDefault();
      e.stopPropagation();
      document.querySelectorAll(".settings-tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".settings-panel").forEach(p => p.classList.remove("active"));
      tab.classList.add("active");
      const panel = document.getElementById("panel-" + tab.dataset.tab);
      if (panel) panel.classList.add("active");
    }
  });
  
  // 主题色切换
  document.querySelectorAll(".theme-color").forEach(color => {
    color.addEventListener("click", () => {
      document.querySelectorAll(".theme-color").forEach(c => c.classList.remove("active"));
      color.classList.add("active");
      const newColor = color.dataset.color;
      document.documentElement.style.setProperty("--accent", newColor);
      showToast("主题色已切换", "success");
    });
  });
  
  // 保存通用设置
  document.getElementById("btnSaveGeneral").addEventListener("click", async () => {
    const config = await window.api.getConfig();
    config.system = config.system || {};
    config.system.botNickname = document.getElementById("cfgBotNickname").value || "小熊";
    config.system.defaultReply = document.getElementById("cfgDefaultReply").value;
    config.system.globalEnabled = document.getElementById("cfgGlobalEnabled").checked;
    config.system.antiSpam = parseInt(document.getElementById("cfgAntiSpam").value) || 0;
    config.system.autoConnect = document.getElementById("cfgAutoConnect").checked;
    await window.api.saveConfig(config);
    showSavedToast("btnSaveGeneral");
  });
  
  // 保存日志设置
  document.getElementById("btnSaveLog").addEventListener("click", async () => {
    const config = await window.api.getConfig();
    config.system = config.system || {};
    config.system.logLevel = document.getElementById("cfgLogLevel").value;
    config.system.logRetention = parseInt(document.getElementById("cfgLogRetention").value) || 7;
    await window.api.saveConfig(config);
    showSavedToast("btnSaveLog");
  });
  
  // 保存界面设置
  document.getElementById("btnSaveUI").addEventListener("click", async () => {
    const config = await window.api.getConfig();
    config.system = config.system || {};
    config.system.ui = config.system.ui || {};
    const activeColor = document.querySelector(".theme-color.active");
    config.system.ui.accentColor = activeColor ? activeColor.dataset.color : "#5c6bc0";
    config.system.ui.bgImage = document.getElementById("cfgBgImage").value;
    config.system.ui.fontSize = document.getElementById("cfgFontSize").value;
    await window.api.saveConfig(config);
    // 应用字体大小
    document.documentElement.style.fontSize = config.system.ui.fontSize + "px";
    showSavedToast("btnSaveUI");
  });
  
  // 保存安全设置
  document.getElementById("btnSaveSecurity").addEventListener("click", async () => {
    const config = await window.api.getConfig();
    config.system = config.system || {};
    config.system.adminList = document.getElementById("cfgAdminList").value.split("\n").map(s => s.trim()).filter(s => s);
    config.system.opPassword = document.getElementById("cfgOpPassword").value;
    config.system.groupBlacklist = document.getElementById("cfgGroupBlacklist").value.split("\n").map(s => s.trim()).filter(s => s);
    config.system.userBlacklist = document.getElementById("cfgUserBlacklist").value.split("\n").map(s => s.trim()).filter(s => s);
    await window.api.saveConfig(config);
    showSavedToast("btnSaveSecurity");
  });
  
  // 保存高级设置
  document.getElementById("btnSaveAdvanced").addEventListener("click", async () => {
    const config = await window.api.getConfig();
    config.system = config.system || {};
    config.system.debugMode = document.getElementById("cfgDebugMode").checked;
    config.system.msgTimeout = parseInt(document.getElementById("cfgMsgTimeout").value) || 10;
    config.system.reconnectLimit = parseInt(document.getElementById("cfgReconnectLimit").value) || 10;
    config.system.concurrency = parseInt(document.getElementById("cfgConcurrency").value) || 3;
    await window.api.saveConfig(config);
    showSavedToast("btnSaveAdvanced");
  });
  
  // 系统设置里的导出/导入配置
  const _btnExportConfig2 = document.getElementById("btnExportConfig2");
  if (_btnExportConfig2) _btnExportConfig2.addEventListener("click", () => { const _btnExport = document.getElementById("btnExport"); if (_btnExport) _btnExport.click(); });
  const _btnImportConfig2 = document.getElementById("btnImportConfig2");
  if (_btnImportConfig2) _btnImportConfig2.addEventListener("click", () => { const _btnImport = document.getElementById("btnImport"); if (_btnImport) _btnImport.click(); });
  

}

  

function setupEventListeners() {
  window.api.onLog((entry) => appendLog(entry));
  window.api.onStatus((data) => updateStatusUI(data));
  // 官方机器人被添加到群
  if (window.api.onOfficialGroupAdded) {
    window.api.onOfficialGroupAdded((data) => {
      addRecentGroup(data.group_openid, data.time);
      showToast("官方机器人已被添加到新群！group_openid已复制", "success");
      fallbackCopy(data.group_openid);
    });
  }
}

// ==================== 配置填充 ====================
function fillAllForms(config) {
  // 官方机器人配置
  document.getElementById("cfgOfficialAppId").value = (config.official && config.official.appId) || "";
  document.getElementById("cfgOfficialAppSecret").value = (config.official && config.official.appSecret) || "";
  // 网站
  document.getElementById("cfgWebsiteUrl").value = (config.website && config.website.url) || "";
  document.getElementById("cfgWebsiteInterval").value = (config.website && config.website.checkInterval) || 5;
  document.getElementById("cfgWebsiteTemplate").value = (config.website && config.website.pushTemplate) || "";
  document.getElementById("cfgWebsiteEnabled").checked = (config.website && config.website.enabled) !== false;
  // 欢迎
  document.getElementById("cfgWelcomeMessage").value = (config.welcome && config.welcome.message) || "";
  document.getElementById("cfgWelcomeImage").value = (config.welcome && config.welcome.image) || "";
  updateWelcomeImagePreview((config.welcome && config.welcome.image) || "");
  welcomeButtonsList = JSON.parse(JSON.stringify((config.welcome && config.welcome.buttons) || []));
  renderWelcomeButtons();
  document.getElementById("cfgLeaveMessage").value = (config.leaveNotice && config.leaveNotice.message) || "";
  // 关键词
  keywordEditingList = JSON.parse(JSON.stringify(config.keywordReplies || []));
  renderKeywordList();
  // 一言
  document.getElementById("cfgHitokoto").value = (config.hitokotoList || []).join("\n");
  // 默认设置
  const d = config.defaults || {};
  document.getElementById("defWelcome").checked = d.welcome !== false;
  document.getElementById("defLeaveNotice").checked = d.leaveNotice !== false;
  document.getElementById("defKeywordReply").checked = d.keywordReply !== false;
  document.getElementById("defWebsitePush").checked = d.websitePush !== false;
  document.getElementById("defAdmin").checked = d.admin !== false;
  document.getElementById("defHitokoto").checked = d.hitokoto !== false;
  
  // 系统设置-通用设置
  const sys = config.system || {};
  if (document.getElementById("cfgBotNickname")) document.getElementById("cfgBotNickname").value = sys.botNickname || "小熊";
  if (document.getElementById("cfgDefaultReply")) document.getElementById("cfgDefaultReply").value = sys.defaultReply || "";
  if (document.getElementById("cfgGlobalEnabled")) document.getElementById("cfgGlobalEnabled").checked = sys.globalEnabled !== false;
  if (document.getElementById("cfgAntiSpam")) document.getElementById("cfgAntiSpam").value = sys.antiSpam || 3;
  if (document.getElementById("cfgAutoConnect")) document.getElementById("cfgAutoConnect").checked = sys.autoConnect === true;
}

function collectConnectionConfig() {
  if (!currentConfig.official) currentConfig.official = {};
  currentConfig.official.appId = document.getElementById("cfgOfficialAppId").value.trim();
  currentConfig.official.appSecret = document.getElementById("cfgOfficialAppSecret").value.trim();
  // 自动连接开关
  const autoConnectEl = document.getElementById("cfgAutoConnect");
  if (autoConnectEl) {
    if (!currentConfig.system) currentConfig.system = {};
    currentConfig.system.autoConnect = autoConnectEl.checked;
  }
}
function collectWebsiteConfig() {
  currentConfig.website.enabled = document.getElementById("cfgWebsiteEnabled").checked;
  currentConfig.website.url = document.getElementById("cfgWebsiteUrl").value.trim();
  currentConfig.website.checkInterval = parseInt(document.getElementById("cfgWebsiteInterval").value) || 5;
  currentConfig.website.pushTemplate = document.getElementById("cfgWebsiteTemplate").value;
}
function collectWelcomeConfig() {
  currentConfig.welcome.message = document.getElementById("cfgWelcomeMessage").value;
  currentConfig.welcome.image = document.getElementById("cfgWelcomeImage").value.trim();
  currentConfig.welcome.buttons = welcomeButtonsList.filter((b) => b.label.trim() !== "");
  currentConfig.leaveNotice.message = document.getElementById("cfgLeaveMessage").value;
}

function collectKeywordsConfig() {
  currentConfig.keywordReplies = keywordEditingList.filter((i) => i.keyword.trim() !== "");
}
function collectAdminConfig() {
  const hitokoto = document.getElementById("cfgHitokoto").value;
  currentConfig.hitokotoList = hitokoto.split("\n").map((s) => s.trim()).filter((s) => s !== "");
}
function collectDefaultsConfig() {
  currentConfig.defaults = {
    welcome: document.getElementById("defWelcome").checked,
    leaveNotice: document.getElementById("defLeaveNotice").checked,
    keywordReply: document.getElementById("defKeywordReply").checked,
    websitePush: document.getElementById("defWebsitePush").checked,
    admin: document.getElementById("defAdmin").checked,
    hitokoto: document.getElementById("defHitokoto").checked,
  };
}
async function saveAllConfig(showToastMsg = true) {
  const r = await window.api.saveConfig(currentConfig);
  if (showToastMsg) {
    showToast(r.success ? "配置已保存" : "保存失败", r.success ? "success" : "error");
  }
  return r;
}

// ==================== 网站推送功能 ====================
async function testWebsite() {
  collectWebsiteConfig();
  await saveAllConfig();
  const resultEl = document.getElementById("websiteTestResult");
  resultEl.style.display = "block";
  resultEl.innerHTML = '<div style="padding:12px;color:#666;">正在测试连接...</div>';
  const r = await window.api.websiteTest();
  if (r.success && r.posts) {
    let html = '<div style="padding:12px;color:#2e7d32;font-weight:bold;margin-bottom:8px;">✅ 连接成功！最新3篇文章：</div>';
    r.posts.forEach((p) => {
      const title = (p.title && p.title.rendered) ? p.title.rendered.replace(/<[^>]+>/g, "") : "无标题";
      html += `<div style="padding:8px 0;border-bottom:1px solid #eee;font-size:13px;"><a href="${p.link}" target="_blank" style="color:#1976d2;">${escapeHtml(title)}</a><br><span style="color:#999;font-size:12px;">ID: ${p.id} | ${p.date}</span></div>`;
    });
    resultEl.innerHTML = html;
  } else {
    resultEl.innerHTML = `<div style="padding:12px;color:#c62828;">❌ 连接失败: ${escapeHtml(r.error || "未知错误")}</div>`;
  }
}
async function pushNow() {
  collectWebsiteConfig();
  await saveAllConfig(false); // 不显示"配置已保存"提示
  const r = await window.api.websitePushNow();
  if (r.success) showToast("已推送最新文章", "success");
  else showToast("推送失败: " + (r.error || ""), "error");
}
function addPushGroup() {
  const input = document.getElementById("newPushGroup");
  const gid = input.value.trim();
  if (!gid) { showToast("请输入有效的群号或openid", "error"); return; }
  const isOpenId = gid.length === 32 && /^[0-9A-Fa-f]+$/.test(gid);
  const isQQGroup = !isNaN(parseInt(gid)) && parseInt(gid) > 10000;
  if (!isOpenId && !isQQGroup) { showToast("请输入有效的QQ群号（数字）或群openid（32位十六进制）", "error"); return; }
  if (!currentConfig.website.pushGroups) currentConfig.website.pushGroups = [];
  if (currentConfig.website.pushGroups.includes(gid)) { showToast("该群已添加", "warn"); return; }
  currentConfig.website.pushGroups.push(gid);
  saveAllConfig();
  input.value = "";
  renderPushGroupList();
  showToast("已添加推送群", "success");
}
function renderPushGroupList() {
  const container = document.getElementById("pushGroupList");
  const groups = currentConfig.website.pushGroups || [];
  if (groups.length === 0) { container.innerHTML = '<div style="padding:12px;color:#999;font-size:13px;">暂无推送群，添加后该群将收到网站新游推送</div>'; return; }
  container.innerHTML = groups.map((gid) => `
    <div class="push-group-item">
      <span class="pg-id">群 ${gid}</span>
      <button class="btn btn-sm btn-danger" onclick="removePushGroup('${gid}')">移除</button>
    </div>
  `).join("");
}
window.removePushGroup = async function(gid) {
  currentConfig.website.pushGroups = (currentConfig.website.pushGroups || []).filter((g) => g !== gid);
  await saveAllConfig();
  renderPushGroupList();
  showToast("已移除", "info");
};

﻿// ==================== 最近活跃群 ====================
async function loadRecentGroups() {
  const container = document.getElementById("recentGroupsList");
  if (!container) return;
  try {
    const result = await window.api.getRecentGroups();
    const groups = (result && result.groups) || [];
    if (groups.length === 0) {
      container.innerHTML = '<div style="padding:12px;color:#999;font-size:13px;text-align:center;">暂无活跃群，让群里发一条消息后刷新即可看到</div>';
      return;
    }
    let html = "";
    groups.forEach((g) => {
      const time = new Date(g.lastActive).toLocaleString("zh-CN");
      const isAdded = currentConfig.groupSettings && currentConfig.groupSettings[g.id];
      html += '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border:1px solid rgba(255,255,255,0.1);border-radius:6px;margin-bottom:6px;">';
      html += '<div style="flex:1;min-width:0;">';
      html += '<div style="font-size:13px;font-family:monospace;word-break:break-all;">' + g.id + '</div>';
      html += '<div style="font-size:11px;color:#888;margin-top:2px;">最后活跃: ' + time + '</div>';
      html += '</div>';
      if (isAdded) {
        html += '<span style="color:#4CAF50;font-size:12px;">已添加</span>';
      } else {
        html += '<button class="btn btn-sm btn-primary" onclick="addRecentGroupById(\'' + g.id + '\')">添加</button>';
      }
      html += '</div>';
    });
    container.innerHTML = html;
  } catch (e) {
    container.innerHTML = '<div style="padding:12px;color:#f44;font-size:13px;text-align:center;">加载失败: ' + e.message + '</div>';
  }
}
function addRecentGroupById(gid) {
  if (!currentConfig.groupSettings) currentConfig.groupSettings = {};
  if (currentConfig.groupSettings[gid]) { showToast("该群已在管理列表", "warn"); return; }
  currentConfig.groupSettings[gid] = { ...currentConfig.defaults };
  saveAllConfig();
  renderGroupSettingsList();
  loadRecentGroups();
  showToast("已添加群", "success");
}


// ==================== 群功能管理 ====================
function addGroupToManage() {
  const input = document.getElementById("newGroupId");
  const gid = input.value.trim();
  if (!gid) { showToast("请输入有效的群号或openid", "error"); return; }
  const isOpenId = gid.length === 32 && /^[0-9A-Fa-f]+$/.test(gid);
  const isQQGroup = !isNaN(parseInt(gid)) && parseInt(gid) > 10000;
  if (!isOpenId && !isQQGroup) { showToast("请输入有效的QQ群号（数字）或群openid（32位十六进制）", "error"); return; }
  if (!currentConfig.groupSettings) currentConfig.groupSettings = {};
  if (currentConfig.groupSettings[gid]) { showToast("该群已在管理列表", "warn"); return; }
  currentConfig.groupSettings[gid] = { ...currentConfig.defaults };
  saveAllConfig();
  input.value = "";
  renderGroupSettingsList();
  showToast("已添加群", "success");
}
function renderGroupSettingsList() {
  const container = document.getElementById("groupSettingsList");
  const groups = currentConfig.groupSettings || {};
  const gids = Object.keys(groups);
  if (gids.length === 0) { container.innerHTML = '<div style="padding:16px;color:#999;font-size:13px;text-align:center;">暂无管理群，添加后可单独控制每个群的功能开关</div>'; return; }
  container.innerHTML = gids.map((gid) => {
    const s = groups[gid];
    return `
    <div class="group-setting-card" data-gid="${gid}">
      <div class="gsc-header" onclick="toggleGroupPanel('${gid}')">
        <span class="gsc-title">👥 群 ${gid}</span>
        <span class="gsc-toggle">▼</span>
      </div>
      <div class="gsc-body" id="gsc-body-${gid}">
        <div class="gsc-switches">
          <label class="switch-label"><input type="checkbox" class="gs-welcome" ${s.welcome ? "checked" : ""}><span>入群欢迎</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-leaveNotice" ${s.leaveNotice ? "checked" : ""}><span>退群提醒</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-keywordReply" ${s.keywordReply ? "checked" : ""}><span>关键词回复</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-websitePush" ${s.websitePush ? "checked" : ""}><span>网站推送</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-websiteQuery" ${s.websiteQuery !== false ? "checked" : ""}><span>网站查询</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-warframe" ${s.warframe !== false ? "checked" : ""}><span>Warframe查询</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-admin" ${s.admin ? "checked" : ""}><span>群管指令</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-hitokoto" ${s.hitokoto ? "checked" : ""}><span>一言功能</span></label>
        </div>
        <div class="gsc-actions">
          <button class="btn btn-sm btn-primary" onclick="saveGroupSettings('${gid}')">保存此群设置</button>
          <button class="btn btn-sm btn-ghost" onclick="resetGroupSettings('${gid}')">恢复默认</button>
          <button class="btn btn-sm btn-danger" onclick="removeGroupSettings('${gid}')">从列表移除</button>
        </div>
      </div>
    </div>`;
  }).join("");
}
;
window.saveGroupSettings = async function(gid) {
  const card = document.querySelector(`.group-setting-card[data-gid="${gid}"]`);
  currentConfig.groupSettings[gid] = {
    welcome: card.querySelector(".gs-welcome").checked,
    leaveNotice: card.querySelector(".gs-leaveNotice").checked,
    keywordReply: card.querySelector(".gs-keywordReply").checked,
    websitePush: card.querySelector(".gs-websitePush").checked,
    websiteQuery: card.querySelector(".gs-websiteQuery").checked,
    warframe: card.querySelector(".gs-warframe").checked,
    admin: card.querySelector(".gs-admin").checked,
    hitokoto: card.querySelector(".gs-hitokoto").checked,
  };
  await saveAllConfig();
  showToast(`群 ${gid} 设置已保存`, "success");
};
window.resetGroupSettings = async function(gid) {
  currentConfig.groupSettings[gid] = { ...currentConfig.defaults };
  await saveAllConfig();
  renderGroupSettingsList();
  showToast("已恢复默认设置", "info");
};
window.removeGroupSettings = async function(gid) {
  delete currentConfig.groupSettings[gid];
  await saveAllConfig();
  renderGroupSettingsList();
  showToast("已从管理列表移除", "info");
};

// ==================== 关键词列表渲染 ====================
function renderKeywordList() {
  const container = document.getElementById("keywordList");
  if (keywordEditingList.length === 0) {
    container.innerHTML = '<div class="keyword-empty">暂无关键词规则，点击右上角"添加规则"开始添加</div>';
    return;
  }
  container.innerHTML = keywordEditingList.map((item, idx) => `
    <div class="keyword-item" data-idx="${idx}">
      <div class="kw-inputs">
        <div class="kw-row">
          <input type="text" class="input kw-keyword" placeholder="关键词" value="${escapeHtml(item.keyword)}">
          <select class="input kw-mode">
            <option value="includes" ${item.mode === "includes" ? "selected" : ""}>包含匹配</option>
            <option value="exact" ${item.mode === "exact" ? "selected" : ""}>精确匹配</option>
          </select>
        </div>
        <div class="kw-row">
          <input type="text" class="input kw-reply" placeholder="回复内容" value="${escapeHtml(item.reply)}">
        </div>
      </div>
      <button class="btn-delete" data-idx="${idx}">删除</button>
    </div>
  `).join("");
  container.querySelectorAll(".keyword-item").forEach((el) => {
    const idx = parseInt(el.dataset.idx);
    el.querySelector(".kw-keyword").addEventListener("input", (e) => { keywordEditingList[idx].keyword = e.target.value; });
    el.querySelector(".kw-reply").addEventListener("input", (e) => { keywordEditingList[idx].reply = e.target.value; });
    el.querySelector(".kw-mode").addEventListener("change", (e) => { keywordEditingList[idx].mode = e.target.value; });
    el.querySelector(".btn-delete").addEventListener("click", () => { keywordEditingList.splice(idx, 1); renderKeywordList(); });
  });
}

// ==================== 状态UI ====================
function updateStatusUI(data) {
  const status = typeof data === "string" ? data : data.status;
  const botQQ = typeof data === "object" ? data.botQQ : null;
  const dot = document.querySelector(".status-dot");
  const text = document.getElementById("statusText");
  const qqText = document.getElementById("statusQQ");
  const btnConnect = document.getElementById("btnConnect");
  const btnDisconnect = document.getElementById("btnDisconnect");
  dot.className = "status-dot " + status;
  const statusMap = { disconnected: "未连接", connecting: "连接中...", connected: "已连接", error: "异常" };
  text.textContent = statusMap[status] || status;
  // 根据连接模式显示不同的状态文本
  const isOfficial = currentConfig && currentConfig.officialMode === true;
  let modeText = isOfficial ? "官方机器人" : "OneBot 服务";
  
  if (botQQ) qqText.textContent = `机器人QQ: ${botQQ}`;
  else if (status === "connected") qqText.textContent = `已连接 ${modeText}`;
  else qqText.textContent = `等待连接 ${modeText}`;
  if (status === "connected" || status === "connecting") { btnConnect.disabled = true; btnDisconnect.disabled = false; }
  else { btnConnect.disabled = false; btnDisconnect.disabled = true; }
}

// ==================== 日志 ====================
function renderLogs(logs) {
  const container = document.getElementById("consoleLog");
  container.innerHTML = "";
  logs.forEach((entry) => appendLog(entry, false));
  container.scrollTop = container.scrollHeight;
}
function appendLog(entry) {
  const container = document.getElementById("consoleLog");
  const div = document.createElement("div");
  div.className = "log-entry";
  div.innerHTML = `<span class="log-time">[${entry.time}]</span><span class="log-type ${entry.type}">${entry.type.toUpperCase()}</span><span class="log-message">${escapeHtml(entry.message)}</span>`;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
  while (container.children.length > 500) container.removeChild(container.firstChild);
}

// ==================== Toast ====================

function showToast(message, type = "info") {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.className = "toast " + type + " show";
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2500);
}


// 保存成功按钮反馈
function showSavedToast(btnId) {
  const btn = document.getElementById(btnId);
  if (!btn) return;
  const originalText = btn.textContent;
  btn.textContent = "✓ 已保存";
  btn.disabled = true;
  setTimeout(() => {
    btn.textContent = originalText;
    btn.disabled = false;
  }, 2000);
  showToast("设置已保存", "success");
}



// ==================== 工具 ====================

// 最近添加的群
let recentGroups = [];
function addRecentGroup(groupOpenid, time) {
  recentGroups.unshift({ openid: groupOpenid, time: time });
  if (recentGroups.length > 5) recentGroups = recentGroups.slice(0, 5);
  renderRecentGroups();
}
function renderRecentGroups() {
  const area = document.getElementById("recentGroupsArea");
  const list = document.getElementById("recentGroupsList");
  if (!area || !list) return;
  if (recentGroups.length === 0) {
    area.style.display = "none";
    return;
  }
  area.style.display = "block";
  list.innerHTML = "";
  recentGroups.forEach((g, idx) => {
    const item = document.createElement("div");
    item.style.cssText = "display:flex;align-items:center;gap:10px;padding:8px 12px;background:rgba(255,255,255,0.05);border-radius:6px;cursor:pointer;border:1px solid rgba(255,255,255,0.1);";
    item.innerHTML = `<span style="flex:1;font-family:monospace;font-size:12px;word-break:break-all;">${g.openid}</span><span style="font-size:11px;color:var(--text-muted);white-space:nowrap;">${g.time}</span><span style="font-size:11px;color:var(--accent);white-space:nowrap;">点击复制</span>`;
    item.addEventListener("click", () => {
      fallbackCopy(g.openid);
    });
    list.appendChild(item);
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}


// ==================== WF指令别名管理 ====================
let currentWfAliases = {};

// 加载别名列表
async function loadWfAliases() {
  try {
    const result = await window.api.wfGetAliases();
    if (result && result.success) {
      currentWfAliases = result.aliases || {};
      renderAliasList();
    } else {
      document.getElementById("aliasList").innerHTML = "<div style='color:#ff6b6b;text-align:center;padding:20px;'>加载失败: " + (result?.error || "未知错误") + "</div>";
    }
  } catch (e) {
    document.getElementById("aliasList").innerHTML = "<div style='color:#ff6b6b;text-align:center;padding:20px;'>加载失败: " + e.message + "</div>";
  }
}

// 渲染别名列表（用DOM操作，避免引号转义问题）
function renderAliasList() {
  const list = document.getElementById("aliasList");
  if (!list) return;
  
  const keys = Object.keys(currentWfAliases);
  if (keys.length === 0) {
    list.innerHTML = "<div style='color:#888;text-align:center;padding:20px;'>暂无别名，点击上方添加</div>";
    return;
  }
  
  list.innerHTML = "";
  keys.forEach(alias => {
    const target = currentWfAliases[alias];
    
    // 创建容器div
    const div = document.createElement("div");
    div.style.cssText = "display:flex;align-items:center;gap:10px;padding:8px 10px;margin-bottom:6px;background:rgba(255,255,255,0.03);border-radius:6px;border:1px solid rgba(255,255,255,0.08);";
    
    // 别名
    const code1 = document.createElement("code");
    code1.style.cssText = "color:#00d4ff;font-weight:bold;min-width:80px;";
    code1.textContent = alias;
    
    // 箭头
    const arrow = document.createElement("span");
    arrow.style.color = "#888";
    arrow.textContent = "→";
    
    // 目标指令
    const code2 = document.createElement("code");
    code2.style.cssText = "color:#ffc800;flex:1;";
    code2.textContent = target;
    
    // 删除按钮
    const btn = document.createElement("button");
    btn.style.cssText = "background:rgba(255,107,107,0.15);color:#ff6b6b;border:none;padding:4px 10px;border-radius:4px;cursor:pointer;font-size:12px;";
    btn.textContent = "删除";
    btn.addEventListener("click", () => deleteWfAlias(alias));
    
    div.appendChild(code1);
    div.appendChild(arrow);
    div.appendChild(code2);
    div.appendChild(btn);
    list.appendChild(div);
  });
}

// 添加别名
function addWfAlias() {
  const aliasInput = document.getElementById("newAlias");
  const targetInput = document.getElementById("newAliasTarget");
  const alias = aliasInput.value.trim();
  const target = targetInput.value.trim();
  
  if (!alias || !target) {
    showAlert("请填写别名和标准指令");
    return;
  }
  
  if (!alias.startsWith("#")) {
    showAlert("别名必须以 # 开头");
    return;
  }
  
  currentWfAliases[alias] = target;
  renderAliasList();
  aliasInput.value = "";
  targetInput.value = "";
}

// 删除别名
async function deleteWfAlias(alias) {
  if (await showConfirm("确定删除别名 " + alias + " 吗？")) {
    delete currentWfAliases[alias];
    renderAliasList();
  }
}

// 保存别名
async function saveWfAliases() {
  try {
    const result = await window.api.wfSaveAliases(currentWfAliases);
    if (result && result.success) {
      showSuccess("别名保存成功！重启软件后生效");
    } else {
      showError("保存失败: " + (result?.error || "未知错误"));
    }
  } catch (e) {
    showError("保存失败: " + e.message);
  }
}

// 恢复默认别名
async function resetWfAliases() {
  if (!await showConfirm("确定恢复默认别名吗？当前自定义的别名将被覆盖")) {
    return;
  }
  try {
    const result = await window.api.wfResetAliases();
    if (result && result.success) {
      currentWfAliases = result.aliases || {};
      renderAliasList();
      showSuccess("已恢复默认别名！重启软件后生效");
    } else {
      showError("恢复失败: " + (result?.error || "未知错误"));
    }
  } catch (e) {
    showError("恢复失败: " + e.message);
  }
}


// ==================== 修仙管理功能 ====================
function showXiuxianTab(tab) {
  document.querySelectorAll('.xiuxian-tab').forEach(t => t.style.display = 'none');
  const target = document.getElementById('xiuxianTab-' + tab);
  if (target) target.style.display = 'block';
  
  // 切换时自动加载对应数据
  if (tab === 'players') refreshXiuxianPlayers();
  if (tab === 'config') loadXiuxianConfig();
  if (tab === 'sects') refreshXiuxianSects();
  if (tab === 'market') refreshXiuxianMarket();
  if (tab === 'activity') refreshXiuxianActivities();
}

async function refreshXiuxianStats() {
  try {
    const result = await window.api.xiuxianGetStats();
    if (result.success) {
      document.getElementById('statTotalPlayers').textContent = result.data.totalPlayers;
      document.getElementById('statActivePlayers').textContent = result.data.activePlayers;
      document.getElementById('statTotalSects').textContent = result.data.totalSects;
      document.getElementById('statMarketItems').textContent = result.data.marketItems;
    }
  } catch (e) {
    console.error('刷新修仙统计失败:', e);
  }
}

async function refreshXiuxianPlayers() {
  const listEl = document.getElementById('xiuxianPlayerList');
  listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">加载中...</div>';
  try {
    const result = await window.api.xiuxianGetPlayers();
    if (result.success && result.data && result.data.players.length > 0) {
      let html = '<table style="width:100%;border-collapse:collapse;font-size:13px;">';
      html += '<thead><tr style="background:rgba(255,255,255,0.05);">';
      html += '<th style="padding:8px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.1);">QQ号</th>';
      html += '<th style="padding:8px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.1);">昵称</th>';
      html += '<th style="padding:8px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.1);">境界</th>';
      html += '<th style="padding:8px;text-align:right;border-bottom:1px solid rgba(255,255,255,0.1);">战力</th>';
      html += '<th style="padding:8px;text-align:right;border-bottom:1px solid rgba(255,255,255,0.1);">灵石</th>';
      html += '<th style="padding:8px;text-align:center;border-bottom:1px solid rgba(255,255,255,0.1);">操作</th>';
      html += '</tr></thead><tbody>';
      
      result.data.players.forEach((p, index) => {
        html += '<tr style="border-bottom:1px solid rgba(255,255,255,0.05);">';
        // QQ号显示：如果是openid（长度>15且包含字母），显示截断的openid
        let qqDisplay = p.qq;
        if (p.qq && p.qq.length > 15 && /[A-Z]/.test(p.qq)) {
          qqDisplay = p.qq.substring(0, 8) + '... (官方用户)';
        }
        html += '<td style="padding:8px;" title="' + p.qq + '">' + qqDisplay + '</td>';
        html += '<td style="padding:8px;">' + (p.nickname || '未知') + '</td>';
        const realmNames = ['练气期','筑基期','金丹期','元婴期','化神期','炼虚期','合体期','大乘期','渡劫期','仙人'];
        const realmName = realmNames[(p.realmId || 1) - 1] || '练气期';
        html += '<td style="padding:8px;">' + realmName + ' ' + (p.realmLevel || 1) + '层</td>';
        html += '<td style="padding:8px;text-align:right;">' + (p.power || 0).toLocaleString() + '</td>';
        html += '<td style="padding:8px;text-align:right;">' + (p.gold || 0).toLocaleString() + '</td>';
        html += '<td style="padding:8px;text-align:center;">';
        html += '<button class="btn btn-sm btn-ghost btn-view" data-qq="' + p.qq + '">详情</button> ';
        html += '<button class="btn btn-sm btn-primary btn-gold" data-qq="' + p.qq + '">灵石</button> ';
        html += '<button class="btn btn-sm btn-success btn-exp" data-qq="' + p.qq + '">修为</button> ';
        if (p.banned) {
          html += '<button class="btn btn-sm btn-warning btn-unban" data-qq="' + p.qq + '">解封</button>';
        } else {
          html += '<button class="btn btn-sm btn-danger btn-ban" data-qq="' + p.qq + '">封禁</button>';
        }
        html += '</td>';
        html += '</tr>';
      });
      
      html += '</tbody></table>';
      listEl.innerHTML = html;
      
      // 动态绑定按钮事件（解决contextIsolation下onclick无法调用函数的问题）
      setTimeout(() => {
        listEl.querySelectorAll('.btn-view').forEach(btn => {
          btn.addEventListener('click', () => viewXiuxianPlayer(btn.dataset.qq));
        });
        listEl.querySelectorAll('.btn-gold').forEach(btn => {
          btn.addEventListener('click', () => addXiuxianGold(btn.dataset.qq));
        });
        listEl.querySelectorAll('.btn-exp').forEach(btn => {
          btn.addEventListener('click', () => addXiuxianExp(btn.dataset.qq));
        });
        listEl.querySelectorAll('.btn-ban').forEach(btn => {
          btn.addEventListener('click', () => banXiuxianPlayer(btn.dataset.qq));
        });
        listEl.querySelectorAll('.btn-unban').forEach(btn => {
          btn.addEventListener('click', () => unbanXiuxianPlayer(btn.dataset.qq));
        });
      }, 10);
    } else {
      listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">暂无玩家数据</div>';
    }
    refreshXiuxianStats();
  } catch (e) {
    listEl.innerHTML = '<div style="color:#f55;text-align:center;padding:30px;">加载失败: ' + e.message + '</div>';
  }
}

function searchXiuxianPlayers() {
  const keyword = document.getElementById('xiuxianPlayerSearch').value.toLowerCase();
  const rows = document.querySelectorAll('#xiuxianPlayerList tbody tr');
  rows.forEach(row => {
    const text = row.textContent.toLowerCase();
    row.style.display = text.includes(keyword) ? '' : 'none';
  });
}

async function viewXiuxianPlayer(qq) {
  try {
    const result = await window.api.xiuxianGetPlayerDetail(qq);
    if (result.success) {
      const p = result.data;
      console.log('[修仙管理-前端详情] 完整数据:', JSON.stringify(p));
      console.log('[修仙管理-前端详情] linggen字段:', JSON.stringify(p.linggen));
      console.log('[修仙管理-前端详情] 灵根字段:', JSON.stringify(p.灵根));
      let msg = '【玩家详情】\n\n';
      msg += 'QQ号: ' + p.qq + '\n';
      msg += '昵称: ' + (p.nickname || '未知') + '\n';
      msg += '境界: ' + (p.realm || '练气期') + ' ' + (p.realmLevel || 1) + '层\n';
      const linggenName = p.linggen?.name || p.linggen?.attribute || p.linggen?.灵根 || '';
      const linggenType = p.linggen?.type || p.linggen?.类型 || '未知';
      const linggenEff = p.linggen?.eff || p.linggen?.效率 || '';
      let linggenText = linggenType;
      if (linggenName) linggenText += ' - ' + linggenName;
      if (linggenEff) linggenText += ' (效率' + (linggenEff * 100).toFixed(0) + '%)';
      msg += '灵根: ' + linggenText + '\n';
      msg += '攻击: ' + (p.atk || 0) + '\n';
      msg += '防御: ' + (p.def || 0) + '\n';
      msg += '生命: ' + (p.hp || 0) + '/' + (p.maxHp || 0) + '\n';
      msg += '战力: ' + (p.power || 0) + '\n';
      msg += '灵石: ' + (p.gold || 0) + '\n';
      msg += '修为: ' + (p.exp || 0) + '\n';
      if (p.sect) msg += '宗门: ' + p.sect + '\n';
      if (p.pet) msg += '仙宠: ' + p.pet.name + '\n';
      if (p.occupation) msg += '职业: ' + p.occupation + '\n';
      if (p.spouse) msg += '配偶: ' + p.spouse.nickname + '\n';
      if (p.master) msg += '师父: ' + p.master.nickname + '\n';
      msg += '\n注册时间: ' + new Date(p.createTime || Date.now()).toLocaleString();
      showAlert(msg);
    } else {
      showError('获取玩家详情失败: ' + (result.error || '未知错误'));
    }
  } catch (e) {
    showError('获取玩家详情失败: ' + e.message);
  }
}

async function loadXiuxianConfig() {
  try {
    const result = await window.api.xiuxianGetConfig();
    if (result.success) {
      const c = result.data;
      document.getElementById('configRealms').innerHTML = c.realms.map(r => r.name + ' (' + r.maxLevel + '层)').join('<br>');
      document.getElementById('configLinggen').innerHTML = c.linggen.map(l => l.type + ' (' + (l.probability * 100).toFixed(0) + '%, ' + l.eff + 'x)').join('<br>');
      document.getElementById('configEquipments').innerHTML = '武器: ' + c.weapons + '件<br>防具: ' + c.armors + '件<br>法宝: ' + c.treasures + '件';
      document.getElementById('configPills').innerHTML = c.pills.map(p => p.name).join('<br>');
      document.getElementById('configMonsters').innerHTML = c.monsters.map(m => m.name + ' (Lv.' + m.level + ')').join('<br>');
      document.getElementById('configOccupations').innerHTML = c.occupations.map(o => o.name).join('<br>');
    }
  } catch (e) {
    console.error('加载修仙配置失败:', e);
  }
}

async function openXiuxianConfigFile() {
  try {
    await window.api.xiuxianOpenConfig();
  } catch (e) {
    showError('打开配置文件失败: ' + e.message);
  }
}

async function refreshXiuxianSects() {
  const listEl = document.getElementById('xiuxianSectList');
  listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">加载中...</div>';
  try {
    const result = await window.api.xiuxianGetSects();
    if (result.success && result.data.sects.length > 0) {
      let html = '';
      result.data.sects.forEach(s => {
        html += '<div style="padding:12px;background:rgba(255,255,255,0.03);border-radius:8px;margin-bottom:10px;">';
        html += '<div style="display:flex;justify-content:space-between;align-items:center;">';
        html += '<div style="font-weight:bold;font-size:15px;">' + s.name + '</div>';
        html += '<div style="font-size:12px;color:#aaa;">Lv.' + s.level + ' · ' + s.members.length + '人</div>';
        html += '</div>';
        html += '<div style="font-size:12px;color:#888;margin-top:5px;">宗主: ' + (s.founderName || '未知') + '</div>';
        if (s.announcement) html += '<div style="font-size:12px;color:#aaa;margin-top:5px;">公告: ' + s.announcement + '</div>';
        html += '<div style="margin-top:8px;display:flex;gap:6px;">';
        html += '<button class="btn btn-sm btn-primary sect-level" data-name="' + s.name + '">调等级</button>';
        html += '<button class="btn btn-sm btn-success sect-announce" data-name="' + s.name + '">改公告</button>';
        html += '<button class="btn btn-sm btn-danger sect-disband" data-name="' + s.name + '">解散</button>';
        html += '</div>';
        html += '</div>';
      });
      listEl.innerHTML = html;
      
      // 动态绑定宗门按钮事件
      setTimeout(() => {
        listEl.querySelectorAll('.sect-level').forEach(btn => {
          btn.addEventListener('click', () => updateXiuxianSectLevel(btn.dataset.name));
        });
        listEl.querySelectorAll('.sect-announce').forEach(btn => {
          btn.addEventListener('click', () => updateXiuxianSectAnnouncement(btn.dataset.name));
        });
        listEl.querySelectorAll('.sect-disband').forEach(btn => {
          btn.addEventListener('click', () => disbandXiuxianSect(btn.dataset.name));
        });
      }, 10);
    } else {
      listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">暂无宗门数据</div>';
    }
    refreshXiuxianStats();
  } catch (e) {
    listEl.innerHTML = '<div style="color:#f55;text-align:center;padding:30px;">加载失败: ' + e.message + '</div>';
  }
}

async function refreshXiuxianMarket() {
  const listEl = document.getElementById('xiuxianMarketList');
  listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">加载中...</div>';
  try {
    const result = await window.api.xiuxianGetMarket();
    if (result.success && result.data.items.length > 0) {
      let html = '<table style="width:100%;border-collapse:collapse;font-size:13px;">';
      html += '<thead><tr style="background:rgba(255,255,255,0.05);">';
      html += '<th style="padding:8px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.1);">物品</th>';
      html += '<th style="padding:8px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.1);">卖家</th>';
      html += '<th style="padding:8px;text-align:right;border-bottom:1px solid rgba(255,255,255,0.1);">价格</th>';
      html += '<th style="padding:8px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.1);">上架时间</th>';
      html += '<th style="padding:8px;text-align:center;border-bottom:1px solid rgba(255,255,255,0.1);">操作</th>';
      html += '</tr></thead><tbody>';
      
      result.data.items.forEach(item => {
        html += '<tr style="border-bottom:1px solid rgba(255,255,255,0.05);">';
        html += '<td style="padding:8px;">' + item.item.name + '</td>';
        html += '<td style="padding:8px;">' + (item.sellerName || '未知') + '</td>';
        html += '<td style="padding:8px;text-align:right;color:#4f9;">' + item.price.toLocaleString() + ' 灵石</td>';
        html += '<td style="padding:8px;font-size:11px;color:#888;">' + new Date(item.listTime).toLocaleString() + '</td>';
        html += '<td style="padding:8px;text-align:center;">';
        html += '<button class="btn btn-sm btn-danger market-remove" data-id="' + (item.id || item.itemId || item._id) + '">下架</button>';
        html += '</td>';
        html += '</tr>';
      });
      
      html += '</tbody></table>';
      listEl.innerHTML = html;
      
      // 动态绑定市场按钮事件
      setTimeout(() => {
        listEl.querySelectorAll('.market-remove').forEach(btn => {
          btn.addEventListener('click', () => removeXiuxianMarketItem(btn.dataset.id));
        });
      }, 10);
    } else {
      listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">暂无上架商品</div>';
    }
    refreshXiuxianStats();
  } catch (e) {
    listEl.innerHTML = '<div style="color:#f55;text-align:center;padding:30px;">加载失败: ' + e.message + '</div>';
  }
}

// 页面切换时自动加载修仙数据
document.addEventListener('DOMContentLoaded', () => {
  const xiuxianNav = document.querySelector('[data-page="xiuxian"]');
  if (xiuxianNav) {
    xiuxianNav.addEventListener('click', () => {
      setTimeout(() => {
        refreshXiuxianStats();
        refreshXiuxianPlayers();
      }, 100);
    });
  }
});

// ==================== 修仙高级管理功能 ====================

// 发送系统邮件
async function sendXiuxianMail() {
  const toQq = document.getElementById('mailToQq').value.trim();
  const title = document.getElementById('mailTitle').value.trim();
  const mailContent = document.getElementById('mailContent').value.trim();
  const rewardsStr = document.getElementById('mailRewards').value.trim();
  
  if (!toQq || !title || !mailContent) {
    showAlert('请填写完整的邮件信息');
    return;
  }
  
  let rewards = {};
  if (rewardsStr) {
    try { rewards = JSON.parse(rewardsStr); } catch (e) { showError('奖励格式错误，请使用JSON格式'); return; }
  }
  
  try {
    const result = await window.api.xiuxianSendMail(toQq, title, mailContent, rewards);
    if (result.success) {
      showSuccess('邮件发送成功！');
      document.getElementById('mailToQq').value = '';
      document.getElementById('mailTitle').value = '';
      document.getElementById('mailContent').value = '';
      document.getElementById('mailRewards').value = '';
    } else {
      showError('发送失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('发送失败: ' + e.message);
  }
}

// 发送全局公告
async function sendXiuxianGlobalMail() {
  const title = document.getElementById('globalMailTitle').value.trim();
  const mailContent = document.getElementById('globalMailContent').value.trim();
  const rewardsStr = document.getElementById('globalMailRewards').value.trim();
  
  if (!title || !mailContent) {
    showAlert('请填写完整的公告信息');
    return;
  }
  
  let rewards = {};
  if (rewardsStr) {
    try { rewards = JSON.parse(rewardsStr); } catch (e) { showError('奖励格式错误，请使用JSON格式'); return; }
  }
  
  try {
    const result = await window.api.xiuxianSendGlobalMail(title, mailContent, rewards);
    if (result.success) {
      showSuccess('全局公告发送成功！');
      document.getElementById('globalMailTitle').value = '';
      document.getElementById('globalMailContent').value = '';
      document.getElementById('globalMailRewards').value = '';
    } else {
      showError('发送失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('发送失败: ' + e.message);
  }
}

// 创建活动
async function createXiuxianActivity() {
  const name = document.getElementById('activityName').value.trim();
  const type = document.getElementById('activityType').value;
  const value = parseFloat(document.getElementById('activityValue').value);
  const startTime = new Date(document.getElementById('activityStartTime').value).getTime();
  const endTime = new Date(document.getElementById('activityEndTime').value).getTime();
  const description = document.getElementById('activityDesc').value.trim();
  
  if (!name || !startTime || !endTime) {
    showAlert('请填写完整的活动信息');
    return;
  }
  
  try {
    const result = await window.api.xiuxianCreateActivity(name, type, value, startTime, endTime, description);
    if (result.success) {
      showSuccess('活动创建成功！');
      refreshXiuxianActivities();
    } else {
      showError('创建失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('创建失败: ' + e.message);
  }
}

// 刷新活动列表
async function refreshXiuxianActivities() {
  const listEl = document.getElementById('xiuxianActivityList');
  if (!listEl) return;
  listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">加载中...</div>';
  
  try {
    const result = await window.api.xiuxianGetActivities();
    if (result.success && result.data.length > 0) {
      let html = '';
      result.data.forEach(a => {
        const now = Date.now();
        const isActive = a.enabled && now >= a.startTime && now <= a.endTime;
        const statusColor = isActive ? '#4f9' : '#888';
        const statusText = isActive ? '进行中' : (now > a.endTime ? '已结束' : '未开始');
        const typeNames = { exp: '修为加成', gold: '灵石加成', drop: '掉落加成', cultivate: '修炼效率加成' };
        
        html += '<div style="padding:12px;background:rgba(255,255,255,0.03);border-radius:8px;margin-bottom:10px;">';
        html += '<div style="display:flex;justify-content:space-between;align-items:center;">';
        html += '<div style="font-weight:bold;">' + a.name + '</div>';
        html += '<div style="font-size:12px;color:' + statusColor + ';">' + statusText + '</div>';
        html += '</div>';
        html += '<div style="font-size:12px;color:#aaa;margin-top:5px;">';
        html += '类型: ' + (typeNames[a.type] || a.type) + ' | 加成: ' + (a.value * 100).toFixed(0) + '%';
        html += '</div>';
        html += '<div style="font-size:11px;color:#888;margin-top:3px;">';
        html += new Date(a.startTime).toLocaleString() + ' ~ ' + new Date(a.endTime).toLocaleString();
        html += '</div>';
        if (a.description) html += '<div style="font-size:12px;color:#ccc;margin-top:5px;">' + a.description + '</div>';
        html += '<div style="margin-top:8px;display:flex;gap:8px;">';
        html += '<button class="btn btn-sm btn-danger activity-delete" data-id="' + a.id + '">删除</button>';
        html += '</div>';
        html += '</div>';
      });
      listEl.innerHTML = html;
      
      // 动态绑定活动按钮事件
      setTimeout(() => {
        listEl.querySelectorAll('.activity-delete').forEach(btn => {
          btn.addEventListener('click', () => deleteXiuxianActivity(btn.dataset.id));
        });
      }, 10);
    } else {
      listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">暂无活动</div>';
    }
  } catch (e) {
    listEl.innerHTML = '<div style="color:#f55;text-align:center;padding:30px;">加载失败: ' + e.message + '</div>';
  }
}

// 删除活动
async function deleteXiuxianActivity(activityId) {
  if (!await showConfirm('确定要删除这个活动吗？')) return;
  try {
    const result = await window.api.xiuxianDeleteActivity(activityId);
    if (result.success) {
      showAlert('活动已删除');
      refreshXiuxianActivities();
    } else {
      showError('删除失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('删除失败: ' + e.message);
  }
}

// 导出玩家数据
async function exportXiuxianPlayers() {
  const format = document.getElementById('exportFormat').value;
  try {
    const result = await window.api.xiuxianExportPlayers(format);
    if (result.success) {
      showSuccess('导出成功！\n共导出 ' + result.count + ' 条玩家数据\n文件已保存到桌面: ' + result.path);
    } else {
      showError('导出失败: ' + (result.error || '未知错误'));
    }
  } catch (e) {
    showError('导出失败: ' + e.message);
  }
}

// 封禁玩家
async function banXiuxianPlayer(qq) {
  const reason = await showInputDialog('封禁玩家', '请输入封禁原因（可选）:', '') || '';
  if (reason === null) return;
  const durationStr = await showInputDialog('封禁天数', '请输入封禁天数（0=永久封禁）:', '0');
  if (durationStr === null) return;
  const duration = parseInt(durationStr) || 0;
  
  try {
    const result = await window.api.xiuxianBanPlayer(qq, reason, duration);
    if (result.success) {
      showAlert('玩家已封禁');
      refreshXiuxianPlayers();
    } else {
      showError('封禁失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('封禁失败: ' + e.message);
  }
}

// 解封玩家
async function unbanXiuxianPlayer(qq) {
  try {
    const result = await window.api.xiuxianUnbanPlayer(qq);
    if (result.success) {
      showAlert('玩家已解封');
      refreshXiuxianPlayers();
    } else {
      showError('解封失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('解封失败: ' + e.message);
  }
}

// 增加玩家灵石
async function addXiuxianGold(qq) {
  const input = await showInputDialog('调整灵石', '请输入增加的灵石数量（负数为扣除）:', '100');
  if (input === null) return;
  const amount = parseInt(input);
  if (isNaN(amount)) { showAlert('请输入有效的数字'); return; }
  try {
    const result = await window.api.xiuxianAddGold(qq, amount);
    if (result.success) {
      showAlert('灵石已调整，当前余额: ' + result.newBalance);
      refreshXiuxianPlayers();
    } else {
      showError('操作失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('操作失败: ' + e.message);
  }
}

// 增加玩家修为
async function addXiuxianExp(qq) {
  const input = await showInputDialog('调整修为', '请输入增加的修为数量（负数为扣除）:', '1000');
  if (input === null) return;
  const amount = parseInt(input);
  if (isNaN(amount)) { showAlert('请输入有效的数字'); return; }
  try {
    const result = await window.api.xiuxianAddExp(qq, amount);
    if (result.success) {
      showAlert('修为已调整，当前修为: ' + result.newExp);
      refreshXiuxianPlayers();
    } else {
      showError('操作失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('操作失败: ' + e.message);
  }
}


// 将修仙管理函数绑定到window全局作用域，确保HTML onclick可以调用
// 核心Tab切换和数据加载
window.showXiuxianTab = showXiuxianTab;
window.refreshXiuxianStats = refreshXiuxianStats;
window.refreshXiuxianPlayers = refreshXiuxianPlayers;
window.refreshXiuxianSects = refreshXiuxianSects;
window.refreshXiuxianMarket = refreshXiuxianMarket;
window.refreshXiuxianActivities = refreshXiuxianActivities;
window.loadXiuxianConfig = loadXiuxianConfig;
window.openXiuxianConfigFile = openXiuxianConfigFile;
window.searchXiuxianPlayers = searchXiuxianPlayers;
window.viewXiuxianPlayer = viewXiuxianPlayer;

// 玩家管理操作
window.addXiuxianGold = addXiuxianGold;
window.addXiuxianExp = addXiuxianExp;
window.banXiuxianPlayer = banXiuxianPlayer;
window.unbanXiuxianPlayer = unbanXiuxianPlayer;

// 邮件公告
window.sendXiuxianMail = sendXiuxianMail;
window.sendXiuxianGlobalMail = sendXiuxianGlobalMail;

// 宗门管理
window.disbandXiuxianSect = disbandXiuxianSect;
window.updateXiuxianSectLevel = updateXiuxianSectLevel;
window.updateXiuxianSectAnnouncement = updateXiuxianSectAnnouncement;

// 市场管理
window.removeXiuxianMarketItem = removeXiuxianMarketItem;

// 活动管理
window.createXiuxianActivity = createXiuxianActivity;
window.deleteXiuxianActivity = deleteXiuxianActivity;

// 数据导出
window.exportXiuxianPlayers = exportXiuxianPlayers;

// 调整宗门等级
async function updateXiuxianSectLevel(sectName) {
  const input = await showInputDialog('调整宗门等级', '请输入新的宗门等级（1-5）:', '1');
  if (input === null) return;
  const level = parseInt(input);
  if (isNaN(level) || level < 1 || level > 5) {
    showAlert('等级必须在1-5之间');
    return;
  }
  try {
    const result = await window.api.xiuxianUpdateSectLevel(sectName, level);
    if (result.success) {
      showAlert('宗门等级已调整为 Lv.' + level);
      refreshXiuxianSects();
    } else {
      showError('操作失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('操作失败: ' + e.message);
  }
}

// 修改宗门公告
async function updateXiuxianSectAnnouncement(sectName) {
  const announcement = await showInputDialog('修改宗门公告', '请输入新的宗门公告:', '');
  if (announcement === null) return;
  try {
    const result = await window.api.xiuxianUpdateSectAnnouncement(sectName, announcement);
    if (result.success) {
      showAlert('宗门公告已更新');
      refreshXiuxianSects();
    } else {
      showError('操作失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('操作失败: ' + e.message);
  }
}

// 解散宗门
async function disbandXiuxianSect(sectName) {
  const confirmed = await showConfirmDialog('解散宗门', '确定要解散宗门「' + sectName + '」吗？所有成员将被移出宗门！');
  if (!confirmed) return;
  try {
    const result = await window.api.xiuxianDisbandSect(sectName);
    if (result.success) {
      showAlert('宗门已解散');
      refreshXiuxianSects();
    } else {
      showError('操作失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('操作失败: ' + e.message);
  }
}

// 下架商品
async function removeXiuxianMarketItem(itemId) {
  const confirmed = await showConfirmDialog('下架商品', '确定要下架这个商品吗？物品将退还给卖家！');
  if (!confirmed) return;
  try {
    const result = await window.api.xiuxianRemoveMarketItem(itemId);
    if (result.success) {
      showAlert('商品已下架');
      refreshXiuxianMarket();
    } else {
      showError('操作失败: ' + (result.message || result.error));
    }
  } catch (e) {
    showError('操作失败: ' + e.message);
  }
}

// showXiuxianTab函数已经包含了所有Tab的自动加载逻辑，无需重写





// ==================== 修仙管理按钮全局事件委托（修复版） ====================
(function() {
  
  // 修仙管理函数映射表（精确匹配）
  const xiuxianActions = {
    'refreshXiuxianStats()': function() { if (typeof refreshXiuxianStats === 'function') refreshXiuxianStats(); },
    'refreshXiuxianPlayers()': function() { if (typeof refreshXiuxianPlayers === 'function') refreshXiuxianPlayers(); },
    'searchXiuxianPlayers()': function() { if (typeof searchXiuxianPlayers === 'function') searchXiuxianPlayers(); },
    'loadXiuxianConfig()': function() { if (typeof loadXiuxianConfig === 'function') loadXiuxianConfig(); },
    'openXiuxianConfigFile()': function() { if (typeof openXiuxianConfigFile === 'function') openXiuxianConfigFile(); },
    'refreshXiuxianSects()': function() { if (typeof refreshXiuxianSects === 'function') refreshXiuxianSects(); },
    'refreshXiuxianMarket()': function() { if (typeof refreshXiuxianMarket === 'function') refreshXiuxianMarket(); },
    'sendXiuxianMail()': function() { if (typeof sendXiuxianMail === 'function') sendXiuxianMail(); },
    'sendXiuxianGlobalMail()': function() { if (typeof sendXiuxianGlobalMail === 'function') sendXiuxianGlobalMail(); },
    'createXiuxianActivity()': function() { if (typeof createXiuxianActivity === 'function') createXiuxianActivity(); },
    'refreshXiuxianActivities()': function() { if (typeof refreshXiuxianActivities === 'function') refreshXiuxianActivities(); },
    'exportXiuxianPlayers()': function() { if (typeof exportXiuxianPlayers === 'function') exportXiuxianPlayers(); },
  };
  
  // Tab切换函数（带参数）
  const tabActions = {
    'players': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('players'); },
    'config': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('config'); },
    'sects': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('sects'); },
    'market': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('market'); },
    'mail': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('mail'); },
    'activity': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('activity'); },
    'items': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('items'); },
    'advanced': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('advanced'); },
    'timelimit': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('timelimit'); },
    'stats': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('stats'); },
    'logs': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('logs'); },
    'backup': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('backup'); },
    'export': function() { if (typeof showXiuxianTab === 'function') showXiuxianTab('export'); },
  };
  
  // 全局点击事件委托（捕获阶段）
  document.addEventListener('click', function(e) {
    try {
      // 找到点击的按钮
      const btn = e.target.closest('button');
      if (!btn) return;
      
      // 获取按钮的onclick属性
      const onclick = btn.getAttribute('onclick');
      if (!onclick) return;
      
      const trimmedOnclick = onclick.trim();
      
      // 1. 精确匹配映射表
      if (xiuxianActions[trimmedOnclick]) {
        e.preventDefault();
        e.stopPropagation();
        xiuxianActions[trimmedOnclick]();
        return;
      }
      
      // 2. 匹配Tab切换函数 showXiuxianTab('xxx')
      const tabMatch = trimmedOnclick.match(/^showXiuxianTab\(['"]([^'"]+)['"]\)$/);
      if (tabMatch && tabActions[tabMatch[1]]) {
        e.preventDefault();
        e.stopPropagation();
        tabActions[tabMatch[1]]();
        return;
      }
      
      // 3. 匹配玩家管理函数（带QQ号参数）
      const playerFuncMatch = trimmedOnclick.match(/^(viewXiuxianPlayer|addXiuxianGold|addXiuxianExp|banXiuxianPlayer|unbanXiuxianPlayer)\(['"]([^'"]+)['"]\)$/);
      if (playerFuncMatch) {
        e.preventDefault();
        e.stopPropagation();
        const funcName = playerFuncMatch[1];
        const qq = playerFuncMatch[2];
        if (typeof window[funcName] === 'function') {
          window[funcName](qq);
        } else {
          console.error('[修仙管理] 函数不存在:', funcName);
        }
        return;
      }
      
      // 4. 匹配其他修仙管理函数（带参数）
      const otherFuncMatch = trimmedOnclick.match(/^(disbandXiuxianSect|updateXiuxianSectLevel|updateXiuxianSectAnnouncement|removeXiuxianMarketItem|deleteXiuxianActivity)\(['"]([^'"]+)['"]\)$/);
      if (otherFuncMatch) {
        e.preventDefault();
        e.stopPropagation();
        const funcName = otherFuncMatch[1];
        const param = otherFuncMatch[2];
        console.log('[修仙管理] 其他操作:', funcName, param);
        if (typeof window[funcName] === 'function') {
          window[funcName](param);
        } else {
          console.error('[修仙管理] 函数不存在:', funcName);
        }
        return;
      }
      
      // 5. 通用匹配：如果函数存在于window中，直接执行
      const genericMatch = trimmedOnclick.match(/^([a-zA-Z_$][a-zA-Z0-9_$]*)((.*))$/);
      if (genericMatch) {
        const funcName = genericMatch[1];
        const argsStr = genericMatch[2];
        if (typeof window[funcName] === 'function') {
          e.preventDefault();
          e.stopPropagation();
          console.log('[修仙管理] 通用匹配，执行函数:', funcName, argsStr);
          try {
            // 解析参数（支持字符串参数）
            const args = [];
            if (argsStr.trim()) {
              // 简单的参数解析：支持字符串和数字
              const argParts = argsStr.match(/'([^']*)'|"([^"]*)"|(d+)/g);
              if (argParts) {
                argParts.forEach(arg => {
                  if (arg.startsWith("'") || arg.startsWith('"')) {
                    args.push(arg.slice(1, -1));
                  } else {
                    args.push(parseInt(arg));
                  }
                });
              }
            }
            window[funcName].apply(null, args);
          } catch (execErr) {
            console.error('[修仙管理] 函数执行出错:', execErr);
          }
          return;
        }
      }
      
    } catch (err) {
      console.error('[修仙管理] 事件处理出错:', err);
    }
  }, true); // 使用捕获阶段，确保在onclick之前执行
  
  console.log('[修仙管理] 全局事件委托初始化完成');
})();


// ========== 物品装备管理 ==========
async function loadXiuxianItems(type) {
  const listEl = document.getElementById('xiuxianItemsList');
  listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">加载中...</div>';
  try {
    const result = await window.api.xiuxianGetItems(type);
    if (result.success && result.data && result.data.items) {
      const items = result.data.items;
      if (items.length === 0) {
        listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">暂无数据</div>';
        return;
      }
      let html = '<div style="font-size:13px;color:#aaa;margin-bottom:10px;">共 ' + items.length + ' 项</div>';
      html += '<table style="width:100%;border-collapse:collapse;font-size:12px;">';
      html += '<thead><tr style="background:rgba(255,255,255,0.05);">';
      html += '<th style="padding:8px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.1);">名称</th>';
      html += '<th style="padding:8px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.1);">类型/品级</th>';
      html += '<th style="padding:8px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.1);">效果/描述</th>';
      html += '<th style="padding:8px;text-align:right;border-bottom:1px solid rgba(255,255,255,0.1);">价格/等级</th>';
      html += '</tr></thead><tbody>';
      items.forEach(item => {
        html += '<tr style="border-bottom:1px solid rgba(255,255,255,0.03);">';
        html += '<td style="padding:8px;font-weight:bold;">' + (item.name || item.名称 || '未知') + '</td>';
        const typeInfo = (item.type || item.品级 || item.grade || '') + (item.level ? ' Lv.' + item.level : '');
        html += '<td style="padding:8px;color:#aaa;">' + typeInfo + '</td>';
        html += '<td style="padding:8px;color:#888;">' + (item.effect || item.desc || item.描述 || item.效果 || '-') + '</td>';
        html += '<td style="padding:8px;text-align:right;color:#ffd700;">' + (item.price || item.价格 || '-') + '</td>';
        html += '</tr>';
      });
      html += '</tbody></table>';
      listEl.innerHTML = html;
    } else {
      listEl.innerHTML = '<div style="color:#ff6b6b;text-align:center;padding:30px;">加载失败: ' + (result.error || '未知错误') + '</div>';
    }
  } catch (e) {
    listEl.innerHTML = '<div style="color:#ff6b6b;text-align:center;padding:30px;">加载失败: ' + e.message + '</div>';
  }
}

// ========== 高级系统管理 ==========
async function loadAdvancedSystem(type) {
  const contentEl = document.getElementById('xiuxianAdvancedContent');
  contentEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">加载中...</div>';
  try {
    const result = await window.api.xiuxianGetAdvancedData(type);
    if (result.success && result.data) {
      const data = result.data;
      let html = '';
      
      // 统计卡片
      if (data.stats) {
        html += '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px;">';
        Object.keys(data.stats).forEach(key => {
          html += '<div style="padding:12px;background:rgba(255,255,255,0.03);border-radius:8px;text-align:center;">';
          html += '<div style="font-size:12px;color:#888;">' + key + '</div>';
          html += '<div style="font-size:24px;font-weight:bold;color:#4facfe;">' + data.stats[key] + '</div>';
          html += '</div>';
        });
        html += '</div>';
      }
      
      // 列表数据
      if (data.list && data.list.length > 0) {
        html += '<div style="font-size:13px;color:#aaa;margin-bottom:10px;">共 ' + data.list.length + ' 条记录</div>';
        html += '<div style="max-height:400px;overflow-y:auto;">';
        html += '<table style="width:100%;border-collapse:collapse;font-size:12px;">';
        html += '<thead><tr style="background:rgba(255,255,255,0.05);position:sticky;top:0;">';
        if (data.list[0]) {
          Object.keys(data.list[0]).forEach(key => {
            html += '<th style="padding:8px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.1);">' + key + '</th>';
          });
        }
        html += '</tr></thead><tbody>';
        data.list.forEach(item => {
          html += '<tr style="border-bottom:1px solid rgba(255,255,255,0.03);">';
          Object.values(item).forEach(val => {
            html += '<td style="padding:8px;">' + (typeof val === 'object' ? JSON.stringify(val) : val) + '</td>';
          });
          html += '</tr>';
        });
        html += '</tbody></table>';
        html += '</div>';
      } else if (data.info) {
        html += '<div style="padding:20px;background:rgba(255,255,255,0.03);border-radius:8px;">';
        html += '<pre style="font-size:12px;color:#aaa;white-space:pre-wrap;">' + JSON.stringify(data.info, null, 2) + '</pre>';
        html += '</div>';
      }
      
      contentEl.innerHTML = html;
    } else {
      contentEl.innerHTML = '<div style="color:#ff6b6b;text-align:center;padding:30px;">加载失败: ' + (result.error || '未知错误') + '</div>';
    }
  } catch (e) {
    contentEl.innerHTML = '<div style="color:#ff6b6b;text-align:center;padding:30px;">加载失败: ' + e.message + '</div>';
  }
}

// ========== 限时活动管理 ==========
async function loadTimelimitItems(type) {
  const listEl = document.getElementById('xiuxianTimelimitList');
  listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">加载中...</div>';
  try {
    const result = await window.api.xiuxianGetTimelimitItems(type);
    if (result.success && result.data && result.data.items) {
      const items = result.data.items;
      if (items.length === 0) {
        listEl.innerHTML = '<div style="color:#888;text-align:center;padding:30px;">暂无数据</div>';
        return;
      }
      let html = '<div style="font-size:13px;color:#aaa;margin-bottom:10px;">共 ' + items.length + ' 项限时物品</div>';
      html += '<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;">';
      items.forEach(item => {
        html += '<div style="padding:15px;background:rgba(255,255,255,0.03);border-radius:8px;border-left:3px solid #f093fb;">';
        html += '<div style="font-weight:bold;font-size:14px;margin-bottom:5px;">' + (item.name || item.名称 || '未知') + '</div>';
        if (item.type || item.品级) html += '<div style="font-size:12px;color:#aaa;margin-bottom:5px;">类型: ' + (item.type || item.品级 || '-') + '</div>';
        if (item.effect || item.desc || item.效果 || item.描述) {
          html += '<div style="font-size:12px;color:#888;margin-bottom:5px;">效果: ' + (item.effect || item.desc || item.效果 || item.描述 || '-') + '</div>';
        }
        if (item.price || item.价格) html += '<div style="font-size:12px;color:#ffd700;">价格: ' + (item.price || item.价格) + '</div>';
        html += '</div>';
      });
      html += '</div>';
      listEl.innerHTML = html;
    } else {
      listEl.innerHTML = '<div style="color:#ff6b6b;text-align:center;padding:30px;">加载失败: ' + (result.error || '未知错误') + '</div>';
    }
  } catch (e) {
    listEl.innerHTML = '<div style="color:#ff6b6b;text-align:center;padding:30px;">加载失败: ' + e.message + '</div>';
  }
}


// ========== 玩家详情管理 ==========
let currentDetailQq = null;
let currentDetailData = null;

async function viewXiuxianPlayer(qq) {
  currentDetailQq = qq;
  try {
    const result = await window.api.xiuxianGetPlayerDetail(qq);
    if (result.success && result.data) {
      currentDetailData = result.data;
      openPlayerDetail(result.data);
    } else {
      showError('获取玩家详情失败: ' + (result.error || '未知错误'));
    }
  } catch (e) {
    showError('获取玩家详情失败: ' + e.message);
  }
}

function openPlayerDetail(p) {
  // 填充基本信息
  document.getElementById('detailQq').textContent = p.qq || '-';
  document.getElementById('detailNickname').textContent = p.nickname || p.名号 || '-';
  document.getElementById('detailRealm').textContent = (p.realm || '练气期') + ' ' + (p.realmLevel || 1) + '层';
  
  // 灵根
  let linggenText = '未知';
  if (p.linggen && p.linggen.name) {
    linggenText = p.linggen.type + ' - ' + p.linggen.name;
    if (p.linggen.eff) linggenText += ' (' + (p.linggen.eff * 100).toFixed(0) + '%)';
  }
  document.getElementById('detailLinggen').textContent = linggenText;
  
  // 职业
  document.getElementById('detailOccupation').textContent = p.occupation || '散修';
  
  // 状态
  const statusEl = document.getElementById('detailStatus');
  if (p.banned) {
    statusEl.textContent = '已封禁';
    statusEl.style.color = '#ff6b6b';
    document.getElementById('detailBanBtn').textContent = '解除封禁';
    document.getElementById('detailBanBtn').className = 'btn btn-success btn-sm';
  } else {
    statusEl.textContent = '正常';
    statusEl.style.color = '#43e97b';
    document.getElementById('detailBanBtn').textContent = '封禁玩家';
    document.getElementById('detailBanBtn').className = 'btn btn-warning btn-sm';
  }
  
  // 填充属性输入框
  document.getElementById('adjustAtk').value = p.atk || p.攻击 || 0;
  document.getElementById('adjustDef').value = p.def || p.防御 || 0;
  document.getElementById('adjustMaxHp').value = p.maxHp || p.血量上限 || p.生命 || 100;
  document.getElementById('adjustHp').value = p.hp || p.当前血量 || 100;
  document.getElementById('adjustGold').value = p.gold || p.灵石 || 0;
  document.getElementById('adjustExp').value = p.exp || p.修为 || 0;
  document.getElementById('adjustRealmId').value = p.realmId || p.level_id || 1;
  document.getElementById('adjustLunhui').value = p.轮回点 || p.lunhuiPoint || 0;
  
  // 显示模态框
  document.getElementById('playerDetailModal').style.display = 'flex';
  
  // 默认显示背包
  showPlayerTab('inventory');
}

function closePlayerDetail() {
  document.getElementById('playerDetailModal').style.display = 'none';
  currentDetailQq = null;
  currentDetailData = null;
}

function showPlayerTab(tab) {
  // 更新按钮样式
  document.querySelectorAll('#playerDetailModal .btn').forEach(btn => {
    if (btn.textContent === '背包' || btn.textContent === '装备' || btn.textContent === '仙宠') {
      btn.className = 'btn btn-sm btn-ghost';
    }
  });
  event.target.className = 'btn btn-sm btn-primary';
  
  const contentEl = document.getElementById('playerTabContent');
  const p = currentDetailData;
  
  if (tab === 'inventory') {
    const inventory = p.纳戒 || p.inventory || {};
    let html = '<div style="font-weight:bold;margin-bottom:10px;color:#fff;">背包（纳戒等级 ' + (inventory.等级 || 1) + '）</div>';
    const categories = ['道具', '丹药', '功法', '武器', '护具', '法宝', '材料', '草药', '装备', '仙宠口粮'];
    categories.forEach(cat => {
      const items = inventory[cat] || [];
      if (items.length > 0) {
        html += '<div style="margin-bottom:8px;"><span style="color:#4facfe;font-weight:bold;">' + cat + '：</span>';
        html += items.map(item => {
          if (typeof item === 'string') return item;
          return (item.name || item.名称 || '未知') + (item.count ? ' x' + item.count : '');
        }).join('、');
        html += '</div>';
      }
    });
    if (categories.every(cat => !(inventory[cat] || []).length)) {
      html += '<div style="color:#888;">背包为空</div>';
    }
    contentEl.innerHTML = html;
  } else if (tab === 'equipment') {
    const equipment = p.装备 || p.equipment || {};
    let html = '<div style="font-weight:bold;margin-bottom:10px;color:#fff;">当前装备</div>';
    const slots = ['武器', '护具', '法宝'];
    slots.forEach(slot => {
      const item = equipment[slot];
      html += '<div style="padding:8px;background:rgba(255,255,255,0.03);border-radius:6px;margin-bottom:6px;">';
      html += '<span style="color:#aaa;">' + slot + '：</span>';
      if (item) {
        html += '<span style="color:#ffd700;font-weight:bold;">' + (item.name || item.名称 || '未知') + '</span>';
        if (item.level) html += ' <span style="color:#888;">Lv.' + item.level + '</span>';
      } else {
        html += '<span style="color:#666;">未装备</span>';
      }
      html += '</div>';
    });
    contentEl.innerHTML = html;
  } else if (tab === 'pet') {
    const pet = p.仙宠 || p.pet;
    let html = '<div style="font-weight:bold;margin-bottom:10px;color:#fff;">仙宠</div>';
    if (pet && pet.name) {
      html += '<div style="padding:12px;background:rgba(255,255,255,0.03);border-radius:8px;">';
      html += '<div style="font-size:16px;font-weight:bold;color:#f093fb;">' + pet.name + '</div>';
      if (pet.type) html += '<div style="color:#aaa;margin-top:4px;">类型：' + pet.type + '</div>';
      if (pet.level) html += '<div style="color:#aaa;margin-top:4px;">等级：' + pet.level + '</div>';
      if (pet.attack) html += '<div style="color:#aaa;margin-top:4px;">攻击：' + pet.attack + '</div>';
      if (pet.defense) html += '<div style="color:#aaa;margin-top:4px;">防御：' + pet.defense + '</div>';
      html += '</div>';
    } else {
      html += '<div style="color:#888;">暂无仙宠，发送"捕捉仙宠"可以捕捉</div>';
    }
    contentEl.innerHTML = html;
  }
}

function resetPlayerAttributes() {
  if (currentDetailData) {
    openPlayerDetail(currentDetailData);
  }
}

async function savePlayerAttributes() {
  if (!currentDetailQq) return;
  const updates = {
    atk: parseInt(document.getElementById('adjustAtk').value) || 0,
    def: parseInt(document.getElementById('adjustDef').value) || 0,
    maxHp: parseInt(document.getElementById('adjustMaxHp').value) || 100,
    hp: parseInt(document.getElementById('adjustHp').value) || 100,
    gold: parseInt(document.getElementById('adjustGold').value) || 0,
    exp: parseInt(document.getElementById('adjustExp').value) || 0,
    realmId: parseInt(document.getElementById('adjustRealmId').value) || 1,
    lunhuiPoint: parseInt(document.getElementById('adjustLunhui').value) || 0,
  };
  try {
    const result = await window.api.xiuxianUpdatePlayerAttributes(currentDetailQq, updates);
    if (result.success) {
      showSuccess('属性保存成功！');
      viewXiuxianPlayer(currentDetailQq); // 重新加载
    } else {
      showError('保存失败: ' + (result.error || '未知错误'));
    }
  } catch (e) {
    showError('保存失败: ' + e.message);
  }
}

async function resetPlayerData() {
  if (!currentDetailQq) return;
  if (!await showConfirm('确定要重置该玩家的所有数据吗？此操作不可恢复！')) return;
  try {
    const result = await window.api.xiuxianResetPlayer(currentDetailQq);
    if (result.success) {
      showAlert('玩家数据已重置！');
      closePlayerDetail();
      refreshXiuxianPlayers();
    } else {
      showError('重置失败: ' + (result.error || '未知错误'));
    }
  } catch (e) {
    showError('重置失败: ' + e.message);
  }
}

async function togglePlayerBan() {
  if (!currentDetailQq) return;
  const isBanned = currentDetailData && currentDetailData.banned;
  try {
    let result;
    if (isBanned) {
      result = await window.api.xiuxianUnbanPlayer(currentDetailQq);
    } else {
      const reason = await showPrompt('请输入封禁原因：') || '管理员封禁';
      result = await window.api.xiuxianBanPlayer(currentDetailQq, reason, 0);
    }
    if (result.success) {
      showAlert(isBanned ? '已解除封禁！' : '已封禁玩家！');
      viewXiuxianPlayer(currentDetailQq);
      refreshXiuxianPlayers();
    } else {
      showError('操作失败: ' + (result.error || '未知错误'));
    }
  } catch (e) {
    showError('操作失败: ' + e.message);
  }
}


// ========== 配置管理增强 ==========
async function showConfigEditor() {
  try {
    const result = await window.api.xiuxianGetConfigRaw();
    if (result.success) {
      document.getElementById('configJsonEditor').value = result.data;
      document.getElementById('configOverview').style.display = 'none';
      document.getElementById('configEditor').style.display = 'block';
    } else {
      showError('加载配置失败: ' + (result.error || '未知错误'));
    }
  } catch (e) {
    showError('加载配置失败: ' + e.message);
  }
}

function hideConfigEditor() {
  document.getElementById('configOverview').style.display = 'block';
  document.getElementById('configEditor').style.display = 'none';
}

async function saveConfigJson() {
  const json = document.getElementById('configJsonEditor').value;
  try {
    JSON.parse(json); // 验证JSON格式
  } catch (e) {
    showError('JSON格式错误: ' + e.message);
    return;
  }
  if (!await showConfirm('确定要保存配置吗？原配置会自动备份。')) return;
  try {
    const result = await window.api.xiuxianSaveConfig(json);
    if (result.success) {
      showSuccess('配置保存成功！');
      hideConfigEditor();
      loadXiuxianConfig();
    } else {
      showError('保存失败: ' + (result.error || '未知错误'));
    }
  } catch (e) {
    showError('保存失败: ' + e.message);
  }
}

// 重写loadXiuxianConfig，添加更多配置展示
const originalLoadConfig = loadXiuxianConfig;
async function loadXiuxianConfig() {
  try {
    const result = await window.api.xiuxianGetConfig();
    if (result.success && result.data) {
      const c = result.data;
      document.getElementById('configRealms').innerHTML = c.realms.map(r => r.name + ' (' + r.maxLevel + '层)').join('<br>');
      document.getElementById('configLinggen').innerHTML = c.linggen.map(l => l.type + ' (' + (l.probability * 100).toFixed(0) + '%, ' + l.eff + 'x)').join('<br>');
      document.getElementById('configEquipments').innerHTML = '武器: ' + c.weapons + '件<br>防具: ' + c.armors + '件<br>法宝: ' + c.treasures + '件';
      document.getElementById('configPills').innerHTML = c.pills.map(p => p.name).join('<br>');
      document.getElementById('configMonsters').innerHTML = c.monsters.map(m => m.name + ' (Lv.' + m.level + ')').join('<br>');
      document.getElementById('configOccupations').innerHTML = c.occupations.map(o => o.name).join('<br>');
      
      // 额外配置（从原始配置获取）
      try {
        const rawResult = await window.api.xiuxianGetConfigRaw();
        if (rawResult.success) {
          const raw = JSON.parse(rawResult.data);
          document.getElementById('configSignin').innerHTML = (raw.签到奖励 || '默认签到奖励').toString().substring(0, 100);
          document.getElementById('configCultivate').innerHTML = '基础效率: ' + (raw.修炼配置?.基础效率 || '1.0') + '<br>突破成功率: ' + (raw.修炼配置?.突破成功率 || '默认');
          document.getElementById('configBattle').innerHTML = '暴击率: ' + (raw.战斗配置?.暴击率 || '0.05') + '<br>暴击伤害: ' + (raw.战斗配置?.暴击伤害 || '1.5x');
          document.getElementById('configShop').innerHTML = '商店物品数: ' + ((raw.商店配置?.物品列表 || []).length || '默认');
        }
      } catch (e) {}
    }
  } catch (e) {
    console.error('加载配置失败:', e);
  }
}

// ========== 宗门管理增强 ==========
async function viewSectMembers(sectName) {
  try {
    const result = await window.api.xiuxianGetSectMembers(sectName);
    if (result.success) {
      const members = result.data.members;
      let html = '<div style="padding:15px;background:rgba(255,255,255,0.03);border-radius:8px;margin-top:10px;">';
      html += '<div style="font-weight:bold;margin-bottom:10px;">' + sectName + ' - 成员列表（' + members.length + '人）</div>';
      if (members.length === 0) {
        html += '<div style="color:#888;">暂无成员</div>';
      } else {
        html += '<table style="width:100%;border-collapse:collapse;font-size:12px;">';
        html += '<thead><tr style="background:rgba(255,255,255,0.05);"><th style="padding:6px;text-align:left;">QQ号</th><th style="padding:6px;text-align:left;">昵称</th><th style="padding:6px;text-align:left;">职位</th><th style="padding:6px;text-align:right;">贡献</th><th style="padding:6px;text-align:center;">操作</th></tr></thead><tbody>';
        members.forEach(m => {
          html += '<tr style="border-bottom:1px solid rgba(255,255,255,0.03);">';
          html += '<td style="padding:6px;">' + m.qq + '</td>';
          html += '<td style="padding:6px;">' + m.nickname + '</td>';
          html += '<td style="padding:6px;color:#4facfe;">' + m.role + '</td>';
          html += '<td style="padding:6px;text-align:right;">' + m.contribution + '</td>';
          html += '<td style="padding:6px;text-align:center;"><button class="btn btn-danger btn-sm" onclick="removeSectMember(\'' + m.qq + '\', \'' + sectName + '\')">移出</button></td>';
          html += '</tr>';
        });
        html += '</tbody></table>';
      }
      html += '</div>';
      
      // 插入到对应宗门卡片后面
      const sectCards = document.querySelectorAll('#xiuxianSectList > div');
      sectCards.forEach(card => {
        if (card.textContent.includes(sectName)) {
          // 移除旧的成员列表
          const oldMembers = card.nextElementSibling;
          if (oldMembers && oldMembers.id === 'members-' + sectName) {
            oldMembers.remove();
          }
          const div = document.createElement('div');
          div.id = 'members-' + sectName;
          div.innerHTML = html;
          card.after(div);
        }
      });
    }
  } catch (e) {
    showError('获取宗门成员失败: ' + e.message);
  }
}

async function removeSectMember(qq, sectName) {
  if (!await showConfirm('确定要将该玩家移出宗门吗？')) return;
  try {
    const result = await window.api.xiuxianRemoveSectMember(qq);
    if (result.success) {
      showAlert('已移出宗门！');
      viewSectMembers(sectName);
      refreshXiuxianSects();
    } else {
      showError('操作失败: ' + (result.error || '未知错误'));
    }
  } catch (e) {
    showError('操作失败: ' + e.message);
  }
}

// ========== 操作日志 ==========
async function loadOperationLogs() {
  try {
    const result = await window.api.xiuxianGetOperationLogs(100);
    if (result.success) {
      const logs = result.data.logs;
      let html = '<table style="width:100%;border-collapse:collapse;font-size:12px;">';
      html += '<thead><tr style="background:rgba(255,255,255,0.05);"><th style="padding:8px;text-align:left;">时间</th><th style="padding:8px;text-align:left;">操作</th><th style="padding:8px;text-align:left;">详情</th><th style="padding:8px;text-align:left;">管理员</th></tr></thead><tbody>';
      logs.forEach(log => {
        html += '<tr style="border-bottom:1px solid rgba(255,255,255,0.03);">';
        html += '<td style="padding:8px;color:#888;">' + new Date(log.time).toLocaleString() + '</td>';
        html += '<td style="padding:8px;font-weight:bold;color:#4facfe;">' + log.action + '</td>';
        html += '<td style="padding:8px;color:#aaa;">' + log.detail + '</td>';
        html += '<td style="padding:8px;color:#888;">' + log.admin + '</td>';
        html += '</tr>';
      });
      html += '</tbody></table>';
      document.getElementById('operationLogsList').innerHTML = html;
    }
  } catch (e) {
    document.getElementById('operationLogsList').innerHTML = '<div style="color:#ff6b6b;">加载失败: ' + e.message + '</div>';
  }
}

// ========== 数据备份 ==========
async function backupData() {
  if (!await showConfirm('确定要备份所有修仙数据吗？')) return;
  try {
    const result = await window.api.xiuxianBackupData();
    if (result.success) {
      showSuccess('备份成功！备份路径: ' + result.data.backupPath);
      loadBackups();
    } else {
      showError('备份失败: ' + (result.error || '未知错误'));
    }
  } catch (e) {
    showError('备份失败: ' + e.message);
  }
}

async function loadBackups() {
  try {
    const result = await window.api.xiuxianGetBackups();
    if (result.success) {
      const backups = result.data.backups;
      let html = '';
      if (backups.length === 0) {
        html = '<div style="color:#888;text-align:center;padding:20px;">暂无备份</div>';
      } else {
        backups.forEach(b => {
          html += '<div style="padding:12px;background:rgba(255,255,255,0.03);border-radius:8px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;">';
          html += '<div><div style="font-weight:bold;">' + b.name + '</div><div style="font-size:12px;color:#888;">' + new Date(b.time).toLocaleString() + '</div></div>';
          html += '<div style="color:#43e97b;font-size:12px;">已备份</div>';
          html += '</div>';
        });
      }
      document.getElementById('backupsList').innerHTML = html;
    }
  } catch (e) {
    document.getElementById('backupsList').innerHTML = '<div style="color:#ff6b6b;">加载失败: ' + e.message + '</div>';
  }
}

// ========== 统计仪表盘 ==========
async function loadStatsDashboard() {
  try {
    const result = await window.api.xiuxianGetStatsDashboard();
    if (result.success) {
      const s = result.data;
      let html = '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px;">';
      html += '<div style="padding:15px;background:linear-gradient(135deg,#667eea,#764ba2);border-radius:10px;color:white;text-align:center;"><div style="font-size:12px;opacity:0.8;">总玩家数</div><div style="font-size:28px;font-weight:bold;">' + s.totalPlayers + '</div></div>';
      html += '<div style="padding:15px;background:linear-gradient(135deg,#f093fb,#f5576c);border-radius:10px;color:white;text-align:center;"><div style="font-size:12px;opacity:0.8;">总灵石</div><div style="font-size:28px;font-weight:bold;">' + s.totalGold.toLocaleString() + '</div></div>';
      html += '<div style="padding:15px;background:linear-gradient(135deg,#4facfe,#00f2fe);border-radius:10px;color:white;text-align:center;"><div style="font-size:12px;opacity:0.8;">平均境界</div><div style="font-size:28px;font-weight:bold;">Lv.' + s.avgLevel + '</div></div>';
      html += '<div style="padding:15px;background:linear-gradient(135deg,#43e97b,#38f9d7);border-radius:10px;color:white;text-align:center;"><div style="font-size:12px;opacity:0.8;">已封禁</div><div style="font-size:28px;font-weight:bold;">' + s.bannedCount + '</div></div>';
      html += '</div>';
      
      html += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">';
      
      // 境界分布
      html += '<div style="padding:15px;background:rgba(255,255,255,0.03);border-radius:8px;"><div style="font-weight:bold;margin-bottom:10px;">境界分布</div>';
      Object.keys(s.realmDistribution).sort((a,b) => a-b).forEach(realm => {
        const count = s.realmDistribution[realm];
        const percent = ((count / s.totalPlayers) * 100).toFixed(1);
        html += '<div style="margin-bottom:6px;"><div style="display:flex;justify-content:space-between;font-size:12px;"><span>境界' + realm + '</span><span>' + count + '人 (' + percent + '%)</span></div><div style="height:6px;background:rgba(255,255,255,0.1);border-radius:3px;margin-top:3px;"><div style="height:100%;width:' + percent + '%;background:#4facfe;border-radius:3px;"></div></div></div>';
      });
      html += '</div>';
      
      // 职业分布
      html += '<div style="padding:15px;background:rgba(255,255,255,0.03);border-radius:8px;"><div style="font-weight:bold;margin-bottom:10px;">职业分布</div>';
      Object.keys(s.occupationDistribution).forEach(occ => {
        const count = s.occupationDistribution[occ];
        html += '<div style="display:flex;justify-content:space-between;padding:4px 0;font-size:12px;"><span style="color:#f093fb;">' + occ + '</span><span>' + count + '人</span></div>';
      });
      html += '</div>';
      
      // 灵根分布
      html += '<div style="padding:15px;background:rgba(255,255,255,0.03);border-radius:8px;"><div style="font-weight:bold;margin-bottom:10px;">灵根分布</div>';
      Object.keys(s.linggenDistribution).forEach(lg => {
        const count = s.linggenDistribution[lg];
        html += '<div style="display:flex;justify-content:space-between;padding:4px 0;font-size:12px;"><span style="color:#43e97b;">' + lg + '</span><span>' + count + '人</span></div>';
      });
      html += '</div>';
      
      html += '</div>';
      
      // 其他统计
      html += '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:20px;">';
      html += '<div style="padding:12px;background:rgba(255,255,255,0.03);border-radius:8px;text-align:center;"><div style="font-size:12px;color:#888;">有仙宠</div><div style="font-size:20px;font-weight:bold;color:#f093fb;">' + s.hasPetCount + '</div></div>';
      html += '<div style="padding:12px;background:rgba(255,255,255,0.03);border-radius:8px;text-align:center;"><div style="font-size:12px;color:#888;">有宗门</div><div style="font-size:20px;font-weight:bold;color:#4facfe;">' + s.hasSectCount + '</div></div>';
      html += '<div style="padding:12px;background:rgba(255,255,255,0.03);border-radius:8px;text-align:center;"><div style="font-size:12px;color:#888;">已婚</div><div style="font-size:20px;font-weight:bold;color:#f5576c;">' + s.marriedCount + '</div></div>';
      html += '<div style="padding:12px;background:rgba(255,255,255,0.03);border-radius:8px;text-align:center;"><div style="font-size:12px;color:#888;">总修为</div><div style="font-size:20px;font-weight:bold;color:#ffd700;">' + s.totalExp.toLocaleString() + '</div></div>';
      html += '</div>';
      
      document.getElementById('statsDashboard').innerHTML = html;
    }
  } catch (e) {
    document.getElementById('statsDashboard').innerHTML = '<div style="color:#ff6b6b;">加载失败: ' + e.message + '</div>';
  }
}


// 打开修仙管理独立窗口
async function openXiuxianAdminWindow() {
  try {
    const result = await window.api.openXiuxianAdmin();
    if (result.success) {
      console.log('[修仙管理] 独立窗口已打开');
    }
  } catch (e) {
    console.error('[修仙管理] 打开独立窗口失败:', e);
    showError('打开独立窗口失败: ' + e.message);
  }
}
