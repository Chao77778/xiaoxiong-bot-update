﻿// ============== 预加载脚本：IPC 桥接 v3.0 ==============
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("api", {
  // 配置
  getConfig: () => ipcRenderer.invoke("config:get"),
  saveConfig: (config) => ipcRenderer.invoke("config:save", config),
  exportConfig: () => ipcRenderer.invoke("config:export"),
  importConfig: () => ipcRenderer.invoke("config:import"),
  selectImage: () => ipcRenderer.invoke("image:select"),

  // 机器人控制
  connect: () => ipcRenderer.invoke("bot:connect"),
  disconnect: () => ipcRenderer.invoke("bot:disconnect"),
  getStatus: () => ipcRenderer.invoke("bot:status"),
  clearLogs: () => ipcRenderer.invoke("bot:clear-logs"),

  // 网站对接
  websiteTest: () => ipcRenderer.invoke("website:test"),
  websitePushNow: () => ipcRenderer.invoke("website:push-now"),
  websiteCheckNow: () => ipcRenderer.invoke("website:check-now"),

  // 推送群管理
  pushGroupsAdd: (groupId) => ipcRenderer.invoke("push-groups:add", groupId),
  pushGroupsRemove: (groupId) => ipcRenderer.invoke("push-groups:remove", groupId),

  // 群设置
  groupSettingsGet: (groupId) => ipcRenderer.invoke("group-settings:get", groupId),
  groupSettingsSave: (groupId, settings) => ipcRenderer.invoke("group-settings:save", groupId, settings),
  groupSettingsReset: (groupId) => ipcRenderer.invoke("group-settings:reset", groupId),
  groupSettingsList: () => ipcRenderer.invoke("group-settings:list"),

  // 事件监听
  onLog: (callback) => ipcRenderer.on("bot:log", (_, data) => callback(data)),
  onStatus: (callback) => ipcRenderer.on("bot:status", (_, data) => callback(data)),
  onWindowMaximized: (callback) => ipcRenderer.on("window:maximized", (_, data) => callback(data)),
  onOfficialGroupAdded: (callback) => ipcRenderer.on("official:group_added", (_, data) => callback(data)),

  // 窗口控制
  windowMinimize: () => ipcRenderer.invoke("window:minimize"),
  windowMaximize: () => ipcRenderer.invoke("window:maximize"),
  windowClose: () => ipcRenderer.invoke("window:close"),
  windowIsMaximized: () => ipcRenderer.invoke("window:is-maximized"),

  // 在线更新
  updateGetVersion: () => ipcRenderer.invoke("update:get-version"),
  getVersion: () => ipcRenderer.invoke("update:get-version"),
    updateCheck: () => ipcRenderer.invoke("update:check"),
  updateDownload: () => ipcRenderer.invoke("update:download"),
  updateRestart: () => ipcRenderer.invoke("update:restart"),
  updateLocal: () => ipcRenderer.invoke("update:local"),

  // Warframe
  wfGetPlatform: () => ipcRenderer.invoke("warframe:get-platform"),
  wfSetPlatform: (platform) => ipcRenderer.invoke("warframe:set-platform", platform),
});
