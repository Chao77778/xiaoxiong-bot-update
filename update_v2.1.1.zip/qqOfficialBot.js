﻿// ============== QQ官方机器人 API 适配器 ==============
const https = require("https");
const http = require("http");
const WebSocket = require("ws");

const OFFICIAL_API_BASE = "https://api.bot.qq.com";
const TOKEN_API_URL = "https://bots.qq.com/app/getAppAccessToken";
let accessToken = null;
let accessTokenExpireTime = 0;
let officialWs = null;
let officialHeartbeatTimer = null;
let officialSessionId = null;
let officialSeq = 0;
let officialStatus = "disconnected";
let officialBotInfo = null;
let onOfficialMessage = null;
let onOfficialStatusChange = null;
// 自动重连相关
let officialReconnectTimer = null;
let officialReconnectAttempts = 0;
let officialManualDisconnect = false;
let officialSavedAppId = null;
let officialSavedAppSecret = null;
// HTTP POST 请求
function httpPost(url, data, headers = {}, timeout = 10000) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const postData = JSON.stringify(data);
    const req = https.request({
      hostname: urlObj.hostname,
      path: urlObj.pathname + urlObj.search,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(postData),
        ...headers
      }
    }, (res) => {
      let body = "";
      res.on("data", (c) => body += c);
      res.on("end", () => {
        try {
          const json = JSON.parse(body);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(json);
          } else {
            reject(new Error(json.message || `HTTP ${res.statusCode}`));
          }
        } catch (e) {
          reject(e);
        }
      });
    });
    req.setTimeout(timeout, () => { req.destroy(); reject(new Error("请求超时")); });
    req.on("error", reject);
    req.write(postData);
    req.end();
  });
}

// HTTP GET 请求
function httpGetOfficial(url, headers = {}, timeout = 10000) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const req = https.get({
      hostname: urlObj.hostname,
      path: urlObj.pathname + urlObj.search,
      headers
    }, (res) => {
      let body = "";
      res.on("data", (c) => body += c);
      res.on("end", () => {
        try {
          const json = JSON.parse(body);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(json);
          } else {
            reject(new Error(json.message || `HTTP ${res.statusCode}`));
          }
        } catch (e) {
          reject(e);
        }
      });
    });
    req.setTimeout(timeout, () => { req.destroy(); reject(new Error("请求超时")); });
    req.on("error", reject);
  });
}

// 获取 access_token
async function getAccessToken(appId, appSecret) {
  const now = Date.now();
  if (accessToken && now < accessTokenExpireTime - 60000) {
    return accessToken;
  }
  try {
    const result = await httpPost(TOKEN_API_URL, {
      appId: appId,
      clientSecret: appSecret
    });
    accessToken = result.access_token;
    accessTokenExpireTime = now + (result.expires_in || 7200) * 1000;
    return accessToken;
  } catch (e) {
    throw new Error("获取access_token失败: " + e.message);
  }
}

// 获取 WSS 接入点
async function getGateway(appId, appSecret) {
  const token = await getAccessToken(appId, appSecret);
  const result = await httpGetOfficial(`${OFFICIAL_API_BASE}/gateway`, {
    "Authorization": `QQBot ${token}`
  });
  return result.url;
}

// 连接官方机器人
async function connectOfficialBot(appId, appSecret, messageCallback, statusCallback) {
  onOfficialMessage = messageCallback;
  onOfficialStatusChange = statusCallback;
  officialSavedAppId = appId;
  officialSavedAppSecret = appSecret;
  officialManualDisconnect = false;
  officialReconnectAttempts = 0;
  clearTimeout(officialReconnectTimer);
  
  try {
    officialStatus = "connecting";
    if (onOfficialStatusChange) onOfficialStatusChange(officialStatus);
    
    const token = await getAccessToken(appId, appSecret);
    const gatewayUrl = await getGateway(appId, appSecret);
    
    if (officialWs) { try { officialWs.close(); } catch (e) {} officialWs = null; }
    
    officialWs = new WebSocket(gatewayUrl);
    
    officialWs.on("open", () => {
      console.log("[官方机器人] WebSocket已连接");
    });
    
    officialWs.on("message", (data) => {
      try {
        const payload = JSON.parse(data.toString());
        handleOfficialPayload(payload, appId, appSecret);
      } catch (e) {
        console.error("[官方机器人] 解析消息失败:", e.message);
      }
    });
    
    officialWs.on("error", (err) => {
      console.error("[官方机器人] WebSocket错误:", err.message);
    });
    
    officialWs.on("close", () => {
      console.log("[官方机器人] WebSocket已断开");
      officialStatus = "disconnected";
      if (officialHeartbeatTimer) {
        clearInterval(officialHeartbeatTimer);
        officialHeartbeatTimer = null;
      }
      if (onOfficialStatusChange) onOfficialStatusChange(officialStatus);
      // 自动重连（非主动断开时）
      if (!officialManualDisconnect && officialSavedAppId && officialSavedAppSecret) {
        scheduleOfficialReconnect();
      }
    });
    
    return true;
  } catch (e) {
    officialStatus = "error";
    if (onOfficialStatusChange) onOfficialStatusChange(officialStatus);
    // 连接失败也尝试重连
    if (!officialManualDisconnect && officialSavedAppId && officialSavedAppSecret) {
      scheduleOfficialReconnect();
    }
    throw e;
  }
}

// 官方机器人自动重连（指数退避）
function scheduleOfficialReconnect() {
  clearTimeout(officialReconnectTimer);
  officialReconnectAttempts++;
  const delay = Math.min(5000 * Math.pow(2, officialReconnectAttempts - 1), 60000);
  const seconds = Math.round(delay / 1000);
  console.log(`[官方机器人] ${seconds}秒后自动重连（第${officialReconnectAttempts}次尝试）...`);
  officialReconnectTimer = setTimeout(async () => {
    if (officialManualDisconnect) return;
    try {
      await connectOfficialBot(officialSavedAppId, officialSavedAppSecret, onOfficialMessage, onOfficialStatusChange);
    } catch (e) {
      console.error("[官方机器人] 重连失败:", e.message);
    }
  }, delay);
}

// 断开官方机器人（主动断开，不自动重连）
function disconnectOfficialBot() {
  officialManualDisconnect = true;
  clearTimeout(officialReconnectTimer);
  officialReconnectAttempts = 0;
  if (officialHeartbeatTimer) {
    clearInterval(officialHeartbeatTimer);
    officialHeartbeatTimer = null;
  }
  if (officialWs) {
    try { officialWs.close(); } catch (e) {}
    officialWs = null;
  }
  officialStatus = "disconnected";
  if (onOfficialStatusChange) onOfficialStatusChange(officialStatus);
  console.log("[官方机器人] 已主动断开");
}
// 处理官方机器人消息
function handleOfficialPayload(payload, appId, appSecret) {
  const { op, d, s, t } = payload;
  
  if (s) officialSeq = s;
  
  switch (op) {
    case 10: // Hello
      console.log("[官方机器人] 收到Hello，心跳间隔:", d.heartbeat_interval);
      // 发送鉴权
      sendIdentify(appId);
      // 启动心跳
      startHeartbeat(d.heartbeat_interval);
      break;
      
    case 0: // Dispatch
      handleOfficialEvent(t, d);
      break;
      
    case 11: // Heartbeat ACK
      // 心跳确认
      break;
      
    case 7: // Reconnect
      console.log("[官方机器人] 收到重连通知");
      break;
      
    case 9: // Invalid Session
      console.error("[官方机器人] 鉴权失败");
      officialStatus = "error";
      if (onOfficialStatusChange) onOfficialStatusChange(officialStatus);
      break;
  }
}

// 发送鉴权
function sendIdentify(appId) {
  if (!officialWs || officialWs.readyState !== WebSocket.OPEN) return;
  
  // 订阅群消息和单聊事件
  // GROUP_AND_C2C_EVENT = 1 << 25 = 33554432
  const intents = 33554432;
  
  const identifyPayload = {
    op: 2,
    d: {
      token: `QQBot ${accessToken}`,
      intents: intents,
      shard: [0, 1],
      properties: {
        "$os": "windows",
        "$browser": "xiaoxiong-bot",
        "$device": "xiaoxiong-bot"
      }
    }
  };
  
  officialWs.send(JSON.stringify(identifyPayload));
  console.log("[官方机器人] 已发送鉴权请求");
}

// 启动心跳
function startHeartbeat(interval) {
  if (officialHeartbeatTimer) clearInterval(officialHeartbeatTimer);
  
  officialHeartbeatTimer = setInterval(() => {
    if (!officialWs || officialWs.readyState !== WebSocket.OPEN) return;
    
    const heartbeatPayload = {
      op: 1,
      d: officialSeq || null
    };
    
    officialWs.send(JSON.stringify(heartbeatPayload));
  }, interval);
  
  console.log("[官方机器人] 心跳已启动，间隔:", interval, "ms");
}

// 处理官方事件
function handleOfficialEvent(eventType, data) {
  switch (eventType) {
    case "READY":
      officialStatus = "connected";
      officialSessionId = data.session_id;
      officialBotInfo = data.user;
      console.log("[官方机器人] 鉴权成功，机器人:", data.user.username);
      if (onOfficialStatusChange) onOfficialStatusChange(officialStatus);
      break;
      
    case "RESUMED":
      console.log("[官方机器人] 会话恢复成功");
      break;
      
    case "GROUP_AT_MESSAGE_CREATE":
      // 群@消息
      console.log("[官方机器人] 收到群@消息");
      if (onOfficialMessage) {
        onOfficialMessage({
          type: "group_at",
          group_id: data.group_id,
          user_id: data.author.id,
          message: data.content,
          message_id: data.id,
          raw: data
        });
      }
      break;
      
    case "C2C_MESSAGE_CREATE":
      // 单聊消息
      console.log("[官方机器人] 收到单聊消息");
      if (onOfficialMessage) {
        onOfficialMessage({
          type: "c2c",
          user_id: data.author.id,
          message: data.content,
          message_id: data.id,
          raw: data
        });
      }
      break;
      
        case "GROUP_ADD_ROBOT":
      // 机器人被添加到群
      console.log("[官方机器人] 被添加到群，完整data:", JSON.stringify(data));
      console.log("[官方机器人] data.group_id:", data.group_id);
      console.log("[官方机器人] data.id:", data.id);
      console.log("[官方机器人] data.group_openid:", data.group_openid);
      // 尝试多种可能的字段名
      const groupOpenid = data.group_id || data.id || data.group_openid || data.openid || "";
      console.log("[官方机器人] 最终使用的group_openid:", groupOpenid);
      if (onOfficialMessage) {
        onOfficialMessage({
          type: "group_add",
          group_id: groupOpenid,
          group_openid: groupOpenid,
          raw: data
        });
      }
      break;
      
    case "GROUP_DEL_ROBOT":
      // 机器人被移出群
      console.log("[官方机器人] 被移出群:", data.group_id);
      break;
      
    default:
      console.log("[官方机器人] 收到事件:", eventType);
  }
}

// 发送群消息（官方API）
async function sendOfficialGroupMessage(groupId, content, msgId = null) {
  if (!accessToken) throw new Error("未获取access_token");
  if (officialStatus !== "connected") throw new Error("官方机器人未连接");
  if (!officialWs || officialWs.readyState !== WebSocket.OPEN) throw new Error("官方WebSocket未连接");
  
  const body = {
    content: content,
    msg_type: 0 // 文本
  };
  
  if (msgId) {
    body.msg_id = msgId; // 被动回复需要
  }
  
  const result = await httpPost(
    `${OFFICIAL_API_BASE}/v2/groups/${groupId}/messages`,
    body,
    { "Authorization": `QQBot ${accessToken}` }
  );
  
  return result;
}

// 下载图片并转换为base64（带超时和重定向限制）
function downloadImageToBase64(url, timeout = 10000, redirectCount = 0) {
  return new Promise((resolve, reject) => {
    if (redirectCount > 3) { reject(new Error("图片重定向次数过多")); return; }
    const client = url.startsWith("https") ? https : http;
    const req = client.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume(); // 消耗响应数据
        // 重定向
        downloadImageToBase64(res.headers.location, timeout, redirectCount + 1).then(resolve).catch(reject);
        return;
      }
      if (res.statusCode !== 200) {
        res.resume();
        reject(new Error(`下载图片失败: HTTP ${res.statusCode}`));
        return;
      }
      const chunks = [];
      res.on("data", (chunk) => chunks.push(chunk));
      res.on("end", () => {
        try {
          const buffer = Buffer.concat(chunks);
          const base64 = buffer.toString("base64");
          resolve(base64);
        } catch (e) { reject(e); }
      });
      res.on("error", reject);
    });
    req.setTimeout(timeout, () => { req.destroy(); reject(new Error("图片下载超时")); });
    req.on("error", reject);
  });
}
// 上传文件到官方服务器，获取file_info
async function uploadOfficialFile(groupId, fileDataBase64, fileType = 1) {
  if (!accessToken) throw new Error("未获取access_token");
  
  const body = {
    file_type: fileType, // 1=图片
    file_data: fileDataBase64
  };
  
  const result = await httpPost(
    `${OFFICIAL_API_BASE}/v2/groups/${groupId}/files`,
    body,
    { "Authorization": `QQBot ${accessToken}` }
  );
  
  return result.file_info;
}

// 发送富媒体消息（图片等）
async function sendOfficialMediaMessage(groupId, fileInfo, msgId = null) {
  if (!accessToken) throw new Error("未获取access_token");
  if (officialStatus !== "connected") throw new Error("官方机器人未连接");
  
  const body = {
    msg_type: 7, // 富媒体
    media: {
      file_info: fileInfo
    }
  };
  
  if (msgId) {
    body.msg_id = msgId;
  }
  
  const result = await httpPost(
    `${OFFICIAL_API_BASE}/v2/groups/${groupId}/messages`,
    body,
    { "Authorization": `QQBot ${accessToken}` }
  );
  
  return result;
}

// 发送文本+图片混合消息（先发文本，再发图片）
async function sendOfficialGroupMessageWithImage(groupId, text, imageUrl, msgId = null) {
  // 先发文本
  if (text && text.trim()) {
    await sendOfficialGroupMessage(groupId, text, msgId);
  }
  
  // 再发图片
  if (imageUrl) {
    const base64 = await downloadImageToBase64(imageUrl);
    const fileInfo = await uploadOfficialFile(groupId, base64, 1);
    await sendOfficialMediaMessage(groupId, fileInfo, msgId);
  }
  
  return { success: true };
}

// 发送 Embed 卡片消息（带按钮）- 注意：仅频道支持，群消息不支持
async function sendOfficialEmbedMessage(groupId, embed, keyboard = null, msgId = null) {
  if (!accessToken) throw new Error("未获取access_token");
  if (officialStatus !== "connected") throw new Error("官方机器人未连接");
  
  const body = {
    msg_type: 4, // Embed
    embed: embed
  };
  
  if (keyboard) {
    body.keyboard = keyboard;
  }
  
  if (msgId) {
    body.msg_id = msgId;
  }
  
  const result = await httpPost(
    `${OFFICIAL_API_BASE}/v2/groups/${groupId}/messages`,
    body,
    { "Authorization": `QQBot ${accessToken}` }
  );
  
  return result;
}

// 发送 Markdown 消息（带按钮）- 群消息支持
// 带重试的HTTP请求
async function httpPostWithRetry(url, body, headers, maxRetries = 3) {
  let lastError = null;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      // 每次请求前确保token有效
      if (officialSavedAppId && officialSavedAppSecret) {
        await getAccessToken(officialSavedAppId, officialSavedAppSecret);
        headers["Authorization"] = `QQBot ${accessToken}`;
      }
      const result = await httpPost(url, body, headers);
      return result;
    } catch (e) {
      lastError = e;
      console.warn(`[官方机器人] 请求失败（第${attempt}/${maxRetries}次）: ${e.message}`);
      if (attempt < maxRetries) {
        // 指数退避：1秒、2秒、4秒
        const delay = Math.pow(2, attempt - 1) * 1000;
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  throw lastError;
}

async function sendOfficialMarkdownMessage(groupId, markdownContent, keyboard = null, msgId = null) {
  if (officialStatus !== "connected") throw new Error("官方机器人未连接");
  
  // 确保token有效
  if (officialSavedAppId && officialSavedAppSecret) {
    await getAccessToken(officialSavedAppId, officialSavedAppSecret);
  }
  if (!accessToken) throw new Error("未获取access_token");
  
  const body = {
    msg_type: 2, // Markdown
    markdown: {
      content: markdownContent
    }
  };
  
  if (keyboard) {
    body.keyboard = keyboard;
  }
  
  if (msgId) {
    body.msg_id = msgId;
  }
  
  // 带重试发送
  const result = await httpPostWithRetry(
    `${OFFICIAL_API_BASE}/v2/groups/${groupId}/messages`,
    body,
    { "Authorization": `QQBot ${accessToken}` },
    3 // 最多重试3次
  );
  
  return result;
}

// 发送 Ark 大图卡片（模板37）- 一条消息包含标题+描述+大图+跳转链接
async function sendOfficialArkCard(groupId, title, subtitle, imageUrl, link, prompt = "新消息", msgId = null) {
  if (!accessToken) throw new Error("未获取access_token");
  if (officialStatus !== "connected") throw new Error("官方机器人未连接");
  
  // 子标题截断（避免过长）
  if (subtitle && subtitle.length > 80) {
    subtitle = subtitle.slice(0, 80) + "...";
  }
  
  const body = {
    msg_type: 3, // Ark
    ark: {
      template_id: 37, // 大图模板
      kv: [
        { key: "#PROMPT#", value: prompt || "新消息" },
        { key: "#METATITLE#", value: title || "标题" },
        { key: "#METASUBTITLE#", value: subtitle || "" },
        { key: "#METACOVER#", value: imageUrl || "" },
        { key: "#METAURL#", value: link || "" }
      ]
    }
  };
  
  if (msgId) {
    body.msg_id = msgId;
  }
  
  const result = await httpPost(
    `${OFFICIAL_API_BASE}/v2/groups/${groupId}/messages`,
    body,
    { "Authorization": `QQBot ${accessToken}` }
  );
  
  return result;
}

// 构造复制按钮（type=2 指令按钮，点击后在输入框插入 @bot + 内容，用户可复制）
function buildCopyButton(label, copyText, buttonId = "1") {
  return {
    id: buttonId,
    render_data: {
      label: label,
      visited_label: "已复制，粘贴即可",
      style: 1 // 1=蓝色线框
    },
    action: {
      type: 2, // 2=指令按钮：自动在输入框插入 @bot data
      data: copyText,
      permission: {
        type: 2 // 2=所有人可操作
      },
      unsupport_tips: "客户端不支持，请长按链接复制"
    }
  };
}

// 构造跳转链接按钮
function buildLinkButton(label, url, buttonId = "1") {
  return {
    id: buttonId,
    render_data: {
      label: label,
      style: 0, // 0=灰色
      clicked_label: "正在跳转"
    },
    action: {
      type: 0, // 0=跳转链接
      data: url,
      permission: {
        type: 0
      }
    }
  };
}

// 构造键盘（一行多个按钮）
function buildKeyboard(buttons) {
  // buttons 是二维数组，第一维是行，第二维是该行的按钮
  const rows = buttons.map(rowButtons => ({ buttons: rowButtons }));
  return {
    content: { rows: rows }
  };
}

// 发送文章卡片（Markdown文本+图片 + 底部复制按钮）- 一条消息包含文字和图片
async function sendOfficialArticleCard(groupId, title, description, imageUrl, link, msgId = null) {
  // 构造 Markdown 内容（图片直接显示在 Markdown 里）
  let md = `## 📢 ${title || "新文章推荐"}\n\n`;
  if (description) {
    md += `${description}\n\n`;
  }
  // Markdown 图片语法：![描述 #宽度 #高度](图片URL)
  if (imageUrl) {
    md += `![封面 #600px #400px](${imageUrl})\n\n`;
  }
  md += `---\n点击下方按钮复制链接，到浏览器打开详情`;
  
  // 底部按钮：复制链接
  const copyBtn = buildCopyButton("复制链接去浏览器打开", link, "copy_link");
  const keyboard = buildKeyboard([[copyBtn]]);
  
  // 发送 Markdown + 按钮（一条消息包含文字和图片）
  return await sendOfficialMarkdownMessage(groupId, md, keyboard, msgId);
}

// 发送游戏卡片（Markdown文本+图片 + 底部复制按钮）- 一条消息包含文字和图片
async function sendOfficialGameCard(groupId, gameName, gameDesc, imageUrl, link, extraFields = [], msgId = null) {
  // 构造 Markdown 内容
  let md = `## 🎮 ${gameName || "游戏详情"}\n\n`;
  if (gameDesc) {
    md += `${gameDesc}\n\n`;
  }
  if (Array.isArray(extraFields)) {
    extraFields.forEach(f => {
      if (f.name) {
        md += `**${f.name}**${f.value ? "：" + f.value : ""}\n\n`;
      }
    });
  }
  // Markdown 图片语法
  if (imageUrl) {
    md += `![游戏封面 #600px #400px](${imageUrl})\n\n`;
  }
  md += `---\n点击下方按钮复制链接，到浏览器下载/查看详情`;
  
  // 底部按钮：复制链接
  const copyBtn = buildCopyButton("复制链接去浏览器打开", link, "copy_link");
  const keyboard = buildKeyboard([[copyBtn]]);
  
  // 发送 Markdown + 按钮
  return await sendOfficialMarkdownMessage(groupId, md, keyboard, msgId);
}

// 发送多结果卡片（Markdown文本 + 底部复制全部按钮）
async function sendOfficialMultiResultCard(groupId, keyword, posts, msgId = null) {
  // 构造 Markdown 内容（不直接显示链接，避免风控）
  let md = `## 🎮 找到 ${posts.length} 个"${keyword}"相关游戏\n\n`;
  posts.forEach((p, i) => {
    const title = p.title || "无标题";
    const excerpt = p.excerpt || "";
    md += `${i + 1}. **${title}**\n`;
    if (excerpt) md += `   ${excerpt}\n`;
    md += `\n`;
  });
  md += `---\n点击下方按钮复制全部游戏链接`;
  
  // 复制所有链接
  const allLinks = posts.map((p, i) => `${i + 1}. ${p.title || ""}\n${p.link || ""}`).join("\n\n");
  const copyBtn = buildCopyButton("复制全部链接", allLinks, "copy_all");
  const keyboard = buildKeyboard([[copyBtn]]);
  
  return await sendOfficialMarkdownMessage(groupId, md, keyboard, msgId);
}

// 断开官方机器人连接
function disconnectOfficialBot() {
  if (officialHeartbeatTimer) {
    clearInterval(officialHeartbeatTimer);
    officialHeartbeatTimer = null;
  }
  if (officialWs) {
    try { officialWs.close(); } catch (e) {}
    officialWs = null;
  }
  officialStatus = "disconnected";
  officialSessionId = null;
  officialSeq = 0;
  // 重置token，避免重新连接时使用过期token
  accessToken = null;
  accessTokenExpireTime = 0;
  officialBotInfo = null;
}

// 获取官方机器人状态
function getOfficialStatus() {
  return {
    status: officialStatus,
    botInfo: officialBotInfo
  };
}

module.exports = {
  connectOfficialBot,
  disconnectOfficialBot,
  sendOfficialGroupMessage,
  sendOfficialGroupMessageWithImage,
  sendOfficialMediaMessage,
  sendOfficialEmbedMessage,
  sendOfficialMarkdownMessage,
  sendOfficialArkCard,
  sendOfficialArticleCard,
  sendOfficialGameCard,
  sendOfficialMultiResultCard,
  buildCopyButton,
  buildLinkButton,
  buildKeyboard,
  uploadOfficialFile,
  downloadImageToBase64,
  getOfficialStatus,
  getAccessToken
};
