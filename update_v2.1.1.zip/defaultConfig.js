// ============== 配置默认值（OneBot 协议版 + 网站对接 + 群粒度开关）==============
const DEFAULT_CONFIG = {
  // OneBot WebSocket 连接配置
  connection: {
    wsUrl: "ws://127.0.0.1:3001",
    accessToken: "",
    autoReconnect: true,
  },

  // 官方机器人模式配置
  official: {
    appId: "",
    appSecret: "",
  },

  // 双模式：LLBot接收消息 + 官方机器人发送
  dualMode: {
    enabled: false, // 开启后OneBot和官方同时连接，OneBot收消息，官方发消息
    groupIdMap: {}, // QQ群号 -> group_openid 映射，例如: {"123456": "ABC123..."}
  },

  // 网站对接（子比主题/WordPress）
  website: {
    enabled: true,
    url: "https://xygmyx.cn",
    checkInterval: 5, // 检查间隔（分钟）
    pushTemplate: "🎮 新游上架！\n{title}\n👉 {link}",
    lastPostId: 0, // 上次推送的最新文章ID
    pushGroups: [], // 启用自动推送的群ID列表
  },

  // 全局默认功能开关（新群默认使用这些设置）
  defaults: {
    welcome: true,       // 入群欢迎
    leaveNotice: true,   // 退群提醒
    keywordReply: true,  // 关键词回复
    websitePush: true,   // 网站新游推送（自动推送）
    websiteQuery: true,  // 网站游戏查询（#搜索/#游戏/#分类/#标签/#随机）
    warframe: true,      // Warframe国际服查询
    admin: true,         // 群管指令
    hitokoto: true,      // 一言功能
  },

  // 按群单独设置（群ID字符串为key，覆盖defaults）
  // 例如："123456": { welcome: false, websitePush: true }
  groupSettings: {},

  // 入群欢迎（全局模板，具体群在groupSettings里开关）
  welcome: {
    message: "欢迎 {at} 加入{group}！\n请先看群公告，文明交流，有问题随时@群主~\n\n🎮 游戏下载地址（长按复制）：\n```\nhttps://xygmyx.cn\n```\n复制后到浏览器打开~",
  },

  // 退群提醒
  leaveNotice: {
    message: "{nick}({qq}) 已退出群聊",
  },

  // 关键词回复
  keywordReplies: [
    { keyword: "你好", reply: "你好呀！我是本群机器人，发送 #帮助 查看我的功能~", mode: "includes" },
    { keyword: "机器人", reply: "在的在的，有什么可以帮你？发送 #帮助 看指令列表", mode: "includes" },
  ],

  // 每日一言
  hitokotoList: [
    "生活就像海洋，只有意志坚强的人才能到达彼岸。—— 马克思",
    "成功不是终点，失败也并非末日，最重要的是继续前进的勇气。—— 丘吉尔",
    "你若盛开，蝴蝶自来；你若精彩，天自安排。",
    "愿你出走半生，归来仍是少年。",
    "星光不问赶路人，时光不负有心人。",
    "所谓无底深渊，下去，也是前程万里。—— 木心",
    "人间烟火气，最抚凡人心。",
    "慢慢来，谁还没有一个努力的过程。",
  ],
};

module.exports = { DEFAULT_CONFIG };
