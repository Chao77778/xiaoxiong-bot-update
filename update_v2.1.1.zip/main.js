﻿// ============== Electron 主进程（OneBot v11 + 网站对接 + 群粒度开关）==============
const { app, BrowserWindow, ipcMain, dialog, shell } = require("electron");
const path = require("path");
const fs = require("fs");
const https = require("https");
const http = require("http");
const { exec } = require("child_process");
const WebSocket = require("ws");
const { DEFAULT_CONFIG } = require("./defaultConfig");
const officialBot = require("./qqOfficialBot");

const CONFIG_PATH = path.join(app.getPath("userData"), "config.json");
const APP_VERSION = require("./package.json").version;
const UPDATE_URL = "https://raw.githubusercontent.com/Chao77778/xiaoxiong-bot-update/main/";

// ==================== 工具函数 ====================
// 定期清理过期缓存（防止内存泄漏）
let cacheCleanupTimer = null;
function startCacheCleanup() {
  if (cacheCleanupTimer) return;
  cacheCleanupTimer = setInterval(() => {
    const now = Date.now();
    // 清理过期的频率限制
    for (const [userId, lastTime] of userRateLimit) {
      if (now - lastTime > 60000) userRateLimit.delete(userId);
    }
    // 清理过期的缓存
    for (const [key, item] of cacheStore) {
      if (now > item.expire) cacheStore.delete(key);
    }
    // 清理入群欢迎缓存（保留最近1000条）
    if (welcomeCache.size > 1000) {
      const arr = Array.from(welcomeCache);
      welcomeCache.clear();
      arr.slice(-500).forEach(id => welcomeCache.add(id));
    }
  }, 300000); // 每5分钟清理一次
}
// 带超时的HTTP GET
function httpGet(url, timeout = null, customHeaders = null) {
  // 从配置读取超时时间，默认8秒
  if (!timeout && currentConfig && currentConfig.system) {
    timeout = (currentConfig.system.msgTimeout || 8) * 1000;
  } else if (!timeout) {
    timeout = 8000;
  }
  return new Promise((resolve, reject) => {
    const client = url.startsWith("https://") ? https : http;
    const headers = customHeaders || { "User-Agent": "XiaoXiongBot/1.0", "Accept": "application/json" };
    const req = client.get(url, { headers }, (res) => {
      let data = "";
      res.on("data", (c) => data += c);
      res.on("end", () => {
        if (res.statusCode < 200 || res.statusCode >= 300) { reject(new Error("HTTP " + res.statusCode)); return; }
        try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
      });
    });
    req.setTimeout(timeout, () => { req.destroy(); reject(new Error("请求超时")); });
    req.on("error", reject);
  });
}

// 简单缓存（带过期时间）
const cacheStore = new Map();
function cacheGet(key) {
  const item = cacheStore.get(key);
  if (!item) return null;
  if (Date.now() > item.expire) { cacheStore.delete(key); return null; }
  return item.data;
}
function cacheSet(key, data, ttl = 30000) {
  cacheStore.set(key, { data, expire: Date.now() + ttl });
}

// 消息频率限制（每个用户每3秒最多1次指令响应）
const userRateLimit = new Map();
function checkRateLimit(userId, interval = 3000) {
  const now = Date.now();
  const last = userRateLimit.get(userId) || 0;
  if (now - last < interval) return false;
  userRateLimit.set(userId, now);
  return true;
}

let mainWindow = null;
let ws = null;
let currentConfig = null;
let botStatus = "disconnected";
let logBuffer = [];
let reconnectTimer = null;
let heartbeatTimer = null;
let websiteMonitorTimer = null;
let websiteInitialCheckTimer = null;
let botQQ = null;
let reconnectAttempts = 0;
let connectTimeoutTimer = null;
let manualDisconnect = false; // 主动断开标志，避免主动断开后自动重连
const welcomeCache = new Set();
const MAX_LOGS = 500;
let actionEchoCounter = 0;
const actionCallbacks = new Map();

// 官方机器人模式状态
let officialMode = false; // false=OneBot模式, true=官方模式
let officialStatus = "disconnected";
let officialLastMsgId = null; // 官方模式当前处理的消息ID，用于被动回复

// ==================== 配置文件读写 ====================
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const data = fs.readFileSync(CONFIG_PATH, "utf-8");
      currentConfig = JSON.parse(data);
      currentConfig = deepMerge(DEFAULT_CONFIG, currentConfig);
    } else {
      currentConfig = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
      saveConfig();
    }
  } catch (e) {
    console.error("加载配置失败:", e);
    currentConfig = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  }
  // 同步运行模式
  officialMode = currentConfig.officialMode === true;
  return currentConfig;
}

function saveConfig(config) {
  if (config) currentConfig = config;
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(currentConfig, null, 2), "utf-8");
    return true;
  } catch (e) {
    console.error("保存配置失败:", e);
    return false;
  }
}

function deepMerge(target, source) {
  const result = { ...target };
  for (const key in source) {
    if (source[key] && typeof source[key] === "object" && !Array.isArray(source[key])) {
      result[key] = deepMerge(target[key] || {}, source[key]);
    } else {
      result[key] = source[key];
    }
  }
  return result;
}

// ==================== 群功能开关辅助 ====================
function isFeatureEnabled(groupId, feature) {
  const gid = String(groupId);
  const groupCfg = currentConfig.groupSettings[gid];
  if (groupCfg && typeof groupCfg[feature] === "boolean") {
    return groupCfg[feature];
  }
  return currentConfig.defaults[feature] !== false;
}

// ==================== 日志 & 状态 ====================
function addLog(type, message) {
  // 日志级别过滤
  const sysCfg = currentConfig.system || {};
  const logLevel = sysCfg.logLevel || "all";
  const levelOrder = { debug: 0, info: 1, warn: 2, error: 3 };
  const minLevel = levelOrder[logLevel] !== undefined ? levelOrder[logLevel] : 0;
  const currentLevel = levelOrder[type] !== undefined ? levelOrder[type] : 1;
  if (currentLevel < minLevel) return;
  
  // 调试模式
  if (sysCfg.debugMode) {
    console.log("[DEBUG][" + type + "] " + message);
  }
  

  const now = new Date();
  const time = now.toLocaleString("zh-CN", { hour12: false, month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const entry = {
    time,
    type,
    message,
    timestamp: now.getTime()
  };
  logBuffer.push(entry);
  if (logBuffer.length > MAX_LOGS) logBuffer.shift();
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send("bot:log", entry);
  }
}

function updateStatus(status) {
  botStatus = status;
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send("bot:status", { status, botQQ });
  }
}

// ==================== 官方机器人模式 ====================
async function connectOfficialBotMode() {
  const appId = currentConfig.official && currentConfig.official.appId;
  const appSecret = currentConfig.official && currentConfig.official.appSecret;
  
  if (!appId || !appSecret) {
    addLog("error", "请先配置官方机器人 AppID 和 AppSecret");
    updateOfficialStatus("error");
    return;
  }
  
  try {
    updateOfficialStatus("connecting");
    // 对AppID进行部分隐藏，避免日志泄露
    const maskedAppId = appId.length > 8 ? appId.slice(0, 4) + "****" + appId.slice(-4) : appId;
    addLog("info", `正在连接官方机器人: AppID=${maskedAppId}`);
    
    await officialBot.connectOfficialBot(
      appId,
      appSecret,
      (msg) => handleOfficialMessage(msg),
      (status) => updateOfficialStatus(status)
    );
    
    addLog("success", "官方机器人连接成功");
  } catch (e) {
    addLog("error", `官方机器人连接失败: ${e.message}`);
    updateOfficialStatus("error");
  }
}

function disconnectOfficialBotMode() {
  officialBot.disconnectOfficialBot();
  updateOfficialStatus("disconnected");
  addLog("info", "官方机器人已断开");
}

function handleOfficialMessage(msg) {
  if (msg.type === "group_at") {
    // 群@消息 - 去掉@机器人部分，调用现有指令处理
    let content = msg.message || "";
    content = content.replace(/^@\S+\s*/, "").trim();
    addLog("info", `[官方-群@] 群openid=${msg.group_id} 用户=${msg.user_id}: ${content}`);
    
    // 设置当前消息ID，用于被动回复
    officialLastMsgId = msg.message_id;
    
    // 构造OneBot格式的消息对象，复用现有处理逻辑
    const fakeData = {
      raw_message: content,
      group_id: msg.group_id,
      user_id: msg.user_id,
      sender: { role: "member", nickname: "用户" },
      message: [{ type: "text", data: { text: content } }],
      post_type: "message",
      message_type: "group"
    };
    
    // 调用现有群消息处理逻辑
    handleGroupMessage(fakeData, currentConfig);
    
  } else if (msg.type === "group_add") {
    // 机器人被添加到群 - 记录group_openid，方便配置双模式映射
    addLog("success", `[官方] 机器人被添加到群！group_openid = ${msg.group_openid}`);
    addLog("info", `[官方] 完整msg: ${JSON.stringify(msg)}`);
    addLog("info", `[官方] msg.group_id: ${msg.group_id}, msg.group_openid: ${msg.group_openid}`);
    addLog("info", `[官方] 请在双模式配置中添加群ID映射：QQ群号 -> ${msg.group_openid}`);
    // 发送到渲染进程
    if (mainWindow) mainWindow.webContents.send("official:group_added", { group_openid: msg.group_openid, time: new Date().toLocaleString("zh-CN") });
    
  } else if (msg.type === "c2c") {
    // 单聊消息
    addLog("info", `[官方-单聊] 用户${msg.user_id}: ${msg.message}`);
  }
}

async function sendOfficialGroupMessage(groupId, content, msgId = null) {
  try {
    const result = await officialBot.sendOfficialGroupMessage(groupId, content, msgId);
    addLog("success", `[官方] 发送群消息成功: ${groupId}`);
    return result;
  } catch (e) {
    addLog("error", `[官方] 发送群消息失败: ${e.message}`);
    throw e;
  }
}

function updateOfficialStatus(status) {
  officialStatus = status;
  botStatus = status; // 同步到全局状态，让运行控制台能显示
  if (mainWindow) {
    mainWindow.webContents.send("official:status", { status: status });
    mainWindow.webContents.send("bot:status-update", { status: status, botQQ: null });
  }
}

// ==================== OneBot WebSocket 连接 ====================
function connectBot() {
  manualDisconnect = false; // 重置主动断开标志
  reconnectAttempts = 0;
  if (ws) { try { ws.close(); } catch (e) {} ws = null; }
  clearTimeout(reconnectTimer);
  clearInterval(heartbeatTimer);

  const url = currentConfig.connection.wsUrl;
  if (!url) {
    addLog("error", "请先配置 OneBot WebSocket 地址");
    updateStatus("error");
    return;
  }

  updateStatus("connecting");
  addLog("info", `正在连接 OneBot: ${url}`);

  try {
    const wsOptions = currentConfig.connection.accessToken
      ? { headers: { Authorization: `Bearer ${currentConfig.connection.accessToken}` } }
      : undefined;
    ws = new WebSocket(url, wsOptions);
    // 10秒连接超时
    connectTimeoutTimer = setTimeout(() => {
      if (ws && ws.readyState !== WebSocket.OPEN) {
        addLog("error", "连接超时，10秒内未建立连接");
        try { ws.close(); } catch (e) {}
      }
    }, 10000);
  } catch (e) {
    addLog("error", `连接失败: ${e.message}`);
    updateStatus("error");
    scheduleReconnect();
    return;
  }

  ws.onopen = () => {
    clearTimeout(connectTimeoutTimer);
    reconnectAttempts = 0;
    addLog("success", "已连接到 OneBot 服务");
    updateStatus("connected");
    heartbeatTimer = setInterval(() => {
      sendAction("get_status", {});
    }, 30000);
    startWebsiteMonitor();
  };

  ws.onmessage = (event) => {
    try { handleOneBotEvent(JSON.parse(event.data)); } catch (e) { addLog("warn", `消息解析失败: ${e.message}`); }
  };

  ws.onerror = () => {
    addLog("error", "连接错误，请确认 OneBot 服务已启动且 WebSocket 已开启");
  };

  ws.onclose = () => {
    addLog("warn", "与 OneBot 的连接已断开");
    clearInterval(heartbeatTimer);
    stopWebsiteMonitor();
    ws = null; botQQ = null;
    updateStatus("disconnected");
    // 主动断开时不自动重连
    if (!manualDisconnect && currentConfig.connection.autoReconnect) {
      scheduleReconnect();
    } else if (manualDisconnect) {
      addLog("info", "主动断开，不自动重连");
    }
  };
}

function disconnectBot() {
  manualDisconnect = true; // 标记为主动断开，避免自动重连
  clearTimeout(reconnectTimer);
  clearInterval(heartbeatTimer);
  stopWebsiteMonitor();
  if (ws) { try { ws.close(); } catch (e) {} ws = null; }
  botQQ = null;
  updateStatus("disconnected");
  addLog("info", "已断开连接");
}

function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  reconnectAttempts++
  // 检查是否超过最大重连次数
  const _maxReconnect = (currentConfig && currentConfig.system && currentConfig.system.reconnectLimit) || 10;
  if (reconnectAttempts > _maxReconnect) {
    addLog("warn", "已超过最大重连次数(" + _maxReconnect + ")，停止自动重连，请手动连接");
    botStatus = "disconnected";
    return;
  }
  addLog("info", "自动重连第" + reconnectAttempts + "/" + _maxReconnect + "次");;
  const delay = Math.min(5000 * Math.pow(2, reconnectAttempts - 1), 60000);
  const seconds = Math.round(delay / 1000);
  addLog("info", `${seconds}秒后自动重连（第${reconnectAttempts}次尝试）...`);
  reconnectTimer = setTimeout(() => {
    if (currentConfig.connection.autoReconnect) connectBot();
  }, delay);
}

// ==================== OneBot 动作发送 ====================
function sendAction(action, params, callback) {
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    if (callback) callback({ error: "未连接" });
    return null;
  }
  const echo = `action_${++actionEchoCounter}`;
  const payload = { action, params, echo };
  if (callback) {
    actionCallbacks.set(echo, callback);
    // 15秒超时自动清理，防止内存泄漏
    setTimeout(() => {
      if (actionCallbacks.has(echo)) {
        actionCallbacks.delete(echo);
        callback({ error: "请求超时" });
      }
    }, 15000);
  }
  try { ws.send(JSON.stringify(payload)); } catch (e) {
    actionCallbacks.delete(echo);
    if (callback) callback({ error: e.message });
  }
  return echo;
}


function sendGroupMessage(groupId, message) {
  const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
  
  // 双模式：用官方API发送（需要群ID映射）
  if (dualEnabled) {
    let text = "";
    let imageUrl = "";
    if (typeof message === "string") {
      text = message;
    } else if (Array.isArray(message)) {
      message.forEach((seg) => {
        if (seg.type === "text" && seg.data && seg.data.text) {
          text += seg.data.text;
        } else if (seg.type === "image" && seg.data && seg.data.file) {
          imageUrl = seg.data.file; // 图片URL或本地路径
        }
      });
    }
    
    if (text.length > 4500) {
      text = text.slice(0, 4500) + "\n\n...（内容过长已截断）";
    }
    
    // 查找 group_openid
    const groupIdMap = (currentConfig.dualMode && currentConfig.dualMode.groupIdMap) || {};
    const groupOpenId = groupIdMap[String(groupId)];
    
    if (groupOpenId) {
      // 如果有图片，用官方API发送文本+图片
      if (imageUrl) {
        officialBot.sendOfficialGroupMessageWithImage(groupOpenId, text, imageUrl, null).then(() => {
          addLog("success", `[双模式] 官方发送成功（含图片） 群${groupId}`);
        }).catch((e) => {
          addLog("warn", `[双模式-官方发送] 失败 群${groupId}: ${e.message}`);
          addLog("info", `[双模式] 自动切换到OneBot发送 群${groupId}`);
          // fallback 到 OneBot 发送，保证消息不丢
          sendAction("send_group_msg", { group_id: groupId, message: message }, (resp) => {
            if (resp && resp.error) addLog("warn", `[双模式-OneBot发送] 也失败 群${groupId}: ${resp.error}`);
            else addLog("success", `[双模式] OneBot发送成功 群${groupId}`);
          });
        });
      } else {
        // 纯文本，用官方API发送
        officialBot.sendOfficialGroupMessage(groupOpenId, text, null).then(() => {
          addLog("success", `[双模式] 官方发送成功 群${groupId}`);
        }).catch((e) => {
          addLog("warn", `[双模式-官方发送] 失败 群${groupId}: ${e.message}`);
          addLog("info", `[双模式] 自动切换到OneBot发送 群${groupId}`);
          // fallback 到 OneBot 发送
          sendAction("send_group_msg", { group_id: groupId, message: text }, (resp) => {
            if (resp && resp.error) addLog("warn", `[双模式-OneBot发送] 也失败 群${groupId}: ${resp.error}`);
            else addLog("success", `[双模式] OneBot发送成功 群${groupId}`);
          });
        });
      }
    } else {
      addLog("warn", `[双模式] 群${groupId}未配置group_openid映射，改用OneBot发送`);
      // fallback 到 OneBot 发送
      sendAction("send_group_msg", { group_id: groupId, message: message }, (resp) => {
        if (resp && resp.error) addLog("warn", `发消息失败 群${groupId}: ${resp.error}`);
      });
    }
    return;
  }
  
  // 官方单模式
  if (officialMode) {
    let text = "";
    if (typeof message === "string") {
      text = message;
    } else if (Array.isArray(message)) {
      message.forEach((seg) => {
        if (seg.type === "text" && seg.data && seg.data.text) {
          text += seg.data.text;
        }
      });
    }
    if (text.length > 4500) {
      text = text.slice(0, 4500) + "\n\n...（内容过长已截断）";
    }
    const msgId = officialLastMsgId || null;
    officialBot.sendOfficialGroupMessage(groupId, text, msgId).catch((e) => {
      addLog("warn", `[官方] 发消息失败 群${groupId}: ${e.message}`);
    });
    return;
  }
  
  // OneBot单模式
  let msg = message;
  if (typeof msg === "string") {
    if (msg.length > 4500) {
      msg = msg.slice(0, 4500) + "\n\n...（内容过长已截断）";
    }
  }
  sendAction("send_group_msg", { group_id: groupId, message: msg }, (resp) => {
    if (resp && resp.error) addLog("warn", `发消息失败 群${groupId}: ${resp.error}`);
  });
}

// ==================== 网站对接模块 ====================
function fetchLatestPosts(count = 5) {
  const baseUrl = currentConfig.website.url.replace(/\/$/, "");
  const apiUrl = `${baseUrl}/wp-json/wp/v2/posts?per_page=${count}&_embed&_fields=id,title,link,date,excerpt,content,featured_media`;
  return httpGet(apiUrl, 10000);
}

// 从HTML内容中提取第一张图片URL
function extractFirstImage(html) {
  if (!html) return "";
  const match = html.match(/<img[^>]+src=["']([^"']+)["']/i);
  return match ? match[1] : "";
}

// CQ码特殊字符转义
function escapeCqCode(str) {
  if (!str) return "";
  return str.replace(/&/g, "&amp;").replace(/\[/g, "&#91;").replace(/\]/g, "&#93;").replace(/,/g, "&#44;");
}

async function checkWebsiteAndPush() {
  if (!currentConfig.website.enabled) return;
  if (!currentConfig.website.pushGroups || currentConfig.website.pushGroups.length === 0) return;
  try {
    const posts = await fetchLatestPosts(20);
    if (!Array.isArray(posts) || posts.length === 0) return;
    const latest = posts[0];
    const lastId = currentConfig.website.lastPostId || 0;
    if (lastId === 0) {
      currentConfig.website.lastPostId = latest.id;
      saveConfig();
      addLog("info", `[网站推送] 首次记录最新文章ID: ${latest.id}`);
      return;
    }
    // 找出所有比上次记录新的文章，按时间正序推送
    const newPosts = posts.filter(p => p.id > lastId).reverse();
    for (let i = 0; i < newPosts.length; i++) {
      const post = newPosts[i];
      setTimeout(() => { pushPostToGroups(post); }, i * 3000);
      currentConfig.website.lastPostId = post.id;
    }
    if (newPosts.length > 0) {
      saveConfig();
      addLog("success", `[网站推送] 推送了 ${newPosts.length} 篇新文章`);
    }
  } catch (e) {
    addLog("warn", `[网站推送] 检查失败: ${e.message}`);
  }
}

async function pushPostToGroups(post) {
  const title = (post.title && post.title.rendered) ? post.title.rendered.replace(/<[^>]+>/g, "") : "新文章";
  const link = post.link || "";
  // 提取文章摘要作为描述
  let description = "";
  if (post.excerpt && post.excerpt.rendered) {
    description = post.excerpt.rendered.replace(/<[^>]+>/g, "").trim();
    if (description.length > 100) description = description.slice(0, 100) + "...";
  }
  // 提取特色图片URL
  let imageUrl = "";
  if (post._embedded && post._embedded["wp:featuredmedia"] && post._embedded["wp:featuredmedia"][0]) {
    imageUrl = post._embedded["wp:featuredmedia"][0].source_url || "";
  }
  // 如果没有特色图片，从文章内容中提取第一张图片
  if (!imageUrl && post.content && post.content.rendered) {
    imageUrl = extractFirstImage(post.content.rendered);
  }
  const template = currentConfig.website.pushTemplate || "{title}\n{link}";
  let textMsg = template.replace(/{title}/g, title).replace(/{link}/g, link);
  
  const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
  const groupIdMap = (currentConfig.dualMode && currentConfig.dualMode.groupIdMap) || {};

  for (const gid of currentConfig.website.pushGroups) {
    if (isFeatureEnabled(gid, "websitePush")) {
      // 双模式：使用 Embed 卡片发送
      if (dualEnabled) {
        const groupOpenId = groupIdMap[String(gid)];
        if (groupOpenId) {
          try {
            await officialBot.sendOfficialArticleCard(groupOpenId, title, description, imageUrl, link);
            addLog("success", `[网站推送] 官方卡片发送成功 群${gid}: ${title}`);
          } catch (e) {
            addLog("warn", `[网站推送] 官方卡片发送失败 群${gid}: ${e.message}`);
            addLog("info", `[网站推送] 自动切换到OneBot发送 群${gid}`);
            // fallback 到 OneBot 发送
            if (imageUrl) {
              const messageSegments = [
                { type: "text", data: { text: textMsg + "\n\n" } },
                { type: "image", data: { file: imageUrl } }
              ];
              sendGroupMessage(gid, messageSegments);
            } else {
              sendGroupMessage(gid, textMsg);
            }
          }
        } else {
          addLog("warn", `[网站推送] 群${gid}未配置group_openid映射，改用OneBot发送`);
          if (imageUrl) {
            const messageSegments = [
              { type: "text", data: { text: textMsg + "\n\n" } },
              { type: "image", data: { file: imageUrl } }
            ];
            sendGroupMessage(gid, messageSegments);
          } else {
            sendGroupMessage(gid, textMsg);
          }
        }
      } else {
        // 非双模式：保持原来的逻辑
        if (imageUrl) {
          const messageSegments = [
            { type: "text", data: { text: textMsg + "\n\n" } },
            { type: "image", data: { file: imageUrl } }
          ];
          sendGroupMessage(gid, messageSegments);
        } else {
          sendGroupMessage(gid, textMsg);
        }
      }
    }
  }
}

function startWebsiteMonitor() {
  stopWebsiteMonitor();
  if (!currentConfig.website.enabled) return;
  const interval = Math.max(1, currentConfig.website.checkInterval || 5) * 60 * 1000;
  websiteMonitorTimer = setInterval(checkWebsiteAndPush, interval);
  addLog("info", `[网站推送] 监控已启动，每 ${currentConfig.website.checkInterval} 分钟检查一次`);
  // 启动后延迟10秒先检查一次
  websiteInitialCheckTimer = setTimeout(checkWebsiteAndPush, 10000);
}

function stopWebsiteMonitor() {
  if (websiteMonitorTimer) {
    clearInterval(websiteMonitorTimer);
    websiteMonitorTimer = null;
  }
  if (websiteInitialCheckTimer) {
    clearTimeout(websiteInitialCheckTimer);
    websiteInitialCheckTimer = null;
  }
}

// ==================== 网站查询功能（搜索/随机/分类/详情）====================
function wpApiRequest(path) {
  const baseUrl = currentConfig.website.url.replace(/\/$/, "");
  const url = `${baseUrl}/wp-json/wp/v2/${path}`;
  return httpGet(url, 10000);
}

async function searchPosts(keyword, count = 5) {
  const posts = await wpApiRequest(`posts?search=${encodeURIComponent(keyword)}&per_page=${count}&_fields=id,title,link,excerpt,date`);
  return Array.isArray(posts) ? posts : [];
}

async function getRandomPost() {
  // 获取最近20篇然后随机选一篇（WordPress原生不支持随机排序）
  const posts = await wpApiRequest("posts?per_page=20&_fields=id,title,link,excerpt,date");
  if (!Array.isArray(posts) || posts.length === 0) return null;
  return posts[Math.floor(Math.random() * posts.length)];
}

async function getCategories() {
  const cats = await wpApiRequest("categories?per_page=100&_fields=id,name,count");
  return Array.isArray(cats) ? cats : [];
}

async function getPostsByCategory(catName, count = 8) {
  const cats = await getCategories();
  const matched = cats.find((c) => c.name.includes(catName) || catName.includes(c.name));
  if (!matched) return { category: null, posts: [] };
  const posts = await wpApiRequest(`posts?categories=${matched.id}&per_page=${count}&_fields=id,title,link,date`);
  return { category: matched, posts: Array.isArray(posts) ? posts : [] };
}

async function getPostDetail(postId) {
  const post = await wpApiRequest(`posts/${postId}?_embed`);
  return post;
}

async function getTags() {
  const tags = await wpApiRequest("tags?per_page=100&_fields=id,name,count");
  return Array.isArray(tags) ? tags : [];
}

async function getPostsByTag(tagName, count = 8) {
  const tags = await getTags();
  const matched = tags.find((t) => t.name.includes(tagName) || tagName.includes(t.name));
  if (!matched) return { tag: null, posts: [] };
  const posts = await wpApiRequest(`posts?tags=${matched.id}&per_page=${count}&_fields=id,title,link,date`);
  return { tag: matched, posts: Array.isArray(posts) ? posts : [] };
}

function stripHtml(html) {
  return (html || "").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
}

function formatPostBrief(post) {
  const title = stripHtml(post.title?.rendered || "无标题");
  const link = post.link || "";
  const excerpt = stripHtml(post.excerpt?.rendered || "").slice(0, 80);
  let msg = `🎮 ${title}\n`;
  if (excerpt) msg += `${excerpt}...\n`;
  msg += `👉 ${link}`;
  return msg;
}

// ==================== Warframe 国际服模块 ====================
const WF_API = "https://api.warframestat.us/";
let WF_PLATFORM = "pc";

// 官方 API（替代已403的 warframestat.us）
const WF_OFFICIAL_API = "https://api.warframe.com/cdn/worldState.php";
let wfOfficialCache = null;
let wfOfficialCacheTime = 0;
const WF_OFFICIAL_CACHE_TTL = 20000;

async function wfOfficialGet() {
  const now = Date.now();
  if (wfOfficialCache && (now - wfOfficialCacheTime) < WF_OFFICIAL_CACHE_TTL) {
    return wfOfficialCache;
  }
  const headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json"
  };
  const data = await httpGet(WF_OFFICIAL_API, 15000, headers);
  wfOfficialCache = data;
  wfOfficialCacheTime = now;
  return data;
}

// 从官方API提取时间（毫秒时间戳字符串）
function wfOfficialTime(field) {
  if (!field) return null;
  if (field.$date && field.$date.$numberLong) {
    return parseInt(field.$date.$numberLong, 10);
  }
  return null;
}

// 官方API中英文映射表
const WF_BOSS_MAP = {
  "SORTIE_BOSS_RUK": "莱希·克里尔中尉",
  "SORTIE_BOSS_VAYHEK": "瓦黑克议员",
  "SORTIE_BOSS_SARGAS_RUK": "萨尔加斯·鲁克将军",
  "SORTIE_BOSS_TYL_REGOR": "泰尔·雷戈尔",
  "SORTIE_BOSS_NEF_ANYO": "内夫·安尤",
  "SORTIE_BOSS_AMULS": "阿姆鲁斯",
  "SORTIE_BOSS_KELA_DE_THAYM": "凯拉·德·塞姆",
  "SORTIE_BOSS_HYENA": "鬣狗群",
  "SORTIE_BOSS_LECH_KRIL": "莱希·克里尔中尉",
  "SORTIE_BOSS_VOR": "沃尔上尉",
  "SORTIE_BOSS_PHORID": "恐惧",
  "SORTIE_BOSS_MUTALIST_ALAD_V": "变异化阿拉德五世",
  "SORTIE_BOSS_ALAD_V": "阿拉德五世",
  "SORTIE_BOSS_NATAH": "纳塔",
  "SORTIE_BOSS_TESHIN": "泰辛",
  "SORTIE_BOSS_ERRA": "埃拉",
  "SORTIE_BOSS_BALLAS": "巴拉斯",
  "SORTIE_BOSS_HUNHOW": "浑豪"
};

const WF_MISSION_TYPE_MAP = {
  "MT_ASSASSINATION": "刺杀",
  "MT_EXTERMINATION": "歼灭",
  "MT_SURVIVAL": "生存",
  "MT_DEFENSE": "防御",
  "MT_MOBILE_DEFENSE": "移动防御",
  "MT_CAPTURE": "捕获",
  "MT_INTEL": "间谍",
  "MT_RESCUE": "救援",
  "MT_SABOTAGE": "破坏",
  "MT_EXCAVATION": "挖掘",
  "MT_INTERCEPTION": "拦截",
  "MT_DEFECTION": "叛逃",
  "MT_DISRUPTION": "中断",
  "MT_LANDSCAPE": "开放世界",
  "MT_HIVE": "母巢",
  "MT_ARENA": "竞技场",
  "MT_RUSH": "冲刺",
  "MT_ASSAULT": "突击",
  "MT_SKIRMISH": "前哨战",
  "MT_VOLATILE": " volatile",
  "MT_ORPHIX": "奥菲克斯",
  "MT_CROSSFIRE": "交火"
};

const WF_SORTIE_MODIFIER_MAP = {
  "SORTIE_MODIFIER_LOW_ENERGY": "能量降低",
  "SORTIE_MODIFIER_EXIMUS": "卓越者敌人",
  "SORTIE_MODIFIER_HAZARD_MAGNETIC": "磁力危害",
  "SORTIE_MODIFIER_HAZARD_FIRE": "火焰危害",
  "SORTIE_MODIFIER_HAZARD_COLD": "冰冻危害",
  "SORTIE_MODIFIER_HAZARD_TOXIN": "毒素危害",
  "SORTIE_MODIFIER_HAZARD_RADIATION": "辐射危害",
  "SORTIE_MODIFIER_HAZARD_CORROSIVE": "腐蚀危害",
  "SORTIE_MODIFIER_HAZARD_VIRAL": "病毒危害",
  "SORTIE_MODIFIER_HAZARD_BLAST": "爆炸危害",
  "SORTIE_MODIFIER_HAZARD_GAS": "毒气危害",
  "SORTIE_MODIFIER_HAZARD_ELECTRICITY": "电击危害",
  "SORTIE_MODIFIER_NO_SHIELD": "护盾恢复降低",
  "SORTIE_MODIFIER_NO_DAMAGE": "伤害降低",
  "SORTIE_MODIFIER_ARMOR": "敌人护甲增强",
  "SORTIE_MODIFIER_DAMAGE": "敌人伤害增强",
  "SORTIE_MODIFIER_SHIELD": "敌人护盾增强",
  "SORTIE_MODIFIER_HEALTH": "敌人生命增强",
  "SORTIE_MODIFIER_SNIPER_ONLY": "仅狙击枪",
  "SORTIE_MODIFIER_SHOTGUN_ONLY": "仅霰弹枪",
  "SORTIE_MODIFIER_BOW_ONLY": "仅弓",
  "SORTIE_MODIFIER_MELEE_ONLY": "仅近战",
  "SORTIE_MODIFIER_PISTOL_ONLY": "仅副武器",
  "SORTIE_MODIFIER_RIFLE_ONLY": "仅主武器",
  "SORTIE_MODIFIER_AUGMENTED_ENEMIES": "强化敌人",
  "SORTIE_MODIFIER_REDUCED_ACCURACY": "精准度降低"
};

const WF_FACTION_MAP = {
  "FC_GRINEER": "Grineer",
  "FC_CORPUS": "Corpus",
  "FC_INFESTATION": "Infested",
  "FC_SENTIENT": "Sentient",
  "FC_TENNO": "Tenno",
  "FC_STALKER": "Stalker",
  "FC_NARMER": "Narmer"
};

const WF_VOID_TIER_MAP = {
  "VoidT1": "古纪",
  "VoidT2": "前纪",
  "VoidT3": "中纪",
  "VoidT4": "后纪",
  "VoidT5": "安魂"
};

// 节点中文映射（常用节点+HUB）
const WF_NODE_MAP = {
  // 中继站/HUB
  "EarthHUB": "地球·希图斯",
  "VenusHUB": "金星·福尔图娜",
  "DeimosHUB": "火卫二·殁世幽都",
  "MercuryHUB": "水星中继站",
  "MarsHUB": "火星中继站",
  "JupiterHUB": "木星中继站",
  "SaturnHUB": "土星中继站",
  "UranusHUB": "天王星中继站",
  "NeptuneHUB": "海王星中继站",
  "PlutoHUB": "冥王星中继站",
  "ErisHUB": "阋神星中继站",
  "SednaHUB": "赛德娜中继站",
  "CeresHUB": "谷神星中继站",
  "EuropaHUB": "欧罗巴中继站",
  "PhobosHUB": "火卫一中继站",
  // 地球
  "SolNode228": "地球·夜灵平野",
  "SolNode187": "地球·生存",
  "SolNode195": "地球·入侵节点",
  "SolNode226": "地球·间谍",
  "SolNode32": "地球·刺杀",
  // 水星
  "SolNode100": "水星·Tolstoj",
  "SolNode101": "水星·Elion",
  "SolNode102": "水星·Apollodorus",
  // 金星
  "SolNode200": "金星·V Prime",
  "SolNode201": "金星·Cytherean",
  "SolNode202": "金星·Ishtar",
  // 火星
  "SolNode300": "火星·Ara",
  "SolNode301": "火星·Spear",
  "SolNode302": "火星·Hellas",
  "SolNode303": "火星·Augustus",
  // 谷神星
  "SolNode400": "谷神星·Gabii",
  "SolNode401": "谷神星·Draco",
  "SolNode402": "谷神星·Nuovo",
  // 木星
  "SolNode500": "木星·Cameria",
  "SolNode501": "木星·Sinai",
  "SolNode502": "木星·Themisto",
  "SolNode503": "木星·Elara",
  "SolNode504": "木星·Io",
  // 欧罗巴
  "SolNode600": "欧罗巴·Cholistan",
  "SolNode601": "欧罗巴·Nanus",
  "SolNode602": "欧罗巴·Yursa",
  // 土星
  "SolNode700": "土星·Helene",
  "SolNode701": "土星·Mimas",
  "SolNode702": "土星·Tethys",
  "SolNode703": "土星·Enceladus",
  // 天王星
  "SolNode800": "天王星·Piscinas",
  "SolNode801": "天王星·Despina",
  "SolNode802": "天王星·Thalassa",
  // 海王星
  "SolNode900": "海王星·Salacia",
  "SolNode901": "海王星·Hades",
  "SolNode902": "海王星·Proteus",
  // 冥王星
  "SolNode1000": "冥王星·Hydra",
  "SolNode1001": "冥王星·Nix",
  "SolNode1002": "冥王星·Charon",
  // 阋神星
  "SolNode1100": "阋神星·Zabiela",
  "SolNode1101": "阋神星·Berehynia",
  "SolNode1102": "阋神星·Xini",
  // 赛德娜
  "SolNode1200": "赛德娜·Adaro",
  "SolNode1201": "赛德娜·Kappa",
  "SolNode1202": "赛德娜·Hydron",
  "SolNode1203": "赛德娜·Vodyanoi",
  "SolNode1204": "赛德娜·Merrow",
  // 火卫一
  "SolNode1300": "火卫一·Roche",
  "SolNode1301": "火卫一·Trinculo",
  "SolNode1302": "火卫一·Oberon",
  // 航道星舰节点
  "CrewBattleNode518": "航道星舰·虚空风暴T1",
  "CrewBattleNode515": "航道星舰·虚空风暴T1",
  "CrewBattleNode524": "航道星舰·虚空风暴T3",
  "CrewBattleNode534": "航道星舰·虚空风暴T2",
  "CrewBattleNode531": "航道星舰·虚空风暴T4",
  "CrewBattleNode555": "航道星舰·虚空风暴T4"
};

// 常见物品中文映射
const WF_ITEM_MAP = {
  // 武器部件
  "SnipetronVandalStock": "狙击特昂破坏者枪托",
  "SnipetronVandalBarrel": "狙击特昂破坏者枪管",
  "SnipetronVandalReceiver": "狙击特昂破坏者枪机",
  "LatronWraithBarrel": "拉特昂亡魂枪管",
  "LatronWraithStock": "拉特昂亡魂枪托",
  "LatronWraithReceiver": "拉特昂亡魂枪机",
  "BratonVandalStock": "布拉玛破坏者枪托",
  "BratonVandalBarrel": "布拉玛破坏者枪管",
  "BratonVandalReceiver": "布拉玛破坏者枪机",
  // MOD
  "WaterFightBucks": "夏日活动币",
  // 常见资源
  "Neurodes": "神经传感器",
  "NeuralSensors": "神经传感器",
  "AlloyPlate": "合金板",
  "Circuits": "电路",
  "ControlModule": "控制模块",
  "Ferrite": "铁氧体",
  "FerritePlate": "铁氧体",
  "Gallium": "镓",
  "Morphics": "生物质",
  "NanoSpores": "纳米孢子",
  "OrokinCell": "奥罗金电池",
  "Oxium": "氧金属",
  "Plastids": "非晶态合金",
  "PolymerBundle": "聚合杆",
  "Rubedo": "红化结晶",
  "Salvage": "废旧金属",
  "Tellurium": "碲",
  "ArgonCrystal": "氩结晶",
  "Cryotic": "冰晶石",
  "MutalistMass": "异变感染体",
  "NavCoordinate": "导航坐标",
  "Fieldron": "场力石",
  "DetoniteInjector": "爆燃安瓿",
  "MutagenMass": "诱变剂",
  // 杜卡德币相关
  "Ducats": "杜卡德金币"
};

// 节点名转中文
function wfNodeName(nodeId) {
  if (!nodeId) return "未知";
  return WF_NODE_MAP[nodeId] || nodeId;
}

// 物品名转中文（从路径提取最后一段后映射）
function wfItemName(itemType) {
  if (!itemType) return "未知";
  const shortName = itemType.split("/").pop();
  return WF_ITEM_MAP[shortName] || shortName;
}

function wfGet(endpoint) {
  const cacheKey = `wf:${WF_PLATFORM}:${endpoint}`;
  const cached = cacheGet(cacheKey);
  if (cached) return Promise.resolve(cached);
  const url = `${WF_API}${WF_PLATFORM}/${endpoint}`;
  const wfHeaders = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Language": "zh"
  };
  return httpGet(url, 10000, wfHeaders).then((data) => {
    cacheSet(cacheKey, data, 20000);
    return data;
  });
}

function wfTime(iso) {
  if (!iso) return "未知";
  const diff = new Date(iso).getTime() - Date.now();
  if (diff <= 0) return "已结束";
  const h = Math.floor(diff / 3600000), m = Math.floor((diff % 3600000) / 60000), s = Math.floor((diff % 60000) / 1000);
  if (h > 0) return h + "小时" + m + "分";
  if (m > 0) return m + "分" + s + "秒";
  return s + "秒";
}

// 突击
// 从毫秒时间戳计算剩余时间
function wfTimeMs(ts) {
  if (!ts) return "未知";
  const diff = ts - Date.now();
  if (diff <= 0) return "已结束";
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  if (h > 0) return `${h}小时${m}分`;
  if (m > 0) return `${m}分${s}秒`;
  return `${s}秒`;
}

async function wfSortie() {
  try {
    const ws = await wfOfficialGet();
    const sortie = ws.Sorties;
    if (!sortie) return "暂无突击数据";
    const expiry = wfOfficialTime(sortie.Expiry);
    const boss = WF_BOSS_MAP[sortie.Boss] || sortie.Boss || "未知";
    let msg = `⚔️ 今日突击（剩余${wfTimeMs(expiry)}）\n`;
    msg += `BOSS：${boss}\n\n`;
    if (sortie.Variants && sortie.Variants.length > 0) {
      sortie.Variants.forEach((v, i) => {
        const missionType = WF_MISSION_TYPE_MAP[v.missionType] || v.missionType || "未知";
        const modifier = WF_SORTIE_MODIFIER_MAP[v.modifierType] || v.modifierType || "未知";
        msg += `${i + 1}. ${missionType}｜${modifier}\n   节点：${wfNodeName(v.node)}\n\n`;
      });
    }
    return msg.trim();
  } catch (e) {
    return "突击数据获取失败：" + e.message;
  }
}

// 虚空商人
async function wfVoidTrader() {
  try {
    const ws = await wfOfficialGet();
    const traders = ws.VoidTraders;
    if (!traders || traders.length === 0) return "暂无虚空商人数据";
    const trader = traders[0];
    const activation = wfOfficialTime(trader.Activation);
    const expiry = wfOfficialTime(trader.Expiry);
    const now = Date.now();
    const node = trader.Node || "未知";
    const character = trader.Character || "Baro'Ki Teel";
    if (now >= activation && now <= expiry) {
      let msg = `🛒 ${character}已到来（剩余${wfTimeMs(expiry)}）\n`;
      msg += `地点：${node}\n\n`;
      msg += "（官方API不提供售卖物品列表，请游戏内查看）";
      return msg;
    } else {
      return `🛒 ${character}未到来\n下次到达：${new Date(activation).toLocaleString("zh-CN")}\n地点：${node}\n距离到来：${wfTimeMs(activation)}`;
    }
  } catch (e) {
    return "虚空商人数据获取失败：" + e.message;
  }
}

// 仲裁
async function wfArbitration() {
  return "🏆 仲裁功能维护中\n（官方API暂不提供仲裁数据，后续版本恢复）";
}

// 虚空风暴（官方API仅提供虚空风暴，普通裂缝暂不可用）
async function wfFissures() {
  try {
    const ws = await wfOfficialGet();
    const storms = ws.VoidStorms;
    if (!Array.isArray(storms) || storms.length === 0) return "暂无虚空风暴数据";
    let msg = `🌌 当前虚空风暴（共${storms.length}个）\n\n`;
    storms.slice(0, 10).forEach((s) => {
      const tier = WF_VOID_TIER_MAP[s.ActiveMissionTier] || s.ActiveMissionTier || "未知";
      const expiry = wfOfficialTime(s.Expiry);
      msg += `[${tier}] ${wfNodeName(s.Node)}\n  剩余：${wfTimeMs(expiry)}\n`;
    });
    if (storms.length > 10) msg += `\n...等共${storms.length}个`;
    msg += "\n（注：官方API暂不提供普通虚空裂缝，仅显示航道星舰虚空风暴）";
    return msg.trim();
  } catch (e) {
    return "虚空风暴数据获取失败：" + e.message;
  }
}

// 开放世界通用格式化
function wfOpenWorld(name, data, bountyKey) {
  if (!data) return `暂无${name}数据`;
  const isDay = data.isDay !== undefined ? data.isDay : data.state === "day";
  const timeState = data.isDay !== undefined ? (isDay ? "白天" : "夜晚") : (data.state || "未知");
  let msg = `🗺️ ${name}\n当前：${timeState}｜剩余${wfTime(data.expiry)}\n\n`;
  const bounties = data[bountyKey] || data.bounties;
  if (Array.isArray(bounties) && bounties.length > 0) {
    msg += "当前赏金：\n";
    bounties.forEach((b, i) => {
      const levels = b.enemyLevels ? `${b.enemyLevels[0]}-${b.enemyLevels[1]}` : "未知";
      const type = b.type ? b.type.replace(/^.*\//, "") : "赏金";
      msg += `${i + 1}. [${levels}级] ${type}\n`;
      if (b.rewardPool && Array.isArray(b.rewardPool)) {
        msg += `   奖励：${b.rewardPool.slice(0, 3).join("、")}${b.rewardPool.length > 3 ? "..." : ""}\n`;
      }
    });
  } else {
    msg += "暂无赏金数据";
  }
  return msg.trim();
}

// 入侵
async function wfInvasions() {
  try {
    const ws = await wfOfficialGet();
    const invasions = ws.Invasions;
    if (!Array.isArray(invasions) || invasions.length === 0) return "暂无入侵数据";
    const active = invasions.filter((i) => !i.Completed);
    if (active.length === 0) return "暂无进行中的入侵";
    let msg = `⚔️ 进行中的入侵（共${active.length}个）\n\n`;
    active.slice(0, 8).forEach((inv) => {
      const att = WF_FACTION_MAP[inv.Faction] || inv.Faction || "未知";
      const def = WF_FACTION_MAP[inv.DefenderFaction] || inv.DefenderFaction || "未知";
      const count = inv.Count || 0;
      const goal = inv.Goal || 40000;
      const pct = Math.round(Math.abs(count) / goal * 100);
      const leading = count < 0 ? att : def;
      // 提取奖励物品名（从路径中提取最后一段后映射中文）
      const attReward = inv.AttackerReward && inv.AttackerReward.countedItems && inv.AttackerReward.countedItems.length > 0
        ? inv.AttackerReward.countedItems.map((r) => wfItemName(r.ItemType)).join("、")
        : "";
      const defReward = inv.DefenderReward && inv.DefenderReward.countedItems && inv.DefenderReward.countedItems.length > 0
        ? inv.DefenderReward.countedItems.map((r) => wfItemName(r.ItemType)).join("、")
        : "";
      msg += `📍 ${wfNodeName(inv.Node)}\n  ${att}(${attReward}) vs ${def}(${defReward})\n  进度：${pct}%｜${leading}领先\n\n`;
    });
    if (active.length > 8) msg += `...等共${active.length}个`;
    return msg.trim();
  } catch (e) {
    return "入侵数据获取失败：" + e.message;
  }
}

// 钢铁之路侵袭
async function wfSteelPath() {
  return "🛡️ 钢铁侵袭功能维护中\n（官方API暂不提供钢铁之路数据，后续版本恢复）";
}

// 警报
async function wfAlerts() {
  try {
    const ws = await wfOfficialGet();
    const alerts = ws.Alerts;
    if (!Array.isArray(alerts) || alerts.length === 0) return "暂无警报数据";
    const now = Date.now();
    const active = alerts.filter((a) => {
      const expiry = wfOfficialTime(a.Expiry);
      return expiry && expiry > now;
    });
    if (active.length === 0) return "暂无进行中的警报";
    let msg = `🚨 当前警报（共${active.length}个）\n\n`;
    active.slice(0, 6).forEach((a) => {
      const mi = a.MissionInfo || {};
      const missionType = WF_MISSION_TYPE_MAP[mi.missionType] || mi.missionType || "未知";
      const faction = WF_FACTION_MAP[mi.faction] || mi.faction || "未知";
      const expiry = wfOfficialTime(a.Expiry);
      const rewards = [];
      if (mi.missionReward && mi.missionReward.credits) rewards.push(`${mi.missionReward.credits}现金`);
      if (mi.missionReward && mi.missionReward.countedItems && mi.missionReward.countedItems.length > 0) {
        mi.missionReward.countedItems.forEach((r) => {
          const itemName = wfItemName(r.ItemType);
          if (itemName) rewards.push(`${r.ItemCount || 1}×${itemName}`);
        });
      }
      msg += `📍 ${wfNodeName(mi.location)}\n  ${missionType}｜${faction}\n  等级：${mi.minEnemyLevel || "?"}-${mi.maxEnemyLevel || "?"}\n`;
      if (rewards.length > 0) msg += `  奖励：${rewards.join("、")}\n`;
      msg += `  剩余：${wfTimeMs(expiry)}\n\n`;
    });
    if (active.length > 6) msg += `...等共${active.length}个`;
    return msg.trim();
  } catch (e) {
    return "警报数据获取失败：" + e.message;
  }
}

// 深层科研
async function wfDeepArchimedea() {
  return "🔬 深层科研功能维护中\n（官方API暂不提供深层科研数据，后续版本恢复）";
}

// 网件（时光科研）
async function wfNetracells() {
  return "⏳ 网件（时光科研）功能维护中\n（官方API暂不提供网件数据，后续版本恢复）";
}

// 平原时间
async function wfPlainsTime() {
  return "🌍 平原时间功能维护中\n（官方API暂不直接提供开放世界循环数据，需根据游戏时间规则计算，后续版本恢复）";
}

// Warframe Market v2 API - 物品列表缓存（24小时）
let marketItemsCache = null;
let marketItemsCacheTime = 0;
const MARKET_ITEMS_CACHE_TTL = 24 * 60 * 60 * 1000;

async function getMarketItems() {
  const now = Date.now();
  if (marketItemsCache && (now - marketItemsCacheTime) < MARKET_ITEMS_CACHE_TTL) {
    return marketItemsCache;
  }
  const marketHeaders = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Language": "zh-hans",
    "Platform": "pc"
  };
  const data = await httpGet("https://api.warframe.market/v2/items", 15000, marketHeaders);
  marketItemsCache = data && data.data ? data.data : [];
  marketItemsCacheTime = now;
  return marketItemsCache;
}

// Warframe Market 查询（v2 API）
async function wfMarket(keyword) {
  const cacheKey = `wfmarket:${keyword.toLowerCase()}`;
  const cached = cacheGet(cacheKey);
  if (cached) return cached;
  const marketHeaders = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Language": "zh-hans",
    "Platform": "pc"
  };
  try {
    // 1. 获取物品列表并本地搜索
    const items = await getMarketItems();
    const kw = keyword.toLowerCase();
    const matches = items.filter((item) => {
      const name = (item.itemName || item.name || item.slug || "").toLowerCase();
      return name.includes(kw);
    });
    if (matches.length === 0) return `未找到"${keyword}"相关物品`;
    // 取最匹配的（名称最短的优先）
    matches.sort((a, b) => {
      const na = (a.itemName || a.name || a.slug || "").length;
      const nb = (b.itemName || b.name || b.slug || "").length;
      return na - nb;
    });
    const item = matches[0];
    const itemName = item.itemName || item.name || item.slug;
    // 2. 查询最优订单
    const ordersUrl = `https://api.warframe.market/v2/orders/item/${item.slug}/top`;
    const ordersData = await httpGet(ordersUrl, 10000, marketHeaders);
    const orderData = ordersData && ordersData.data ? ordersData.data : {};
    const sellOrders = orderData.sell || [];
    const buyOrders = orderData.buy || [];
    let msg = `💰 Warframe Market\n物品：${itemName}\n\n`;
    if (sellOrders.length > 0) {
      const s = sellOrders[0];
      const sellerName = s.user ? (s.user.ingameName || s.user.name || "未知") : "未知";
      msg += `最低售价（在线）：${s.platinum}白金\n卖家：${sellerName}\n\n`;
    }
    if (buyOrders.length > 0) {
      const b = buyOrders[0];
      const buyerName = b.user ? (b.user.ingameName || b.user.name || "未知") : "未知";
      msg += `最高收购（在线）：${b.platinum}白金\n买家：${buyerName}\n\n`;
    }
    if (sellOrders.length > 1) msg += `其他售价：${sellOrders.slice(1, 4).map((o) => o.platinum).join("、")}白金\n`;
    if (buyOrders.length > 1) msg += `其他收购：${buyOrders.slice(1, 4).map((o) => o.platinum).join("、")}白金\n`;
    msg += `\n共${sellOrders.length + buyOrders.length}条在线订单（卖家${sellOrders.length}，买家${buyOrders.length}）`;
    cacheSet(cacheKey, msg, 30000);
    return msg;
  } catch (e) {
    return "Market 查询失败：" + e.message;
  }
}

// Warframe 指令分发
async function handleWarframeCommand(rawMsg, groupId) {
  const msg = rawMsg.trim();
  try {
    if (msg === "#突击") return await wfSortie();
    if (msg === "#虚空商人" || msg === "#baro" || msg === "#商人") return await wfVoidTrader();
    if (msg === "#仲裁") return await wfArbitration();
    if (msg === "#裂缝" || msg === "#虚空裂缝") return await wfFissures();
    if (msg === "#夜灵" || msg === "#夜灵平野") return "🗺️ 夜灵平野功能维护中\n（官方API暂不提供开放世界数据，后续版本恢复）";
    if (msg === "#奥布" || msg === "#奥布山谷") return "🗺️ 奥布山谷功能维护中\n（官方API暂不提供开放世界数据，后续版本恢复）";
    if (msg === "#魔胎" || msg === "#魔胎之境" || msg === "#火卫二") return "🗺️ 魔胎之境功能维护中\n（官方API暂不提供开放世界数据，后续版本恢复）";
    if (msg === "#入侵") return await wfInvasions();
    if (msg === "#钢铁侵袭" || msg === "#钢铁之路") return await wfSteelPath();
    if (msg === "#警报") return await wfAlerts();
    if (msg === "#深层科研" || msg === "#深岩") return await wfDeepArchimedea();
    if (msg === "#时光科研" || msg === "#网件") return await wfNetracells();
    if (msg === "#平原时间" || msg === "#时间") return await wfPlainsTime();
    if (msg.startsWith("#wm") || msg.startsWith("#market") || msg.startsWith("#市场")) {
      const kw = msg.replace(/^#(wm|market|市场)\s*/, "").trim();
      if (!kw) return "用法：#wm 物品名（如 #wm 狂战士）";
      return await wfMarket(kw);
    }
    if (msg === "#wf帮助" || msg === "#warframe") {
      return `🎮 Warframe 国际服指令\n\n` +
        `【可用】\n#突击 - 今日突击\n#虚空商人 - 商人状态\n#入侵 - 进行中的入侵\n#警报 - 当前警报\n#裂缝 - 虚空风暴列表\n#wm 物品名 - Market价格查询\n\n` +
        `【维护中】\n#仲裁、#平原时间、#夜灵、#奥布、#魔胎\n#深层科研、#时光科研、#钢铁侵袭\n（官方API暂不提供这些数据，后续版本恢复）\n\n` +
        `数据来源：api.warframe.com（官方）+ api.warframe.market/v2`;
    }
    return null;
  } catch (e) {
    return "Warframe 查询失败：" + e.message;
  }
}

// ==================== OneBot 事件处理 ====================
function handleOneBotEvent(data) {
  if (data.echo && actionCallbacks.has(data.echo)) {
    const cb = actionCallbacks.get(data.echo);
    actionCallbacks.delete(data.echo);
    cb(data);
    return;
  }

  if (data.post_type === "meta_event") {
    if (data.meta_event_type === "lifecycle" && data.sub_type === "connect") {
      sendAction("get_login_info", {}, (resp) => {
        if (resp && resp.data) {
          botQQ = resp.data.user_id;
          addLog("success", `机器人登录: ${resp.data.nickname} (${botQQ})`);
          updateStatus("connected");
        }
      });
    }
    return;
  }

  const cfg = currentConfig;

  if (data.post_type === "notice" && data.notice_type === "group_increase") {
    if (isFeatureEnabled(data.group_id, "welcome")) handleGroupIncrease(data, cfg);
    return;
  }

  if (data.post_type === "notice" && data.notice_type === "group_decrease") {
    if (isFeatureEnabled(data.group_id, "leaveNotice")) handleGroupDecrease(data, cfg);
    return;
  }

  if (data.post_type === "message" && data.message_type === "group") {
    handleGroupMessage(data, cfg);
    return;
  }
}

// ==================== 入群欢迎 ====================
function handleGroupIncrease(data, cfg) {
  if (botQQ && data.user_id === botQQ) return;
  const groupId = data.group_id;
  const userId = data.user_id;
  // 防重复：10秒内同一用户入群只欢迎一次
  const cacheKey = `${groupId}_${userId}`;
  if (welcomeCache.has(cacheKey)) return;
  welcomeCache.add(cacheKey);
  setTimeout(() => welcomeCache.delete(cacheKey), 10000);
  
  // 先从事件数据里尝试获取昵称
  let eventNick = "";
  if (data.sender && data.sender.nickname) eventNick = data.sender.nickname;
  else if (data.sender && data.sender.card) eventNick = data.sender.card;
  else if (data.nickname) eventNick = data.nickname;
  else if (data.card) eventNick = data.card;
  
  let welcomeSent = false;
  const sendWelcome = (nick, groupName) => {
    if (welcomeSent) return;
    welcomeSent = true;
    // 只显示昵称，不显示QQ号；如果获取不到昵称，显示"新成员"
    const displayName = nick && nick !== String(userId) && nick.trim() !== "" ? nick : "新成员";
    sendWelcomeMessage(groupId, userId, displayName, groupName || "本群", cfg.welcome.message);
    addLog("info", `[入群欢迎] 群${groupId} 欢迎 ${displayName}(${userId})`);
  };
  
  // 8秒超时保护
  const timeout = setTimeout(() => {
    if (eventNick) sendWelcome(eventNick, "本群");
    else sendWelcome("新成员", "本群");
  }, 8000);
  
  // 第一步：获取群信息
  sendAction("get_group_info", { group_id: groupId }, (groupResp) => {
    const groupName = (groupResp && groupResp.data && groupResp.data.group_name) || "本群";
    addLog("info", `[入群欢迎] 群信息: ${JSON.stringify(groupResp?.data || {})}`);
    
    // 第二步：获取群成员信息
    sendAction("get_group_member_info", { group_id: groupId, user_id: userId }, (memberResp) => {
      addLog("info", `[入群欢迎] 群成员信息返回: retcode=${memberResp?.retcode} status=${memberResp?.status} data=${JSON.stringify(memberResp?.data || {})}`);
      
      if (memberResp && memberResp.data && (memberResp.data.card || memberResp.data.nickname || memberResp.data.name)) {
        clearTimeout(timeout);
        const nick = memberResp.data.card || memberResp.data.nickname || memberResp.data.name;
        sendWelcome(nick, groupName);
      } else {
        // 群成员信息获取失败，尝试获取陌生人信息
        addLog("info", "[入群欢迎] 群成员信息无昵称，尝试get_stranger_info");
        sendAction("get_stranger_info", { user_id: userId, no_cache: true }, (strangerResp) => {
          clearTimeout(timeout);
          addLog("info", `[入群欢迎] 陌生人信息返回: ${JSON.stringify(strangerResp?.data || {})}`);
          if (strangerResp && strangerResp.data && strangerResp.data.nickname) {
            sendWelcome(strangerResp.data.nickname, groupName);
          } else if (eventNick) {
            sendWelcome(eventNick, groupName);
          } else {
            sendWelcome("新成员", groupName);
          }
        });
      }
    });
  });
}

// 处理base64图片，转换为OneBot可用的格式
function processWelcomeImage(imageData) {
  if (!imageData) return null;
  // 如果是base64 data URL格式（data:image/png;base64,xxx）
  if (imageData.startsWith("data:image")) {
    const base64Data = imageData.split(",")[1];
    return "base64://" + base64Data;
  }
  // 如果已经是base64://格式
  if (imageData.startsWith("base64://")) {
    return imageData;
  }
  // 如果是URL或本地路径，直接返回
  return imageData;
}

// 提取纯base64数据（去掉前缀），用于官方API上传
function extractPureBase64(imageData) {
  if (!imageData) return null;
  if (imageData.startsWith("data:image")) {
    return imageData.split(",")[1];
  }
  if (imageData.startsWith("base64://")) {
    return imageData.substring(9);
  }
  return imageData;
}

function sendWelcomeMessage(groupId, userId, nick, groupName, template) {
  let msg = template.replace(/{nick}/g, String(nick)).replace(/{qq}/g, String(nick)).replace(/{group}/g, String(groupName));
  const welcomeCfg = currentConfig.welcome || {};
  const welcomeImage = welcomeCfg.image || "";
  const welcomeButtons = welcomeCfg.buttons || [];
  const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
  const groupIdMap = (currentConfig.dualMode && currentConfig.dualMode.groupIdMap) || {};
  const groupOpenId = dualEnabled ? groupIdMap[String(groupId)] : null;
  
  // 双模式 + 有groupOpenId：用官方Markdown（文本+URL图片+底部按钮，全部同气泡）
  if (dualEnabled && groupOpenId) {
    (async () => {
      try {
        let md = msg;
        // URL图片直接嵌入Markdown
        if (welcomeImage && (welcomeImage.startsWith("http://") || welcomeImage.startsWith("https://"))) {
          md += "\n\n![欢迎图 #600px #400px](" + welcomeImage + ")";
        }
        
        // 构造底部按钮
        let keyboard = null;
        if (welcomeButtons && welcomeButtons.length > 0) {
          const rows = [];
          for (let i = 0; i < welcomeButtons.length; i += 3) {
            const rowButtons = [];
            for (let j = i; j < Math.min(i + 3, welcomeButtons.length); j++) {
              const btn = welcomeButtons[j];
              const btnData = (btn.data || "").replace(/{nick}/g, String(nick)).replace(/{qq}/g, String(nick)).replace(/{group}/g, String(groupName));
              const btnLabel = (btn.label || "按钮").replace(/{nick}/g, String(nick)).replace(/{qq}/g, String(nick)).replace(/{group}/g, String(groupName));
              let actionType = 2;
              if (btn.type === "link") actionType = 0;
              rowButtons.push({
                id: "welcome_btn_" + j,
                render_data: { label: btnLabel, visited_label: "已点击", style: btn.style || 1 },
                action: { type: actionType, data: btnData, permission: { type: 2 }, unsupport_tips: "客户端不支持" }
              });
            }
            rows.push({ buttons: rowButtons });
          }
          keyboard = { content: { rows: rows } };
        }
        
        // 官方发送（内部已有3次重试 + token自动刷新）
        await officialBot.sendOfficialMarkdownMessage(groupOpenId, md, keyboard);
        addLog("success", "[入群欢迎] 官方发送成功（文本+图片+按钮同气泡） 群" + groupId + " 用户" + nick);
      } catch (e) {
        addLog("error", "[入群欢迎] 官方发送失败（已重试3次） 群" + groupId + ": " + e.message);
        addLog("info", "[入群欢迎] 请检查：1.群openid映射是否正确 2.官方机器人是否在群内 3.网络是否正常");
      }
    })();
  } else {
    // 非双模式或无groupOpenId：用OneBot发送
    const messageSegments = [{ type: "text", data: { text: msg + (welcomeImage ? "\n\n" : "") } }];
    if (welcomeImage) messageSegments.push({ type: "image", data: { file: welcomeImage } });
    // 按钮转文本
    if (welcomeButtons && welcomeButtons.length > 0) {
      let btnText = "\n\n";
      welcomeButtons.forEach((btn) => {
        const btnLabel = (btn.label || "按钮").replace(/{nick}/g, String(nick)).replace(/{qq}/g, String(nick)).replace(/{group}/g, String(groupName));
        const btnData = (btn.data || "").replace(/{nick}/g, String(nick)).replace(/{qq}/g, String(nick)).replace(/{group}/g, String(groupName));
        if (btn.type === "link") btnText += `🔗 ${btnLabel}: ${btnData}\n`;
        else if (btn.type === "copy") btnText += `📋 ${btnLabel}: ${btnData}\n`;
        else btnText += `⚡ ${btnLabel}: 发送 ${btnData}\n`;
      });
      messageSegments.push({ type: "text", data: { text: btnText } });
    }
    sendAction("send_group_msg", { group_id: groupId, message: messageSegments }, (resp) => {
      if (resp && resp.error) addLog("warn", `[入群欢迎] 发送失败 群${groupId}: ${resp.error}`);
      else addLog("success", `[入群欢迎] OneBot发送成功 群${groupId}`);
    });
  }
}

// ==================== 退群提醒 ====================
function handleGroupDecrease(data, cfg) {
  if (botQQ && data.user_id === botQQ) return;
  const msg = cfg.leaveNotice.message
    .replace(/{nick}/g, String(data.user_id))
    .replace(/{qq}/g, String(data.user_id));
  sendGroupMessage(data.group_id, msg);
  addLog("info", `[退群提醒] 群${data.group_id} ${data.user_id} 退群`);
}

// ==================== 群消息处理 ====================
// 消息去重缓存，防止双模式下同一条消息被重复处理
const _messageDedupCache = new Map();
const DEDUP_CACHE_SIZE = 200;
const DEDUP_EXPIRE_TIME = 60000; // 60秒

function isDuplicateMessage(userId, groupId, messageText) {
  const key = userId + "_" + groupId + "_" + messageText.substring(0, 100);
  const now = Date.now();
  
  // 清理过期缓存
  for (const [k, v] of _messageDedupCache) {
    if (now - v > DEDUP_EXPIRE_TIME) {
      _messageDedupCache.delete(k);
    }
  }
  
  if (_messageDedupCache.has(key)) {
    return true;
  }
  
  _messageDedupCache.set(key, now);
  
  // 限制缓存大小
  if (_messageDedupCache.size > DEDUP_CACHE_SIZE) {
    const firstKey = _messageDedupCache.keys().next().value;
    _messageDedupCache.delete(firstKey);
  }
  
  return false;
}

async function handleGroupMessage(data, cfg) {
  // 消息去重检查（防止双模式下同一条消息被重复处理）
  try {
    const userId = data.user_id || (data.sender && data.sender.user_id) || "";
    const groupId = data.group_id || "";
    let messageText = "";
    if (typeof data.message === "string") {
      messageText = data.message;
    } else if (Array.isArray(data.message)) {
      messageText = data.message.map(m => m.type === "text" ? (m.data && m.data.text || "") : "").join("");
    } else if (data.raw_message) {
      messageText = data.raw_message;
    }
    if (userId && groupId && messageText && isDuplicateMessage(userId, groupId, messageText)) {
      addLog("info", "[去重] 忽略重复消息 群" + groupId + " 用户" + userId);
      return;
    }
  } catch (e) {
    // 去重检查失败不影响正常处理
  }

  // ========== 系统设置检查 ==========
  const sys = currentConfig.system || {};
  
  // 全局开关检查
  if (sys.globalEnabled === false) {
    return;
  }
  
  // 群黑名单检查
  const _sysGroupId = String(data.group_id || "");
  if (sys.groupBlacklist && sys.groupBlacklist.includes(_sysGroupId)) {
    return;
  }
  
  // 用户黑名单检查
  const _sysUserId = String(data.user_id || "");
  if (sys.userBlacklist && sys.userBlacklist.includes(_sysUserId)) {
    return;
  }
  
  // 防刷屏检查（管理员豁免）
  const _isAdmin = sys.adminList && sys.adminList.includes(_sysUserId);
  if (!_isAdmin && sys.antiSpam && sys.antiSpam > 0) {
    const now = Date.now();
    if (!global.lastReplyTime) global.lastReplyTime = {};
    const lastTime = global.lastReplyTime[_sysUserId] || 0;
    if (now - lastTime < sys.antiSpam * 1000) {
      return;
    }
    global.lastReplyTime[_sysUserId] = now;
  }
  
  // 管理员标记
  data.isAdmin = _isAdmin;
  

  const rawMsg = (data.raw_message || "").trim();
  const groupId = data.group_id;
  const userId = data.user_id;
  const sender = data.sender || {};
  const isAdmin = sender.role === "owner" || sender.role === "admin";
  const messageArray = data.message || [];
  const atUsers = messageArray.filter((m) => m.type === "at").map((m) => m.data.qq);

  // Warframe 国际服查询
  if (isFeatureEnabled(groupId, "warframe") && rawMsg.startsWith("#") && (rawMsg.includes("突击") || rawMsg.includes("虚空商人") || rawMsg.includes("baro") || rawMsg.includes("仲裁") || rawMsg.includes("裂缝") || rawMsg.includes("夜灵") || rawMsg.includes("奥布") || rawMsg.includes("魔胎") || rawMsg.includes("火卫二") || rawMsg.includes("入侵") || rawMsg.includes("钢铁") || rawMsg.includes("警报") || rawMsg.includes("深层科研") || rawMsg.includes("深岩") || rawMsg.includes("时光科研") || rawMsg.includes("网件") || rawMsg.includes("平原时间") || rawMsg.startsWith("#wm") || rawMsg.startsWith("#market") || rawMsg.startsWith("#市场") || rawMsg === "#wf帮助" || rawMsg === "#warframe")) {
    if (!checkRateLimit(userId, 3000)) return;
    const wfResult = await handleWarframeCommand(rawMsg, groupId);
    if (wfResult) {
      sendGroupMessage(groupId, wfResult);
      addLog("info", `[Warframe] 群${groupId} 指令: ${rawMsg}`);
      return;
    }
  }

  if (isFeatureEnabled(groupId, "hitokoto") && (rawMsg === "#一言" || rawMsg === "#鸡汤")) {
    const list = cfg.hitokotoList;
    sendGroupMessage(groupId, list[Math.floor(Math.random() * list.length)]);
    addLog("info", `[每日一言] 群${groupId} 触发`);
    return;
  }

  // 网站查询频率限制
  const isWebsiteQuery = rawMsg.startsWith("#搜索") || rawMsg.startsWith("#search") || rawMsg === "#随机游戏" || rawMsg === "#随机" || rawMsg === "#random" || rawMsg.startsWith("#分类") || rawMsg.startsWith("#category") || rawMsg.startsWith("#标签") || rawMsg.startsWith("#tag") || rawMsg.startsWith("#游戏") || rawMsg.startsWith("#game");
  if (isWebsiteQuery && !checkRateLimit(userId, 3000)) return;

  // 网站查询：搜索游戏
  if (isFeatureEnabled(groupId, "websiteQuery") && (rawMsg.startsWith("#搜索") || rawMsg.startsWith("#search"))) {
    const keyword = rawMsg.replace(/^#(搜索|search)\s*/, "").trim();
    if (!keyword) { sendGroupMessage(groupId, "用法：#搜索 游戏名"); return; }
    try {
      const posts = await searchPosts(keyword, 5);
      if (posts.length === 0) { sendGroupMessage(groupId, `未找到与"${keyword}"相关的游戏`); return; }
      
      const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
      const groupIdMap = (currentConfig.dualMode && currentConfig.dualMode.groupIdMap) || {};
      const groupOpenId = dualEnabled ? groupIdMap[String(groupId)] : null;
      
      // 双模式：用 Markdown + 底部复制按钮
      if (dualEnabled && groupOpenId) {
        try {
          let md = `## 🔍 搜索"${keyword}"找到 ${posts.length} 个结果\n\n`;
          posts.forEach((p, i) => {
            const title = stripHtml(p.title?.rendered || "无标题");
            const excerpt = stripHtml(p.excerpt?.rendered || "").slice(0, 60);
            md += `${i + 1}. **${title}**\n`;
            if (excerpt) md += `   ${excerpt}...\n`;
            md += `\n`;
          });
          md += `---\n点击下方按钮复制全部游戏链接`;
          
          const allLinks = posts.map((p, i) => `${i + 1}. ${stripHtml(p.title?.rendered || "")}\n${p.link || ""}`).join("\n\n");
          const copyBtn = officialBot.buildCopyButton("复制全部链接", allLinks, "copy_all");
          const keyboard = officialBot.buildKeyboard([[copyBtn]]);
          await officialBot.sendOfficialMarkdownMessage(groupOpenId, md, keyboard);
          addLog("success", `[搜索] 官方卡片发送成功: ${keyword}`);
        } catch (e) {
          addLog("warn", `[搜索] 官方卡片发送失败: ${e.message}`);
          // fallback 到纯文本
          let msg = `🔍 搜索"${keyword}"找到 ${posts.length} 个结果：\n\n`;
          posts.forEach((p, i) => {
            const title = stripHtml(p.title?.rendered || "无标题");
            msg += `${i + 1}. ${title}\n   ${p.link}\n\n`;
          });
          sendGroupMessage(groupId, msg.trim());
        }
      } else {
        // 非双模式：纯文本
        let msg = `🔍 搜索"${keyword}"找到 ${posts.length} 个结果：\n\n`;
        posts.forEach((p, i) => {
          const title = stripHtml(p.title?.rendered || "无标题");
          msg += `${i + 1}. ${title}\n   ${p.link}\n\n`;
        });
        sendGroupMessage(groupId, msg.trim());
      }
    } catch (e) {
      sendGroupMessage(groupId, "搜索失败，请稍后重试");
      addLog("warn", `[搜索] 失败: ${e.message}`);
    }
    return;
  }

  // 网站查询：随机推荐
  if (isFeatureEnabled(groupId, "websiteQuery") && (rawMsg === "#随机游戏" || rawMsg === "#随机" || rawMsg === "#random")) {
    try {
      const post = await getRandomPost();
      if (!post) { sendGroupMessage(groupId, "暂无游戏数据"); return; }
      sendGroupMessage(groupId, formatPostBrief(post));
    } catch (e) {
      sendGroupMessage(groupId, "获取失败，请稍后重试");
    }
    return;
  }

  // 网站查询：分类浏览
  if (isFeatureEnabled(groupId, "websiteQuery") && (rawMsg.startsWith("#分类") || rawMsg.startsWith("#category"))) {
    const catName = rawMsg.replace(/^#(分类|category)\s*/, "").trim();
    if (!catName) {
      try {
        const cats = await getCategories();
        if (cats.length === 0) { sendGroupMessage(groupId, "暂无分类"); return; }
        let msg = "📂 所有分类：\n";
        cats.forEach((c) => { msg += `  ${c.name}（${c.count}个）\n`; });
        msg += "\n用法：#分类 分类名";
        sendGroupMessage(groupId, msg);
      } catch (e) { sendGroupMessage(groupId, "获取分类失败"); }
      return;
    }
    try {
      const { category, posts } = await getPostsByCategory(catName, 8);
      if (!category) { sendGroupMessage(groupId, `未找到分类"${catName}"，发送 #分类 查看所有分类`); return; }
      if (posts.length === 0) { sendGroupMessage(groupId, `分类"${category.name}"下暂无游戏`); return; }
      let msg = `📂 分类：${category.name}（共${category.count}个，显示前${posts.length}个）\n\n`;
      posts.forEach((p, i) => {
        const title = stripHtml(p.title?.rendered || "无标题");
        msg += `${i + 1}. ${title}\n   ${p.link}\n`;
      });
      sendGroupMessage(groupId, msg);
    } catch (e) {
      sendGroupMessage(groupId, "获取分类游戏失败");
    }
    return;
  }

  // 网站查询：标签搜索
  if (isFeatureEnabled(groupId, "websiteQuery") && (rawMsg.startsWith("#标签") || rawMsg.startsWith("#tag"))) {
    const tagName = rawMsg.replace(/^#(标签|tag)\s*/, "").trim();
    if (!tagName) {
      try {
        const tags = await getTags();
        if (tags.length === 0) { sendGroupMessage(groupId, "暂无标签"); return; }
        let msg = "🏷️ 热门标签：\n";
        tags.slice(0, 20).forEach((t) => { msg += `  ${t.name}（${t.count}个）\n`; });
        msg += "\n用法：#标签 标签名";
        sendGroupMessage(groupId, msg);
      } catch (e) { sendGroupMessage(groupId, "获取标签失败"); }
      return;
    }
    try {
      const { tag, posts } = await getPostsByTag(tagName, 8);
      if (!tag) { sendGroupMessage(groupId, `未找到标签"${tagName}"，发送 #标签 查看所有标签`); return; }
      if (posts.length === 0) { sendGroupMessage(groupId, `标签"${tag.name}"下暂无游戏`); return; }
      
      const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
      const groupIdMap = (currentConfig.dualMode && currentConfig.dualMode.groupIdMap) || {};
      const groupOpenId = dualEnabled ? groupIdMap[String(groupId)] : null;
      
      // 双模式：用 Markdown + 底部复制按钮
      if (dualEnabled && groupOpenId) {
        try {
          let md = `## 🏷️ 标签：${tag.name}（共${tag.count}个，显示前${posts.length}个）\n\n`;
          posts.forEach((p, i) => {
            const title = stripHtml(p.title?.rendered || "无标题");
            const excerpt = stripHtml(p.excerpt?.rendered || "").slice(0, 60);
            md += `${i + 1}. **${title}**\n`;
            if (excerpt) md += `   ${excerpt}...\n`;
            md += `\n`;
          });
          md += `---\n点击下方按钮复制全部游戏链接`;
          
          const allLinks = posts.map((p, i) => `${i + 1}. ${stripHtml(p.title?.rendered || "")}\n${p.link || ""}`).join("\n\n");
          const copyBtn = officialBot.buildCopyButton("复制全部链接", allLinks, "copy_all");
          const keyboard = officialBot.buildKeyboard([[copyBtn]]);
          await officialBot.sendOfficialMarkdownMessage(groupOpenId, md, keyboard);
          addLog("success", `[标签] 官方卡片发送成功: ${tag.name}`);
        } catch (e) {
          addLog("warn", `[标签] 官方卡片发送失败: ${e.message}`);
          // fallback 到纯文本
          let msg = `🏷️ 标签：${tag.name}（共${tag.count}个，显示前${posts.length}个）\n\n`;
          posts.forEach((p, i) => {
            const title = stripHtml(p.title?.rendered || "无标题");
            msg += `${i + 1}. ${title}\n   ${p.link}\n`;
          });
          sendGroupMessage(groupId, msg);
        }
      } else {
        // 非双模式：纯文本
        let msg = `🏷️ 标签：${tag.name}（共${tag.count}个，显示前${posts.length}个）\n\n`;
        posts.forEach((p, i) => {
          const title = stripHtml(p.title?.rendered || "无标题");
          msg += `${i + 1}. ${title}\n   ${p.link}\n`;
        });
        sendGroupMessage(groupId, msg);
      }
    } catch (e) {
      sendGroupMessage(groupId, "获取标签游戏失败");
    }
    return;
  }

  // 网站查询：游戏详情
  if (isFeatureEnabled(groupId, "websiteQuery") && (rawMsg.startsWith("#游戏") || rawMsg.startsWith("#game"))) {
    const keyword = rawMsg.replace(/^#(游戏|game)\s*/, "").trim();
    if (!keyword) { sendGroupMessage(groupId, "用法：#游戏 游戏名"); return; }
    try {
      const posts = await searchPosts(keyword, 5);
      if (posts.length === 0) { sendGroupMessage(groupId, `未找到"${keyword}"相关游戏`); return; }
      
      const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
      const groupIdMap = (currentConfig.dualMode && currentConfig.dualMode.groupIdMap) || {};
      const groupOpenId = dualEnabled ? groupIdMap[String(groupId)] : null;
      
      // 只有1个结果时显示详情
      if (posts.length === 1) {
        const detail = await getPostDetail(posts[0].id);
        const title = stripHtml(detail.title?.rendered || "无标题");
        const link = detail.link || "";
        const content = stripHtml(detail.content?.rendered || "").slice(0, 200);
        const img = detail._embedded?.["wp:featuredmedia"]?.[0]?.source_url;
        
        // 双模式：使用 Embed 卡片
        if (dualEnabled && groupOpenId) {
          try {
            const extraFields = [];
            if (content) extraFields.push({ name: "游戏介绍", value: content + "..." });
            await officialBot.sendOfficialGameCard(groupOpenId, title, "", img, link, extraFields);
            addLog("success", `[游戏详情] 官方卡片发送成功: ${title}`);
          } catch (e) {
            addLog("warn", `[游戏详情] 官方卡片发送失败: ${e.message}`);
            // fallback 到文本
            let msg = `🎮 ${title}\n\n`;
            if (content) msg += `${content}...\n\n`;
            if (img) msg += `🖼️ ${img}\n\n`;
            msg += `👉 详情+下载：${link}`;
            sendGroupMessage(groupId, msg);
          }
        } else {
          let msg = `🎮 ${title}\n\n`;
          if (content) msg += `${content}...\n\n`;
          if (img) msg += `🖼️ ${img}\n\n`;
          msg += `👉 详情+下载：${link}`;
          sendGroupMessage(groupId, msg);
        }
      } else {
        // 多个结果时显示列表
        // 双模式：使用 Markdown 卡片，展示所有结果
        if (dualEnabled && groupOpenId) {
          try {
            // 构造结果列表
            const resultList = posts.map(p => ({
              title: stripHtml(p.title?.rendered || "无标题"),
              excerpt: stripHtml(p.excerpt?.rendered || "").slice(0, 60),
              link: p.link || ""
            }));
            await officialBot.sendOfficialMultiResultCard(groupOpenId, keyword, resultList);
            addLog("success", `[游戏详情] 官方多结果卡片发送成功: ${keyword}`);
          } catch (e) {
            addLog("warn", `[游戏详情] 官方多结果卡片发送失败: ${e.message}`);
            // fallback 到文本
            let msg = `🎮 搜索"${keyword}"找到 ${posts.length} 个结果：\n\n`;
            posts.forEach((p, i) => {
              const title = stripHtml(p.title?.rendered || "无标题");
              const link = p.link || "";
              const excerpt = stripHtml(p.excerpt?.rendered || "").slice(0, 60);
              msg += `${i + 1}. ${title}\n`;
              if (excerpt) msg += `   ${excerpt}...\n`;
              msg += `   👉 ${link}\n\n`;
            });
            msg += `共找到 ${posts.length} 个同名游戏，点击链接查看详情`;
            sendGroupMessage(groupId, msg.trim());
          }
        } else {
          let msg = `🎮 搜索"${keyword}"找到 ${posts.length} 个结果：\n\n`;
          posts.forEach((p, i) => {
            const title = stripHtml(p.title?.rendered || "无标题");
            const link = p.link || "";
            const excerpt = stripHtml(p.excerpt?.rendered || "").slice(0, 60);
            msg += `${i + 1}. ${title}\n`;
            if (excerpt) msg += `   ${excerpt}...\n`;
            msg += `   👉 ${link}\n\n`;
          });
          msg += `共找到 ${posts.length} 个同名游戏，点击链接查看详情`;
          sendGroupMessage(groupId, msg.trim());
        }
      }
    } catch (e) {
      sendGroupMessage(groupId, "获取游戏详情失败");
      addLog("warn", `[游戏详情] 失败: ${e.message}`);
    }
    return;
  }

  if (rawMsg === "#帮助" || rawMsg === "#help" || rawMsg === "帮助") {
    sendHelpMenu(groupId);
    return;
  }

  if (isFeatureEnabled(groupId, "admin")) {
    if (handleAdminCommands(groupId, userId, rawMsg, isAdmin, atUsers, cfg)) return;
  }

  if (isFeatureEnabled(groupId, "keywordReply")) {
    for (const item of cfg.keywordReplies) {
      let matched = item.mode === "exact" ? rawMsg === item.keyword : rawMsg.includes(item.keyword);
      if (matched) {
        sendGroupMessage(groupId, item.reply);
        addLog("info", `[关键词] 群${groupId} 用户${userId} 命中"${item.keyword}"`);
        break;
      }
    }
  }

  // 默认回复（所有指令都没匹配到时，非#开头的消息）
  const _sysDef = currentConfig.system || {};
  const _rawMsgDef = (data.raw_message || "").trim();
  if (!_rawMsgDef.startsWith("#") && _sysDef.defaultReply && _sysDef.defaultReply.trim()) {
    sendGroupMessage(data.group_id, _sysDef.defaultReply);
  }
}

// ==================== 群管指令 ====================
function handleAdminCommands(groupId, userId, rawMsg, isAdmin, atUsers, cfg) {
  if (rawMsg.startsWith("#踢")) {
    if (!isAdmin) { sendGroupMessage(groupId, "只有群主或管理员才能使用此指令"); return true; }
    if (atUsers.length === 0) { sendGroupMessage(groupId, "用法：#踢 @某人"); return true; }
    atUsers.forEach((targetId) => {
      sendAction("set_group_kick", { group_id: groupId, user_id: targetId });
      sendGroupMessage(groupId, `已将 ${targetId} 移出群聊`);
      addLog("info", `[群管] 群${groupId} 踢人 ${targetId}（操作者${userId}）`);
    });
    return true;
  }
  if (rawMsg.startsWith("#禁言")) {
    if (!isAdmin) { sendGroupMessage(groupId, "只有群主或管理员才能使用此指令"); return true; }
    if (atUsers.length === 0) { sendGroupMessage(groupId, "用法：#禁言 @某人 10（分钟，0=解除）"); return true; }
    const match = rawMsg.match(/#禁言\s+(\d+)/);
    const minutes = match ? parseInt(match[1]) : 10;
    const seconds = Math.min(minutes * 60, 30 * 24 * 3600);
    atUsers.forEach((targetId) => {
      sendAction("set_group_ban", { group_id: groupId, user_id: targetId, duration: seconds });
      sendGroupMessage(groupId, seconds === 0 ? `已解除 ${targetId} 的禁言` : `已禁言 ${targetId} ${minutes} 分钟`);
      addLog("info", `[群管] 群${groupId} 禁言 ${targetId} ${minutes}分钟（操作者${userId}）`);
    });
    return true;
  }
  if (rawMsg === "#全员禁言") {
    if (!isAdmin) { sendGroupMessage(groupId, "只有群主或管理员才能使用此指令"); return true; }
    sendAction("set_group_whole_ban", { group_id: groupId, enable: true });
    sendGroupMessage(groupId, "已开启全员禁言");
    addLog("info", `[群管] 群${groupId} 全员禁言（操作者${userId}）`);
    return true;
  }
  if (rawMsg === "#解除全员禁言") {
    if (!isAdmin) { sendGroupMessage(groupId, "只有群主或管理员才能使用此指令"); return true; }
    sendAction("set_group_whole_ban", { group_id: groupId, enable: false });
    sendGroupMessage(groupId, "已解除全员禁言");
    addLog("info", `[群管] 群${groupId} 解除全员禁言（操作者${userId}）`);
    return true;
  }
  return false;
}

function sendHelpMenu(groupId) {
  const helpText = `
========== 机器人功能菜单 ==========

【游戏查询】
  #搜索 游戏名      搜索网站游戏
  #随机游戏         随机推荐一个游戏
  #分类             查看所有分类
  #分类 动作        浏览指定分类游戏
  #标签             查看所有标签
  #标签 3D          浏览指定标签游戏
  #游戏 游戏名      查看游戏详情+下载

【通用指令】
  #帮助    显示本帮助菜单
  #一言    随机一句励志名言

【群管指令】（仅群主/管理员可用）
  #踢 @某人           移出群成员
  #禁言 @某人 10      禁言指定分钟（0=解除）
  #全员禁言           开启全员禁言
  #解除全员禁言       关闭全员禁言

【自动功能】
  新成员入群自动欢迎
  成员退群自动提醒
  关键词自动回复
  网站新游自动推送

====================================
`.trim();
  sendGroupMessage(groupId, helpText);
}

// ==================== 在线更新模块 ====================
function downloadText(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith("https://") ? https : http;
    client.get(url, { headers: { "User-Agent": "XiaoXiongBot/1.0" } }, (res) => {
      let data = "";
      res.on("data", (c) => data += c);
      res.on("end", () => {
        if (res.statusCode < 200 || res.statusCode >= 300) { reject(new Error(`HTTP ${res.statusCode}`)); return; }
        resolve(data);
      });
    }).on("error", reject);
  });
}

function downloadFile(url, dest) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith("https://") ? https : http;
    const file = fs.createWriteStream(dest);
    client.get(url, { headers: { "User-Agent": "XiaoXiongBot/1.0" } }, (res) => {
      if (res.statusCode < 200 || res.statusCode >= 300) { file.close(); fs.unlinkSync(dest); reject(new Error(`HTTP ${res.statusCode}`)); return; }
      res.pipe(file);
      file.on("finish", () => { file.close(); resolve(); });
    }).on("error", (e) => { file.close(); if (fs.existsSync(dest)) fs.unlinkSync(dest); reject(e); });
  });
}

function extractZip(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    const psCmd = `Expand-Archive -Path '${zipPath}' -DestinationPath '${destDir}' -Force`;
    exec(`powershell -NoProfile -Command "${psCmd}"`, (error, stdout, stderr) => {
      if (error) reject(new Error(stderr || error.message)); else resolve();
    });
  });
}

function copyDir(src, dest) {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  const resolvedDest = path.resolve(dest);
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.resolve(dest, entry.name);
    // 路径遍历防护：确保目标路径在目标目录内
    if (!destPath.startsWith(resolvedDest + path.sep) && destPath !== resolvedDest) {
      addLog("warn", `[安全] 跳过可疑路径: ${entry.name}`);
      continue;
    }
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function compareVersion(v1, v2) {
  const a = v1.split(".").map(Number);
  const b = v2.split(".").map(Number);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const x = a[i] || 0, y = b[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

// ==================== IPC 通信 ====================
function setupIpc() {
  ipcMain.handle("config:get", () => currentConfig);
  ipcMain.handle("config:save", (_, config) => ({ success: saveConfig(config) }));

  ipcMain.handle("bot:connect", async () => {
    try {
      if (!currentConfig) {
        return { success: false, error: "配置未加载，请重启软件" };
      }
      const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
      
      if (dualEnabled) {
        addLog("info", "双模式：同时连接 OneBot 和官方机器人");
        connectBot();
        setTimeout(() => { connectOfficialBotMode(); }, 1000);
      } else {
        officialMode = currentConfig.officialMode === true;
        if (officialMode) {
          addLog("info", "当前模式：官方机器人模式");
          await connectOfficialBotMode();
        } else {
          addLog("info", "当前模式：OneBot模式");
          connectBot();
        }
      }
      console.log("[bot:connect] 连接指令已发送");
      return { success: true };
    } catch (e) {
      console.error("[bot:connect] 连接出错:", e);
      addLog("error", "连接出错: " + e.message);
      return { success: false, error: e.message + "\n" + e.stack };
    }
  });
  ipcMain.handle("bot:disconnect", () => {
    const dualEnabled = currentConfig.dualMode && currentConfig.dualMode.enabled;
    if (dualEnabled || officialMode) {
      disconnectOfficialBotMode();
    }
    if (dualEnabled || !officialMode) {
      disconnectBot();
    }
    return { success: true };
  });
  ipcMain.handle("bot:status", () => ({ status: botStatus, logs: logBuffer, botQQ }));
  ipcMain.handle("bot:clear-logs", () => { logBuffer = []; return { success: true }; });

  // 官方机器人模式
  ipcMain.handle("official:connect", async () => {
    try {
      await connectOfficialBotMode();
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("official:disconnect", () => { disconnectOfficialBotMode(); return { success: true }; });
  ipcMain.handle("official:status", () => ({ status: officialStatus, info: officialBot.getOfficialStatus() }));
  ipcMain.handle("official:send-group", async (_, groupId, content, msgId) => {
    try {
      const result = await sendOfficialGroupMessage(groupId, content, msgId);
      return { success: true, result };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("official:set-mode", (_, mode) => {
    officialMode = mode === "official";
    addLog("info", `切换到${officialMode ? "官方机器人" : "OneBot"}模式`);
    return { success: true, mode: officialMode ? "official" : "onebot" };
  });
  ipcMain.handle("official:get-mode", () => ({ mode: officialMode ? "official" : "onebot" }));

  // 网站对接
  ipcMain.handle("website:test", async () => {
    try {
      const posts = await fetchLatestPosts(3);
      return { success: true, posts };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("website:push-now", async () => {
    try {
      addLog("info", "[立即推送] 开始获取最新文章...");
      const posts = await fetchLatestPosts(1);
      if (posts && posts[0]) {
        const post = posts[0];
        const title = (post.title && post.title.rendered) ? post.title.rendered.replace(/<[^>]+>/g, "") : "无标题";
        addLog("info", `[立即推送] 获取到文章: ${title} (ID: ${post.id})`);
        // 检查推送群配置
        const pushGroups = currentConfig.website.pushGroups || [];
        addLog("info", `[立即推送] 配置的推送群: ${pushGroups.length > 0 ? pushGroups.join(", ") : "无"}`);
        if (pushGroups.length === 0) {
          addLog("warn", "[立即推送] 未配置推送群，请在网站设置中添加推送群");
          return { success: false, error: "未配置推送群" };
        }
        // 检查图片
        let imageUrl = "";
        if (post._embedded && post._embedded["wp:featuredmedia"] && post._embedded["wp:featuredmedia"][0]) {
          imageUrl = post._embedded["wp:featuredmedia"][0].source_url || "";
        }
        if (!imageUrl && post.content && post.content.rendered) {
          imageUrl = extractFirstImage(post.content.rendered);
        }
        addLog("info", `[立即推送] 图片: ${imageUrl ? "有" : "无"}`);
        pushPostToGroups(post);
        currentConfig.website.lastPostId = post.id;
        saveConfig();
        addLog("success", `[立即推送] 推送完成: ${title}`);
        return { success: true, post: post };
      }
      addLog("warn", "[立即推送] 没有获取到文章");
      return { success: false, error: "没有获取到文章" };
    } catch (e) {
      addLog("error", `[立即推送] 失败: ${e.message}`);
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("website:check-now", () => { checkWebsiteAndPush(); return { success: true }; });

  // 群设置
  ipcMain.handle("group-settings:get", (_, groupId) => {
    const gid = String(groupId);
    const groupCfg = currentConfig.groupSettings[gid] || {};
    const merged = { ...currentConfig.defaults, ...groupCfg };
    return { groupId: gid, settings: merged, isCustom: !!currentConfig.groupSettings[gid] };
  });
  ipcMain.handle("group-settings:save", (_, groupId, settings) => {
    const gid = String(groupId);
    currentConfig.groupSettings[gid] = { ...settings };
    saveConfig();
    return { success: true };
  });
  ipcMain.handle("group-settings:reset", (_, groupId) => {
    const gid = String(groupId);
    delete currentConfig.groupSettings[gid];
    saveConfig();
    return { success: true };
  });
  ipcMain.handle("group-settings:list", () => {
    return Object.keys(currentConfig.groupSettings).map(gid => ({
      groupId: gid,
      settings: { ...currentConfig.defaults, ...currentConfig.groupSettings[gid] },
    }));
  });

  // 推送群管理
  ipcMain.handle("push-groups:add", (_, groupId) => {
    const gid = String(groupId);
    if (!currentConfig.website.pushGroups.includes(gid)) {
      currentConfig.website.pushGroups.push(gid);
      saveConfig();
    }
    return { success: true, pushGroups: currentConfig.website.pushGroups };
  });
  ipcMain.handle("push-groups:remove", (_, groupId) => {
    const gid = String(groupId);
    currentConfig.website.pushGroups = currentConfig.website.pushGroups.filter(g => g !== gid);
    saveConfig();
    return { success: true, pushGroups: currentConfig.website.pushGroups };
  });

  ipcMain.handle("config:export", async () => {
    const result = await dialog.showSaveDialog(mainWindow, {
      title: "导出配置", defaultPath: "qq-bot-config.json",
      filters: [{ name: "JSON文件", extensions: ["json"] }],
    });
    if (!result.canceled && result.filePath) {
      fs.writeFileSync(result.filePath, JSON.stringify(currentConfig, null, 2), "utf-8");
      return { success: true };
    }
    return { success: false };
  });

ipcMain.handle("config:import", async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: "导入配置", filters: [{ name: "JSON文件", extensions: ["json"] }],
      properties: ["openFile"],
    });
    if (!result.canceled && result.filePaths.length > 0) {
      try {
        const imported = JSON.parse(fs.readFileSync(result.filePaths[0], "utf-8"));
        currentConfig = deepMerge(DEFAULT_CONFIG, imported);
        saveConfig();
        return { success: true, config: currentConfig };
      } catch (e) {
        return { success: false, error: e.message };
      }
    }
    return { success: false };
  });

  // 窗口控制
  ipcMain.handle("window:minimize", () => { if (mainWindow) mainWindow.minimize(); });
  ipcMain.handle("window:maximize", () => {
    if (!mainWindow) return;
    if (mainWindow.isMaximized()) mainWindow.unmaximize(); else mainWindow.maximize();
  });
  ipcMain.handle("window:close", () => { if (mainWindow) mainWindow.close(); });
  ipcMain.handle("window:is-maximized", () => ({ maximized: mainWindow ? mainWindow.isMaximized() : false }));

  // 在线更新
  ipcMain.handle("update:get-version", () => ({ version: APP_VERSION }));
  ipcMain.handle("update:check", async () => {
    try {
      const data = await downloadText(UPDATE_URL + "version.json");
      const remote = JSON.parse(data);
      const hasUpdate = compareVersion(remote.version, APP_VERSION) > 0;
      return { success: true, hasUpdate, latestVersion: remote.version, notes: remote.notes || "", currentVersion: APP_VERSION };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("update:download", async () => {
    try {
      const verData = await downloadText(UPDATE_URL + "version.json");
      const remote = JSON.parse(verData);
      const fileName = remote.file || "update.zip";
      // 支持完整URL或相对路径
      const downloadUrl = fileName.startsWith("http") ? fileName : UPDATE_URL + fileName;
      const tempZip = path.join(app.getPath("temp"), "xiaoxiong-update.zip");
      await downloadFile(downloadUrl, tempZip);
      const tempDir = path.join(app.getPath("temp"), "xiaoxiong-update");
      if (fs.existsSync(tempDir)) fs.rmSync(tempDir, { recursive: true, force: true });
      fs.mkdirSync(tempDir, { recursive: true });
      await extractZip(tempZip, tempDir);
      const appDir = app.getAppPath();
      copyDir(tempDir, appDir);
      fs.rmSync(tempDir, { recursive: true, force: true });
      fs.unlinkSync(tempZip);
      return { success: true, message: "更新完成，请重启应用" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
  ipcMain.handle("update:restart", () => { app.relaunch(); app.exit(0); });

  // Warframe 平台设置
  ipcMain.handle("warframe:get-platform", () => ({ platform: WF_PLATFORM }));
  ipcMain.handle("warframe:set-platform", (_, platform) => {
    const valid = ["pc", "ps4", "xb1", "swi"];
    if (valid.includes(platform)) { WF_PLATFORM = platform; return { success: true }; }
    return { success: false, error: "无效平台" };
  });

  // 本地更新包（选择本地zip直接更新）
  ipcMain.handle("update:local", async () => {
    try {
      const result = await dialog.showOpenDialog(mainWindow, {
        title: "选择更新包", filters: [{ name: "更新包", extensions: ["zip"] }],
        properties: ["openFile"],
      });
      if (result.canceled || result.filePaths.length === 0) return { success: false, error: "已取消" };
      const zipPath = result.filePaths[0];
      const tempDir = path.join(app.getPath("temp"), "xiaoxiong-local-update");
      if (fs.existsSync(tempDir)) fs.rmSync(tempDir, { recursive: true, force: true });
      fs.mkdirSync(tempDir, { recursive: true });
      await extractZip(zipPath, tempDir);
      const appDir = app.getAppPath();
      copyDir(tempDir, appDir);
      fs.rmSync(tempDir, { recursive: true, force: true });
      return { success: true, message: "本地更新包已安装，请重启应用" };
    } catch (e) {
      return { success: false, error: e.message };
    }
  });
}

// ==================== 窗口创建 ====================
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100, height: 720, minWidth: 900, minHeight: 600,
    title: "小熊机器人",
    icon: path.join(__dirname, "icon.png"),
    frame: false,
    backgroundColor: "#0f0f23",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true, nodeIntegration: false,
    },
  });
  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile(path.join(__dirname, "renderer", "index.html"));
  mainWindow.on("closed", () => { mainWindow = null; });
  mainWindow.on("maximize", () => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send("window:maximized", true); });
  mainWindow.on("unmaximize", () => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send("window:maximized", false); });
}

// ==================== App 生命周期 ====================

// 全局错误处理
process.on("uncaughtException", (err) => {
  console.error("未捕获的异常:", err);
  try { addLog("error", "系统异常: " + err.message); } catch(e) {}
});
process.on("unhandledRejection", (reason, promise) => {
  console.error("未处理的Promise拒绝:", reason);
  try { addLog("error", "异步错误: " + (reason.message || reason)); } catch(e) {}
});

app.whenReady().then(() => {
  loadConfig();
  setupIpc();
  createWindow();
    // 启动定期缓存清理（清理频率限制、缓存、欢迎缓存，防止内存泄漏）
  startCacheCleanup();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  disconnectBot();
  if (process.platform !== "darwin") app.quit();
});
