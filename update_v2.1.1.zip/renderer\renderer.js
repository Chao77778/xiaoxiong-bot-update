// 全局Tab切换函数（确保可被onclick调用）
function switchSettingsTab(tabName) {
  try {
    document.querySelectorAll(".settings-tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".settings-panel").forEach(p => p.classList.remove("active"));
    const tab = document.querySelector('.settings-tab[data-tab="' + tabName + '"]');
    const panel = document.getElementById("panel-" + tabName);
    if (tab) tab.classList.add("active");
    if (panel) panel.classList.add("active");
  } catch (e) {
    console.error("Tab切换失败:", e);
  }
}

// 全局群设置面板切换函数（确保可被onclick调用）
function toggleGroupPanel(gid) {
  try {
    const body = document.getElementById("gsc-body-" + gid);
    const card = document.querySelector('.group-setting-card[data-gid="' + gid + '"]');
    if (!body || !card) {
      console.warn("toggleGroupPanel: 未找到元素, gid=" + gid);
      return;
    }
    const isExpanded = card.classList.contains("expanded");
    if (isExpanded) {
      body.style.display = "none";
      card.classList.remove("expanded");
    } else {
      body.style.display = "block";
      card.classList.add("expanded");
    }
  } catch (e) {
    console.error("toggleGroupPanel错误:", e);
  }
}

// ============== 渲染进程逻辑 v3.0 ==============
let toastTimer = null;
let currentConfig = null;
let keywordEditingList = [];
let welcomeButtonsList = [];

document.addEventListener("DOMContentLoaded", async () => {
  // 先注册事件监听器，确保不会因为后面的错误而丢失事件
  setupEventListeners();
  
  try {
    currentConfig = await window.api.getConfig();
    fillAllForms(currentConfig);
    const status = await window.api.getStatus();
    updateStatusUI(status);
    renderLogs(status.logs || []);
    setupNavigation();
    setupButtons();
    renderPushGroupList();
    renderGroupSettingsList();
    loadVersion();
  } catch (e) {
    console.error("初始化出错:", e);
    if (document.getElementById("consoleLog")) {
      appendLog({ time: new Date().toLocaleString(), type: "error", message: "初始化出错: " + e.message });
    }
  }
});


// ==================== 导航 ====================
function setupNavigation() {
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("click", () => switchPage(item.dataset.page));
  });
}
function switchPage(pageName) {
  document.querySelectorAll(".nav-item").forEach((i) => i.classList.remove("active"));
  document.querySelector(`.nav-item[data-page="${pageName}"]`).classList.add("active");
  document.querySelectorAll(".page").forEach((p) => p.classList.remove("active"));
  document.getElementById(`page-${pageName}`).classList.add("active");
  // 切换页面时重置滚动位置到顶部
  const contentArea = document.querySelector(".content");
  if (contentArea) contentArea.scrollTop = 0;
}


// 保存成功动画：按钮显示"✓ 已保存"2秒
function showSaveSuccess(btn) {
  if (!btn) return;
  const originalText = btn.textContent;
  btn.classList.add("btn-save-success");
  btn.textContent = "✓ 已保存";
  btn.disabled = true;
  setTimeout(() => {
    btn.classList.remove("btn-save-success");
    btn.textContent = originalText;
    btn.disabled = false;
  }, 2000);
}

// 复制所有日志
async function copyAllLogs() {
  const logEl = document.getElementById("consoleLog");
  if (!logEl) {
    showToast("日志容器不存在", "error");
    return;
  }
  const entries = logEl.querySelectorAll(".log-entry");
  if (entries.length === 0) {
    showToast("暂无日志可复制", "info");
    return;
  }
  let text = "===== 小熊机器人日志 =====\n";
  text += "导出时间: " + new Date().toLocaleString("zh-CN") + "\n";
  text += "日志数量: " + entries.length + "\n";
  text += "========================\n";
  entries.forEach((entry) => {
    const time = entry.querySelector(".log-time")?.textContent || "";
    const type = entry.querySelector(".log-type")?.textContent || "";
    const msg = entry.querySelector(".log-message")?.textContent || "";
    text += "[" + time + "] [" + type.padEnd(7) + "] " + msg + "\n";
  });
  await fallbackCopy(text);
}

// 复制文本到剪贴板
async function fallbackCopy(text) {
  try {
    // 优先使用现代Clipboard API
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      showToast("日志已复制到剪贴板（共" + text.split("\n").length + "行）", "success");
      return;
    }
  } catch (e) {
    console.warn("Clipboard API失败，尝试备用方法:", e.message);
  }
  // 备用方法：创建临时textarea
  try {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    textarea.style.top = "-9999px";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    const successful = document.execCommand("copy");
    document.body.removeChild(textarea);
    if (successful) {
      showToast("日志已复制到剪贴板", "success");
    } else {
      showToast("复制失败，请手动选择日志文本复制", "error");
    }
  } catch (e) {
    showToast("复制失败: " + e.message, "error");
  }
}

// 双模式配置收集
function collectDualModeConfig() {
  try {
    const mapText = document.getElementById("cfgGroupIdMap").value.trim();
    currentConfig.dualMode = {
      enabled: document.getElementById("cfgDualMode").checked,
      groupIdMap: mapText ? JSON.parse(mapText) : {}
    };
    return true;
  } catch (e) {
    showToast("群ID映射JSON格式错误: " + e.message, "error");
    return false;
  }
}

// 渲染欢迎按钮列表
function renderWelcomeButtons() {
  const container = document.getElementById("welcomeButtonsList");
  if (!container) return;
  container.innerHTML = "";
  welcomeButtonsList.forEach((btn, idx) => {
    const row = document.createElement("div");
    row.className = "button-config-row";
    row.innerHTML = '<div><label>按钮文字</label><input type="text" class="input" value="' + escapeHtml(btn.label || "") + '" placeholder="如：点击进入官网" data-idx="' + idx + '" data-field="label"></div>' +
      '<div><label>类型</label><select class="input" data-idx="' + idx + '" data-field="type"><option value="link"' + (btn.type === "link" ? " selected" : "") + '>跳转</option><option value="copy"' + (btn.type === "copy" ? " selected" : "") + '>复制</option><option value="command"' + (btn.type === "command" ? " selected" : "") + '>指令</option></select></div>' +
      '<div><label>内容</label><input type="text" class="input" value="' + (btn.data || "") + '" placeholder="链接/复制内容/指令" data-idx="' + idx + '" data-field="data"></div>' +
      '<div><label>样式</label><select class="input" data-idx="' + idx + '" data-field="style"><option value="1"' + (btn.style == 1 ? " selected" : "") + '>蓝色</option><option value="0"' + (btn.style == 0 ? " selected" : "") + '>灰色</option></select></div>' +
      '<button class="btn btn-sm btn-danger" data-del-idx="' + idx + '">删除</button>';
    container.appendChild(row);
  });
  container.querySelectorAll("input, select").forEach((el) => {
    el.addEventListener("input", (e) => {
      const idx = parseInt(e.target.dataset.idx);
      const field = e.target.dataset.field;
      welcomeButtonsList[idx][field] = field === "style" ? parseInt(e.target.value) : e.target.value;
    });
  });
  container.querySelectorAll("[data-del-idx]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      welcomeButtonsList.splice(parseInt(e.target.dataset.delIdx), 1);
      renderWelcomeButtons();
    });
  });
}

// 更新欢迎图片预览
function updateWelcomeImagePreview(imageUrl) {
  const preview = document.getElementById("welcomeImagePreview");
  const img = document.getElementById("welcomeImagePreviewImg");
  if (!preview || !img) return;
  if (imageUrl && imageUrl.trim() !== "" && (imageUrl.startsWith("http://") || imageUrl.startsWith("https://"))) {
    img.src = imageUrl;
    preview.classList.add("show");
  } else {
    img.src = "";
    preview.classList.remove("show");
  }
}

// ==================== 按钮事件 ====================
function setupButtons() {
  document.getElementById("btnConnect").addEventListener("click", async () => {
    collectConnectionConfig();
    await saveAllConfig();
    showToast("正在连接...", "info");
    const result = await window.api.connect();
    if (result && result.success) {
      showToast("连接指令已发送", "success");
    } else {
      showToast("连接失败: " + (result ? result.error : "未知错误"), "error");
    }
  });
  document.getElementById("btnDisconnect").addEventListener("click", async () => {
    await window.api.disconnect();
    showToast("已断开连接", "info");
  });
    // 欢迎图片失焦后预览
  document.getElementById("cfgWelcomeImage").addEventListener("blur", (e) => {
    updateWelcomeImagePreview(e.target.value);
  });
document.getElementById("btnClearLog").addEventListener("click", async () => {
    await window.api.clearLogs();
    document.getElementById("consoleLog").innerHTML = "";
  });

  // 各页面保存
  document.getElementById("btnSaveConnection").addEventListener("click", () => { collectConnectionConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveConnection")); });
  document.getElementById("btnSaveWelcome").addEventListener("click", () => { collectWelcomeConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveWelcome")); showToast("欢迎配置已保存"); });
  document.getElementById("btnSaveKeywords").addEventListener("click", () => { collectKeywordsConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveKeywords")); });
  document.getElementById("btnSaveAdmin").addEventListener("click", () => { collectAdminConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveAdmin")); });
  document.getElementById("btnSaveWebsite").addEventListener("click", () => { collectWebsiteConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveWebsite")); });
  document.getElementById("btnSaveDefaults").addEventListener("click", () => { collectDefaultsConfig(); saveAllConfig(); showSaveSuccess(document.getElementById("btnSaveDefaults")); });
  document.getElementById("btnSaveOfficial").addEventListener("click", () => { collectOfficialConfig(); saveAllConfig(); showToast("官方配置已保存"); });
  document.getElementById("btnSaveMode").addEventListener("click", () => {
    collectModeConfig();
    saveAllConfig();
    const isOfficial = document.getElementById("cfgOfficialMode").checked;
    showToast(isOfficial ? "已切换到官方机器人模式" : "已切换到OneBot模式");
  });

  // 关键词
  document.getElementById("btnAddKeyword").addEventListener("click", () => {
    keywordEditingList.push({ keyword: "", reply: "", mode: "includes" });
    renderKeywordList();
  });

  // 导入导出
  const _btnExport = document.getElementById("btnExport");
  if (_btnExport) _btnExport.addEventListener("click", async () => {
    try {
      const r = await window.api.exportConfig();
      if (r.success) showToast("配置已导出", "success");
      else showToast("导出失败: " + (r.error || ""), "error");
    } catch(e) { showToast("导出失败: " + e.message, "error"); }
  });
  const _btnImport = document.getElementById("btnImport");
  if (_btnImport) _btnImport.addEventListener("click", async () => {
    try {
      const r = await window.api.importConfig();
      if (r.success) {
        currentConfig = r.config;
        loadConfigToUI();
        showToast("配置已导入", "success");
      } else {
        showToast("导入失败: " + (r.error || ""), "error");
      }
    } catch(e) { showToast("导入失败: " + e.message, "error"); }
  });

  // 网站推送
  document.getElementById("btnTestWebsite").addEventListener("click", testWebsite);
  document.getElementById("btnPushNow").addEventListener("click", pushNow);
  document.getElementById("btnCheckNow").addEventListener("click", async () => { collectWebsiteConfig(); await saveAllConfig(false); await window.api.websiteCheckNow(); showToast("已触发检查", "info"); });
  document.getElementById("btnAddPushGroup").addEventListener("click", addPushGroup);

  // 群功能管理
  document.getElementById("btnAddGroup").addEventListener("click", addGroupToManage);

  // 自定义标题栏按钮
  document.getElementById("btnMinimize").addEventListener("click", () => window.api.windowMinimize());
  document.getElementById("btnMaximize").addEventListener("click", async () => {
    await window.api.windowMaximize();
    updateMaximizeIcon();
  });
  document.getElementById("btnClose").addEventListener("click", () => window.api.windowClose());
  if (window.api.onWindowMaximized) {
    window.api.onWindowMaximized((maximized) => updateMaximizeIcon(maximized));
  }
  window.api.windowIsMaximized().then((r) => updateMaximizeIcon(r.maximized));

  // 在线更新
  document.getElementById("btnCheckUpdate").addEventListener("click", checkUpdate);
  const btnLocalUpdate = document.getElementById("btnLocalUpdate");
  if (btnLocalUpdate) btnLocalUpdate.addEventListener("click", localUpdate);

  // Warframe 平台设置
  loadWfPlatform();
  document.getElementById("btnSaveWfPlatform").addEventListener("click", async () => {
    const platform = document.getElementById("wfPlatform").value;
    const r = await window.api.wfSetPlatform(platform);
    if (r.success) showToast("Warframe 平台已设置为: " + platform, "success");
    else showToast("设置失败: " + (r.error || "未知错误"), "error");
  });
}

// ==================== 在线更新 ====================
async function loadVersion() {
  try {
    const r = await window.api.updateGetVersion();
    const ver = r.version || "未知";
    const verEl = document.getElementById("appVersion");
    if (verEl) verEl.textContent = `桌面版 v${ver}`;
    const aboutVer = document.getElementById("aboutVersion");
    if (aboutVer) aboutVer.textContent = `版本 v${ver}（OneBot v11 + 网站对接 + 群粒度开关 + 在线更新）`;
  } catch (e) {}
}

async function checkUpdate() {
  const btn = document.getElementById("btnCheckUpdate");
  const result = document.getElementById("updateResult");
  btn.disabled = true;
  btn.textContent = "正在检查...";
  result.style.display = "block";
  result.textContent = "正在连接更新服务器...";
  try {
    const r = await window.api.updateCheck();
    if (!r.success) {
      result.textContent = "检查失败: " + (r.error || "未知错误");
      result.style.color = "#ff6b6b";
    } else if (r.hasUpdate) {
      result.innerHTML = `<strong style="color:#ffd93d;">发现新版本 v${r.latestVersion}</strong><br>${r.notes || ""}<br><br>当前版本: v${r.currentVersion}`;
      btn.textContent = "下载并更新";
      btn.disabled = false;
      btn.onclick = async () => {
        btn.disabled = true;
        btn.textContent = "正在下载更新...";
        result.textContent = "正在下载更新包，请稍候...";
        const dl = await window.api.updateDownload();
        if (dl.success) {
          result.innerHTML = `<strong style="color:#6bcb77;">更新完成！</strong><br>${dl.message}`;
          btn.textContent = "立即重启";
          btn.onclick = () => window.api.updateRestart();
          btn.disabled = false;
        } else {
          result.textContent = "更新失败: " + (dl.error || "未知错误");
          result.style.color = "#ff6b6b";
          btn.textContent = "检查更新";
          btn.onclick = checkUpdate;
          btn.disabled = false;
        }
      };
      return;
    } else {
      result.innerHTML = `<strong style="color:#6bcb77;">已是最新版本</strong><br>当前版本: v${r.currentVersion}`;
    }
  } catch (e) {
    result.textContent = "检查失败: " + e.message;
    result.style.color = "#ff6b6b";
  }
  btn.textContent = "检查更新";
  btn.disabled = false;
}

async function localUpdate() {
  const result = document.getElementById("updateResult");
  result.style.display = "block";
  result.textContent = "请选择本地 update.zip 更新包...";
  try {
    const r = await window.api.updateLocal();
    if (r.success) {
      result.innerHTML = `<strong style="color:#6bcb77;">更新完成！</strong><br>${r.message}<br><br><button class="btn btn-primary" id="btnRestartNow" style="margin-top:8px;">立即重启</button>`;
  const _btnRestartNow = document.getElementById("btnRestartNow");
  if (_btnRestartNow) _btnRestartNow.addEventListener("click", () => { window.api.restartApp(); });
    } else {
      result.textContent = r.error || "更新已取消";
      result.style.color = "#ff6b6b";
    }
  } catch (e) {
    result.textContent = "更新失败: " + e.message;
    result.style.color = "#ff6b6b";
  }
}

async function loadWfPlatform() {
  try {
    const r = await window.api.wfGetPlatform();
    const sel = document.getElementById("wfPlatform");
    if (sel && r.platform) sel.value = r.platform;
  } catch (e) {}
}

function updateMaximizeIcon(maximized) {
  const btn = document.getElementById("btnMaximize");
  if (!btn) return;
  if (maximized) {
    btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12"><rect x="3" y="1.5" width="6" height="6" fill="none" stroke="currentColor" stroke-width="1"/><rect x="1.5" y="3" width="6" height="6" fill="none" stroke="currentColor" stroke-width="1"/></svg>';
    btn.title = "还原";
  } else {
    btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12"><rect x="2.5" y="2.5" width="7" height="7" fill="none" stroke="currentColor" stroke-width="1"/></svg>';
    btn.title = "最大化";
  }

  // 模式互斥：开启单模式官方时自动关闭双模式，反之亦然
  const officialModeCheckbox = document.getElementById("cfgOfficialMode");
  const dualModeCheckbox = document.getElementById("cfgDualMode");
  officialModeCheckbox.addEventListener("change", () => {
    if (officialModeCheckbox.checked) {
      dualModeCheckbox.checked = false;
      showToast("已切换到单官方模式，双模式已关闭", "info");
    }
  });
  dualModeCheckbox.addEventListener("change", () => {
    if (dualModeCheckbox.checked) {
      officialModeCheckbox.checked = false;
      showToast("已切换到双模式，单官方模式已关闭", "info");
    }
  });

  // 双模式保存
  document.getElementById("btnSaveDualMode").addEventListener("click", () => {
    if (collectDualModeConfig()) {
      saveAllConfig();
      showSaveSuccess(document.getElementById("btnSaveDualMode"));
      showToast("双模式配置已保存");
    }
  });

  // 欢迎按钮配置
  document.getElementById("btnAddWelcomeButton").addEventListener("click", () => {
    welcomeButtonsList.push({ label: "新按钮", type: "link", data: "https://", style: 1 });
    renderWelcomeButtons();
  });

  // 图片上传
  const _btnUploadWelcomeImage = document.getElementById("btnUploadWelcomeImage");
  if (_btnUploadWelcomeImage) _btnUploadWelcomeImage.addEventListener("click", async () => {
    try {
      const result = await window.api.selectImage();
      if (result && result.success) {
        document.getElementById("cfgWelcomeImage").value = result.dataUrl;
        updateWelcomeImagePreview(result.dataUrl);
        showToast("图片已上传 (" + result.fileSize + ")");
      }
    } catch(e) {
      showToast("选择图片失败: " + e.message, "error");
    }
  });

  // 复制日志
  
  // ========== 系统设置 ==========
  // Tab切换（事件委托，确保可点击）
  document.addEventListener("click", (e) => {
    const tab = e.target.closest(".settings-tab");
    if (tab) {
      e.preventDefault();
      e.stopPropagation();
      document.querySelectorAll(".settings-tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".settings-panel").forEach(p => p.classList.remove("active"));
      tab.classList.add("active");
      const panel = document.getElementById("panel-" + tab.dataset.tab);
      if (panel) panel.classList.add("active");
    }
  });
  
  // 主题色切换
  document.querySelectorAll(".theme-color").forEach(color => {
    color.addEventListener("click", () => {
      document.querySelectorAll(".theme-color").forEach(c => c.classList.remove("active"));
      color.classList.add("active");
      const newColor = color.dataset.color;
      document.documentElement.style.setProperty("--accent", newColor);
      showToast("主题色已切换", "success");
    });
  });
  
  // 保存通用设置
  document.getElementById("btnSaveGeneral").addEventListener("click", async () => {
    const config = await window.api.getConfig();
    config.system = config.system || {};
    config.system.botNickname = document.getElementById("cfgBotNickname").value || "小熊";
    config.system.defaultReply = document.getElementById("cfgDefaultReply").value;
    config.system.globalEnabled = document.getElementById("cfgGlobalEnabled").checked;
    config.system.antiSpam = parseInt(document.getElementById("cfgAntiSpam").value) || 0;
    await window.api.saveConfig(config);
    showSavedToast("btnSaveGeneral");
  });
  
  // 保存日志设置
  document.getElementById("btnSaveLog").addEventListener("click", async () => {
    const config = await window.api.getConfig();
    config.system = config.system || {};
    config.system.logLevel = document.getElementById("cfgLogLevel").value;
    config.system.logRetention = parseInt(document.getElementById("cfgLogRetention").value) || 7;
    await window.api.saveConfig(config);
    showSavedToast("btnSaveLog");
  });
  
  // 保存界面设置
  document.getElementById("btnSaveUI").addEventListener("click", async () => {
    const config = await window.api.getConfig();
    config.system = config.system || {};
    config.system.ui = config.system.ui || {};
    const activeColor = document.querySelector(".theme-color.active");
    config.system.ui.accentColor = activeColor ? activeColor.dataset.color : "#5c6bc0";
    config.system.ui.bgImage = document.getElementById("cfgBgImage").value;
    config.system.ui.fontSize = document.getElementById("cfgFontSize").value;
    await window.api.saveConfig(config);
    // 应用字体大小
    document.documentElement.style.fontSize = config.system.ui.fontSize + "px";
    showSavedToast("btnSaveUI");
  });
  
  // 保存安全设置
  document.getElementById("btnSaveSecurity").addEventListener("click", async () => {
    const config = await window.api.getConfig();
    config.system = config.system || {};
    config.system.adminList = document.getElementById("cfgAdminList").value.split("\n").map(s => s.trim()).filter(s => s);
    config.system.opPassword = document.getElementById("cfgOpPassword").value;
    config.system.groupBlacklist = document.getElementById("cfgGroupBlacklist").value.split("\n").map(s => s.trim()).filter(s => s);
    config.system.userBlacklist = document.getElementById("cfgUserBlacklist").value.split("\n").map(s => s.trim()).filter(s => s);
    await window.api.saveConfig(config);
    showSavedToast("btnSaveSecurity");
  });
  
  // 保存高级设置
  document.getElementById("btnSaveAdvanced").addEventListener("click", async () => {
    const config = await window.api.getConfig();
    config.system = config.system || {};
    config.system.debugMode = document.getElementById("cfgDebugMode").checked;
    config.system.msgTimeout = parseInt(document.getElementById("cfgMsgTimeout").value) || 10;
    config.system.reconnectLimit = parseInt(document.getElementById("cfgReconnectLimit").value) || 10;
    config.system.concurrency = parseInt(document.getElementById("cfgConcurrency").value) || 3;
    await window.api.saveConfig(config);
    showSavedToast("btnSaveAdvanced");
  });
  
  // 系统设置里的导出/导入配置
  const _btnExportConfig2 = document.getElementById("btnExportConfig2");
  if (_btnExportConfig2) _btnExportConfig2.addEventListener("click", () => { const _btnExport = document.getElementById("btnExport"); if (_btnExport) _btnExport.click(); });
  const _btnImportConfig2 = document.getElementById("btnImportConfig2");
  if (_btnImportConfig2) _btnImportConfig2.addEventListener("click", () => { const _btnImport = document.getElementById("btnImport"); if (_btnImport) _btnImport.click(); });
  

}

  

function setupEventListeners() {
  window.api.onLog((entry) => appendLog(entry));
  window.api.onStatus((data) => updateStatusUI(data));
  // 官方机器人被添加到群
  if (window.api.onOfficialGroupAdded) {
    window.api.onOfficialGroupAdded((data) => {
      addRecentGroup(data.group_openid, data.time);
      showToast("官方机器人已被添加到新群！group_openid已复制", "success");
      fallbackCopy(data.group_openid);
    });
  }
}

// ==================== 配置填充 ====================
function fillAllForms(config) {
  // 运行模式
  document.getElementById("cfgOfficialMode").checked = config.officialMode === true;
  // 双模式
  if (config.dualMode) {
    document.getElementById("cfgDualMode").checked = config.dualMode.enabled === true;
    document.getElementById("cfgGroupIdMap").value = JSON.stringify(config.dualMode.groupIdMap || {}, null, 2);
  }
  // OneBot
  document.getElementById("cfgWsUrl").value = (config.connection && config.connection.wsUrl) || "";
  document.getElementById("cfgToken").value = (config.connection && config.connection.accessToken) || "";
  document.getElementById("cfgAutoReconnect").checked = !(config.connection && config.connection.autoReconnect === false);
  // 官方
  document.getElementById("cfgOfficialAppId").value = (config.official && config.official.appId) || "";
  document.getElementById("cfgOfficialAppSecret").value = (config.official && config.official.appSecret) || "";
  // 网站
  document.getElementById("cfgWebsiteUrl").value = (config.website && config.website.url) || "";
  document.getElementById("cfgWebsiteInterval").value = (config.website && config.website.checkInterval) || 5;
  document.getElementById("cfgWebsiteTemplate").value = (config.website && config.website.pushTemplate) || "";
  document.getElementById("cfgWebsiteEnabled").checked = (config.website && config.website.enabled) !== false;
  // 欢迎
  document.getElementById("cfgWelcomeMessage").value = (config.welcome && config.welcome.message) || "";
  document.getElementById("cfgWelcomeImage").value = (config.welcome && config.welcome.image) || "";
  updateWelcomeImagePreview((config.welcome && config.welcome.image) || "");
  welcomeButtonsList = JSON.parse(JSON.stringify((config.welcome && config.welcome.buttons) || []));
  renderWelcomeButtons();
  document.getElementById("cfgLeaveMessage").value = (config.leaveNotice && config.leaveNotice.message) || "";
  // 关键词
  keywordEditingList = JSON.parse(JSON.stringify(config.keywordReplies || []));
  renderKeywordList();
  // 一言
  document.getElementById("cfgHitokoto").value = (config.hitokotoList || []).join("\n");
  // 默认设置
  const d = config.defaults || {};
  document.getElementById("defWelcome").checked = d.welcome !== false;
  document.getElementById("defLeaveNotice").checked = d.leaveNotice !== false;
  document.getElementById("defKeywordReply").checked = d.keywordReply !== false;
  document.getElementById("defWebsitePush").checked = d.websitePush !== false;
  document.getElementById("defAdmin").checked = d.admin !== false;
  document.getElementById("defHitokoto").checked = d.hitokoto !== false;
}

function collectConnectionConfig() {
  currentConfig.connection.wsUrl = document.getElementById("cfgWsUrl").value.trim();
  currentConfig.connection.accessToken = document.getElementById("cfgToken").value.trim();
  currentConfig.connection.autoReconnect = document.getElementById("cfgAutoReconnect").checked;
}
function collectOfficialConfig() {
  if (!currentConfig.official) currentConfig.official = {};
  currentConfig.official.appId = document.getElementById("cfgOfficialAppId").value.trim();
  currentConfig.official.appSecret = document.getElementById("cfgOfficialAppSecret").value.trim();
}
function collectModeConfig() {
  currentConfig.officialMode = document.getElementById("cfgOfficialMode").checked;
}
function collectWebsiteConfig() {
  currentConfig.website.enabled = document.getElementById("cfgWebsiteEnabled").checked;
  currentConfig.website.url = document.getElementById("cfgWebsiteUrl").value.trim();
  currentConfig.website.checkInterval = parseInt(document.getElementById("cfgWebsiteInterval").value) || 5;
  currentConfig.website.pushTemplate = document.getElementById("cfgWebsiteTemplate").value;
}
function collectWelcomeConfig() {
  currentConfig.welcome.message = document.getElementById("cfgWelcomeMessage").value;
  currentConfig.welcome.image = document.getElementById("cfgWelcomeImage").value.trim();
  currentConfig.welcome.buttons = welcomeButtonsList.filter((b) => b.label.trim() !== "");
  currentConfig.leaveNotice.message = document.getElementById("cfgLeaveMessage").value;
}

function collectKeywordsConfig() {
  currentConfig.keywordReplies = keywordEditingList.filter((i) => i.keyword.trim() !== "");
}
function collectAdminConfig() {
  const hitokoto = document.getElementById("cfgHitokoto").value;
  currentConfig.hitokotoList = hitokoto.split("\n").map((s) => s.trim()).filter((s) => s !== "");
}
function collectDefaultsConfig() {
  currentConfig.defaults = {
    welcome: document.getElementById("defWelcome").checked,
    leaveNotice: document.getElementById("defLeaveNotice").checked,
    keywordReply: document.getElementById("defKeywordReply").checked,
    websitePush: document.getElementById("defWebsitePush").checked,
    admin: document.getElementById("defAdmin").checked,
    hitokoto: document.getElementById("defHitokoto").checked,
  };
}
async function saveAllConfig(showToastMsg = true) {
  const r = await window.api.saveConfig(currentConfig);
  if (showToastMsg) {
    showToast(r.success ? "配置已保存" : "保存失败", r.success ? "success" : "error");
  }
  return r;
}

// ==================== 网站推送功能 ====================
async function testWebsite() {
  collectWebsiteConfig();
  await saveAllConfig();
  const resultEl = document.getElementById("websiteTestResult");
  resultEl.style.display = "block";
  resultEl.innerHTML = '<div style="padding:12px;color:#666;">正在测试连接...</div>';
  const r = await window.api.websiteTest();
  if (r.success && r.posts) {
    let html = '<div style="padding:12px;color:#2e7d32;font-weight:bold;margin-bottom:8px;">✅ 连接成功！最新3篇文章：</div>';
    r.posts.forEach((p) => {
      const title = (p.title && p.title.rendered) ? p.title.rendered.replace(/<[^>]+>/g, "") : "无标题";
      html += `<div style="padding:8px 0;border-bottom:1px solid #eee;font-size:13px;"><a href="${p.link}" target="_blank" style="color:#1976d2;">${escapeHtml(title)}</a><br><span style="color:#999;font-size:12px;">ID: ${p.id} | ${p.date}</span></div>`;
    });
    resultEl.innerHTML = html;
  } else {
    resultEl.innerHTML = `<div style="padding:12px;color:#c62828;">❌ 连接失败: ${escapeHtml(r.error || "未知错误")}</div>`;
  }
}
async function pushNow() {
  collectWebsiteConfig();
  await saveAllConfig(false); // 不显示"配置已保存"提示
  const r = await window.api.websitePushNow();
  if (r.success) showToast("已推送最新文章", "success");
  else showToast("推送失败: " + (r.error || ""), "error");
}
function addPushGroup() {
  const input = document.getElementById("newPushGroup");
  const gid = input.value.trim();
  if (!gid || isNaN(parseInt(gid))) { showToast("请输入有效的群号", "error"); return; }
  if (!currentConfig.website.pushGroups) currentConfig.website.pushGroups = [];
  if (currentConfig.website.pushGroups.includes(gid)) { showToast("该群已添加", "warn"); return; }
  currentConfig.website.pushGroups.push(gid);
  saveAllConfig();
  input.value = "";
  renderPushGroupList();
  showToast("已添加推送群", "success");
}
function renderPushGroupList() {
  const container = document.getElementById("pushGroupList");
  const groups = currentConfig.website.pushGroups || [];
  if (groups.length === 0) { container.innerHTML = '<div style="padding:12px;color:#999;font-size:13px;">暂无推送群，添加后该群将收到网站新游推送</div>'; return; }
  container.innerHTML = groups.map((gid) => `
    <div class="push-group-item">
      <span class="pg-id">群 ${gid}</span>
      <button class="btn btn-sm btn-danger" onclick="removePushGroup('${gid}')">移除</button>
    </div>
  `).join("");
}
window.removePushGroup = async function(gid) {
  currentConfig.website.pushGroups = (currentConfig.website.pushGroups || []).filter((g) => g !== gid);
  await saveAllConfig();
  renderPushGroupList();
  showToast("已移除", "info");
};

// ==================== 群功能管理 ====================
function addGroupToManage() {
  const input = document.getElementById("newGroupId");
  const gid = input.value.trim();
  if (!gid || isNaN(parseInt(gid))) { showToast("请输入有效的群号", "error"); return; }
  if (!currentConfig.groupSettings) currentConfig.groupSettings = {};
  if (currentConfig.groupSettings[gid]) { showToast("该群已在管理列表", "warn"); return; }
  currentConfig.groupSettings[gid] = { ...currentConfig.defaults };
  saveAllConfig();
  input.value = "";
  renderGroupSettingsList();
  showToast("已添加群", "success");
}
function renderGroupSettingsList() {
  const container = document.getElementById("groupSettingsList");
  const groups = currentConfig.groupSettings || {};
  const gids = Object.keys(groups);
  if (gids.length === 0) { container.innerHTML = '<div style="padding:16px;color:#999;font-size:13px;text-align:center;">暂无管理群，添加后可单独控制每个群的功能开关</div>'; return; }
  container.innerHTML = gids.map((gid) => {
    const s = groups[gid];
    return `
    <div class="group-setting-card" data-gid="${gid}">
      <div class="gsc-header" onclick="toggleGroupPanel('${gid}')">
        <span class="gsc-title">👥 群 ${gid}</span>
        <span class="gsc-toggle">▼</span>
      </div>
      <div class="gsc-body" id="gsc-body-${gid}">
        <div class="gsc-switches">
          <label class="switch-label"><input type="checkbox" class="gs-welcome" ${s.welcome ? "checked" : ""}><span>入群欢迎</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-leaveNotice" ${s.leaveNotice ? "checked" : ""}><span>退群提醒</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-keywordReply" ${s.keywordReply ? "checked" : ""}><span>关键词回复</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-websitePush" ${s.websitePush ? "checked" : ""}><span>网站推送</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-websiteQuery" ${s.websiteQuery !== false ? "checked" : ""}><span>网站查询</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-warframe" ${s.warframe !== false ? "checked" : ""}><span>Warframe查询</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-admin" ${s.admin ? "checked" : ""}><span>群管指令</span></label>
          <label class="switch-label"><input type="checkbox" class="gs-hitokoto" ${s.hitokoto ? "checked" : ""}><span>一言功能</span></label>
        </div>
        <div class="gsc-actions">
          <button class="btn btn-sm btn-primary" onclick="saveGroupSettings('${gid}')">保存此群设置</button>
          <button class="btn btn-sm btn-ghost" onclick="resetGroupSettings('${gid}')">恢复默认</button>
          <button class="btn btn-sm btn-danger" onclick="removeGroupSettings('${gid}')">从列表移除</button>
        </div>
      </div>
    </div>`;
  }).join("");
}
;
window.saveGroupSettings = async function(gid) {
  const card = document.querySelector(`.group-setting-card[data-gid="${gid}"]`);
  currentConfig.groupSettings[gid] = {
    welcome: card.querySelector(".gs-welcome").checked,
    leaveNotice: card.querySelector(".gs-leaveNotice").checked,
    keywordReply: card.querySelector(".gs-keywordReply").checked,
    websitePush: card.querySelector(".gs-websitePush").checked,
    websiteQuery: card.querySelector(".gs-websiteQuery").checked,
    warframe: card.querySelector(".gs-warframe").checked,
    admin: card.querySelector(".gs-admin").checked,
    hitokoto: card.querySelector(".gs-hitokoto").checked,
  };
  await saveAllConfig();
  showToast(`群 ${gid} 设置已保存`, "success");
};
window.resetGroupSettings = async function(gid) {
  currentConfig.groupSettings[gid] = { ...currentConfig.defaults };
  await saveAllConfig();
  renderGroupSettingsList();
  showToast("已恢复默认设置", "info");
};
window.removeGroupSettings = async function(gid) {
  delete currentConfig.groupSettings[gid];
  await saveAllConfig();
  renderGroupSettingsList();
  showToast("已从管理列表移除", "info");
};

// ==================== 关键词列表渲染 ====================
function renderKeywordList() {
  const container = document.getElementById("keywordList");
  if (keywordEditingList.length === 0) {
    container.innerHTML = '<div class="keyword-empty">暂无关键词规则，点击右上角"添加规则"开始添加</div>';
    return;
  }
  container.innerHTML = keywordEditingList.map((item, idx) => `
    <div class="keyword-item" data-idx="${idx}">
      <div class="kw-inputs">
        <div class="kw-row">
          <input type="text" class="input kw-keyword" placeholder="关键词" value="${escapeHtml(item.keyword)}">
          <select class="input kw-mode">
            <option value="includes" ${item.mode === "includes" ? "selected" : ""}>包含匹配</option>
            <option value="exact" ${item.mode === "exact" ? "selected" : ""}>精确匹配</option>
          </select>
        </div>
        <div class="kw-row">
          <input type="text" class="input kw-reply" placeholder="回复内容" value="${escapeHtml(item.reply)}">
        </div>
      </div>
      <button class="btn-delete" data-idx="${idx}">删除</button>
    </div>
  `).join("");
  container.querySelectorAll(".keyword-item").forEach((el) => {
    const idx = parseInt(el.dataset.idx);
    el.querySelector(".kw-keyword").addEventListener("input", (e) => { keywordEditingList[idx].keyword = e.target.value; });
    el.querySelector(".kw-reply").addEventListener("input", (e) => { keywordEditingList[idx].reply = e.target.value; });
    el.querySelector(".kw-mode").addEventListener("change", (e) => { keywordEditingList[idx].mode = e.target.value; });
    el.querySelector(".btn-delete").addEventListener("click", () => { keywordEditingList.splice(idx, 1); renderKeywordList(); });
  });
}

// ==================== 状态UI ====================
function updateStatusUI(data) {
  const status = typeof data === "string" ? data : data.status;
  const botQQ = typeof data === "object" ? data.botQQ : null;
  const dot = document.querySelector(".status-dot");
  const text = document.getElementById("statusText");
  const qqText = document.getElementById("statusQQ");
  const btnConnect = document.getElementById("btnConnect");
  const btnDisconnect = document.getElementById("btnDisconnect");
  dot.className = "status-dot " + status;
  const statusMap = { disconnected: "未连接", connecting: "连接中...", connected: "已连接", error: "异常" };
  text.textContent = statusMap[status] || status;
  if (botQQ) qqText.textContent = `机器人QQ: ${botQQ}`;
  else if (status === "connected") qqText.textContent = "已连接 OneBot 服务";
  else qqText.textContent = "等待连接 OneBot 服务";
  if (status === "connected" || status === "connecting") { btnConnect.disabled = true; btnDisconnect.disabled = false; }
  else { btnConnect.disabled = false; btnDisconnect.disabled = true; }
}

// ==================== 日志 ====================
function renderLogs(logs) {
  const container = document.getElementById("consoleLog");
  container.innerHTML = "";
  logs.forEach((entry) => appendLog(entry, false));
  container.scrollTop = container.scrollHeight;
}
function appendLog(entry) {
  const container = document.getElementById("consoleLog");
  const div = document.createElement("div");
  div.className = "log-entry";
  div.innerHTML = `<span class="log-time">[${entry.time}]</span><span class="log-type ${entry.type}">${entry.type.toUpperCase()}</span><span class="log-message">${escapeHtml(entry.message)}</span>`;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
  while (container.children.length > 500) container.removeChild(container.firstChild);
}

// ==================== Toast ====================

function showToast(message, type = "info") {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.className = "toast " + type + " show";
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2500);
}


// 保存成功按钮反馈
function showSavedToast(btnId) {
  const btn = document.getElementById(btnId);
  if (!btn) return;
  const originalText = btn.textContent;
  btn.textContent = "✓ 已保存";
  btn.disabled = true;
  setTimeout(() => {
    btn.textContent = originalText;
    btn.disabled = false;
  }, 2000);
  showToast("设置已保存", "success");
}



// ==================== 工具 ====================

// 最近添加的群
let recentGroups = [];
function addRecentGroup(groupOpenid, time) {
  recentGroups.unshift({ openid: groupOpenid, time: time });
  if (recentGroups.length > 5) recentGroups = recentGroups.slice(0, 5);
  renderRecentGroups();
}
function renderRecentGroups() {
  const area = document.getElementById("recentGroupsArea");
  const list = document.getElementById("recentGroupsList");
  if (!area || !list) return;
  if (recentGroups.length === 0) {
    area.style.display = "none";
    return;
  }
  area.style.display = "block";
  list.innerHTML = "";
  recentGroups.forEach((g, idx) => {
    const item = document.createElement("div");
    item.style.cssText = "display:flex;align-items:center;gap:10px;padding:8px 12px;background:rgba(255,255,255,0.05);border-radius:6px;cursor:pointer;border:1px solid rgba(255,255,255,0.1);";
    item.innerHTML = `<span style="flex:1;font-family:monospace;font-size:12px;word-break:break-all;">${g.openid}</span><span style="font-size:11px;color:var(--text-muted);white-space:nowrap;">${g.time}</span><span style="font-size:11px;color:var(--accent);white-space:nowrap;">点击复制</span>`;
    item.addEventListener("click", () => {
      fallbackCopy(g.openid);
    });
    list.appendChild(item);
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}
